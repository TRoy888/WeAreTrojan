<?php

return [
	'useLaravelMessages'	=>	true,
	'converter'	=>	'Bllim\LaravelToJqueryValidation\FormBuilder'
];
