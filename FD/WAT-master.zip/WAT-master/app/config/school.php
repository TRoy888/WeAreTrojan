<?php

return array(

  'group' => array(
    'Dornsife' => 'Dornsife College of Letters, Arts and Sceinces',
    'Leventhal' => 'Leventhal School of Accounting',
    'Architecture' => 'Architecture',
    'Roski' => 'Roski School of Art and Design',
    'Arts' => 'Arts, Technology and the Business of Innovation',
    'Marshall' => 'Marshall School of Business',
    'Cinematic' => 'Cinematic Arts',
    'Annenberg' => 'Annenberg School for Communication and Journalism',
    'Kaufman' => 'Kaufman School of Dance',
    'Ostrow' => 'Ostrow School of Dentistry',
    'Dramatic' => 'Dramatic Arts',
    'Rossier' => 'Rossier School of Education',
    'Viterbi' => 'Viterbi School of Engineering',
    'General' => 'General Education',
    'Davis' => 'Davis School of Gerontology',
    'Graduate' => 'Graduate Studies',
    'Law' => 'Law',
    'Keck' => 'Keck School of Medicine',
    'Thornton' => 'Thornton School of Music',
    'Occupational' => 'Occupational Science and Occupational Therapy',
    'Pharmacy' => 'Pharmacy',
    'Physical' => 'Physical Therapy',
    'Price' => 'Price School of Public Policy',
    'Social' => 'Social Work'
  ),

);
