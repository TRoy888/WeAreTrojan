<?php

// Use in-memory database for testing
return array(

    'default' => 'mysql',

    'connections' => array(
        'sqlite' => array(
            'driver'   => 'sqlite',
            'database' => ':memory:',
            'prefix'   => ''
        ),
        'mysql' => array(
                'driver'    => 'mysql',
                'host'      => 'localhost',
                'database'  => 'WATDB',
                'username'  => 'root',
                'password'  => 'root',
                'charset'   => 'utf8',
                'collation' => 'utf8_general_ci',
                'prefix'    => '',
        )
    )
);
