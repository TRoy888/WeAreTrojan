<?php

return array(
/**
* -----------------------------------------------------
* The number of search result in the dropdown list in the nav bar
* ------------------------------------------------------
*/
'number_of_character_in_short_thread' => 250,


);
