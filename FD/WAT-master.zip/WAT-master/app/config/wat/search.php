<?php

return array(

/**
* -----------------------------------------------------
* Elasticsearch server IP(s)
* ------------------------------------------------------
*/
'elasticsearch_hosts' => array (
  '127.0.0.1:9200'
),

/**
* -----------------------------------------------------
* The number of search result in the dropdown list in the nav bar
* ------------------------------------------------------
*/
'number_of_search_result_in_dropdown' => 10,

/**
* -----------------------------------------------------
* The number of search result in the dropdown list in the nav bar
* ------------------------------------------------------
*/
'number_of_search_result' => 10,
);
