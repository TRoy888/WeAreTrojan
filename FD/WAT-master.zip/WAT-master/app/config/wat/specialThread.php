<?php

return array(

  /**
  * -----------------------------------------------------
  * Threads get most post within one week
  * ------------------------------------------------------
  */
  'hot_thread_id' => 0,
  'hot_thread_name' => "Hot Threads",


  /**
  * -----------------------------------------------------
  * All threads in the database
  * ------------------------------------------------------
  */
  'all_thread_id' => -1,
  'all_thread_name' => "All Threads"
);
