<?php

return array(
  'filter_class'            => 'min:1|max:500',
  'filter_degree'           => 'max:255',
  'filter_description'      => 'max:500',
  'filter_email'            => 'required|email|unique:users,email',
  'filter_firstname'        => 'required|name|max:255',
  'filter_lastname'         => 'required|name|max:255',
  'filter_password'         => 'required|confirmed|min:8|max:25',
  'filter_pic_cover'        => 'required|image|max:1000',
  'filter_pic_profile'      => 'required|image|max:1000',
  'filter_school'           => 'max:255',
  'url_pic_default_profile' => '/images/profile_pic/default',
  'url_pic_default_cover'   => '/images/cover_pic/default',
  'url_folder_profile_pic'  => '/images/profile_pic',
  'url_folder_cover_pic'    => '/images/cover_pic',
);
