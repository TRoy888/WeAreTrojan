<?php

return array(

  /**
  * -----------------------------------------------------
  * point for each like a thread/post got.
  * ------------------------------------------------------
  */
  'like_point' => 2,


  /**
  * -----------------------------------------------------
  * point to be dedcuted for each dislik a thread/post got.
  * ------------------------------------------------------
  */
  'dislike_point' => 1,
);
