<?php

use Repositories\Admin\AdminRepository;

class AdminController extends \BaseController {

  private $authFilter = ['except' => []];
  private $repo;

  /**
   * Constructor will initialize Admincontroller value such as filter and repository
   */
  public function __construct(AdminRepository $repo) {
    $this->beforeFilter('auth', $this->authFilter);
    $this->beforeFilter('admin');
    $this->repo = $repo;
  }

  /**
   * Delete a post by mark the delete flag to 1
   * @return Response success if the post flag is mark, fail with error message if not.
   */
  public function deletePost() {
    $post = $this->repo->findPost(Input::get('post'));
    if (empty($post)) {
      return Response::json(array('success' => false, 'errors' => 'Invalid Post[value:'.$post.']'), 400);
    }

    if ($post->deletePost() == false) {
      return Response::json(array('success' => false, 'errors' => 'Post[id:'.$post->id.']->deletePost() failed'), 500);
    }

    Log::info('Post[id:'.$post->id.'] is deleted by admin');
    return Response::json(array('success' => true), 200); //OK
  }

  /**
   * Delete a thread by mark the delete flag to 1
   * @return Response success if the thread flag is mark, fail with error message if not.
   */
  public function deleteThread() {
    $thread = $this->repo->findThread(Input::get('thread'));
    if (empty($thread)) {
      return Response::json(array('success' => false, 'errors' => 'Invalid Thread[value:'.$thread.'] input("thread":'.Input::get('thread').')'), 400);
    }

    if ($thread->deleteThread() == false) {
      return Response::json(array('success' => false, 'errors' => 'Thread[id:'.$thread->id.']->deleteThread() failed'), 500);
    }

    Log::info('Thread[id:'.$thread->id.'] is deleted by admin');
    return Response::json(array('success' => true), 200); //OK
  }

  /**
   * Display reported threads section.
   * @return HTML code on the reported threads section.
   */
  public function getReportedThreads() {
    $threads = $this->repo->reportedThreads()->notDeleted()->paginate(10);
    echo View::make('admins.threads')->with('threads', $threads)->render();
    exit;
  }

  /**
   * Display reported posts section.
   * @return HTML code on the reported posts section.
   */
  public function getReportedPosts() {
    $posts = $this->repo->reportedPosts()->notDeleted()->ofUndeletedThread()->paginate(10);
    echo View::make('admins.posts')->with('posts', $posts)->render();
    exit;
  }

  /**
   * Display admin page index is the same as show function with his/her id.
   * @return show function
   */
  public function index() {
    return $this->show(Auth::user()->id);
  }

	/**
	 * Display admin page which he/she able to manage reported threads and posts
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id) {
		return View::make('admins.show');
	}

  /**
   * Display all events in the system with pagination.
   * @return HTML code on the event section for admin page.
   */
  public function showEvents() {
    $events = $this->repo->allEvents();
    echo View::make('admins.events')->with('events', $events)->render();
    exit;
  }

  /**
   * Verify a post by mark the verify flag to 1.
   * @return Response success if the flag is mark, fail with error message if not.
   */
  public function verifyPost() {
    $post = $this->repo->findPost(Input::get('post'));
    if (empty($post)) {
      return Response::json(array('success' => false, 'errors' => 'Invalid Post[value:'.$post.'] input("post":'.Input::get('post').')'), 400);
    }

    if ($post->verify() == false) {
      return Response::json(array('success' => false, 'errors' => 'Post[id:'.$post->id.']->verify() failed'), 500);
    }

    Log::info('Post[id:'.$post->id.'] is verified by admin');
    return Response::json(array('success' => true), 200); //OK
  }

  /**
   * Verify a thread by mark the verify flag to 1.
   * @return Response success if the flag is mark, fail with error message if not.
   */
  public function verifyThread() {
    $thread = $this->repo->findThread(Input::get('thread'));
    if (empty($thread)) {
      return Response::json(array('success' => false, 'errors' => 'Invalid Thread[value:'.$thread.'] input("thread":'.Input::get('thread').')'), 400);
    }

    if ($thread->verify() == false) {
      return Response::json(array('success' => false, 'errors' => 'Thread[id:'.$thread->id.']->verify() failed'), 500);
    }

    Log::info('Thread[id:'.$thread->id.'] is verified by admin');
    return Response::json(array('success' => true), 200); //OK
  }
}
