<?php
/**
 * This file contains the NotificationController class which acts as a 
 * controller for notifications in the system.
 * 
 * @package Notifications
 */

/**
 * This is a controller class for notifications used for sending data to the
 * notification views.
 */
class NotificationController extends \BaseController {

  /**
  * Display notifications for current user.
  *
  * This function shows the notifications page, where a user can see all her
  * notifications grouped by type and the object they refer to.
  */
  public function index(){
    // Get the active user
    $user = Auth::user();
    
    // Get the user's notification grouped by type and object
    $notifications = Notification::getGroupedNotifications($user);

    // Convert timestamp from datetime to "X hours ago" format
    foreach ($notifications as $notification) {
      $notification->timestamp = $this->timeElapsedString($notification->timestamp);
    }

    // Set all unseen messages to seen
    // (don't do this, a user must click a notification to mark as "seen")
    // Notification::where('to_user', '=', $user->id)->where('is_read', '=', 0)->update(array('is_read'=>1));

    return View::make('users.notifications')->with('user',$user)->with('notifications', $notifications);
  }

  /**
   * @deprecated Test function to generate notifications.
   */
//  public function create(){
//    $list_users = User::lists('first_name','id');
//    return View::make('users.create')->with('list_users',$list_users);
//  }
  
    /**
    * Delete all notifications that belong to the same group of notifications.
     * 
    * @return Function: index()
    */
    public function destroy()
    {
        $object_id = Input::get("obj_id");
        $object_type = Input::get("obj_type");
        $notification_type = Input::get("notif_type");
                
        DB::table('notifications')
                ->where('to_user', '=', Auth::user()->id)
                ->where('object_id', '=', $object_id)
                ->where('object_type', '=', $object_type)
                ->where('notification_type', '=', $notification_type)
                ->delete();

        return Redirect::to('notifications');
    }
  
  //This method is no longer needed, but leave it for future reference.
  // public function store(){
  //   $msg = Input::get("message");
  //   $receiver = Input::get("receiver");
  //   $data = array('message' => $msg,'receiver' => $receiver );
  //   Event::fire(UpdateScoreEventHandler::EVENT, json_encode($data));
  // }

  /**
  * Redirects the user to the correct page when she clicks on a notification
  * on the notification page.
  */
  public function redirect() {

    // Get id and type of the notification object
    $id = Input::get('id');
    $type = Input::get('type');
    
    switch($type) {
      case 'Thread' : return Redirect::action('ThreadController@show', array('id' => $id));
      break;
      // If the type is a post, we must redirict to its thread
      case 'Post' :
      $post = Post::find($id);
      $thread = $post->thread;
      return Redirect::action('ThreadController@show', array('id' => $thread->id));
    }
  }

  /**
   * Helper function to convert datetime to a "X hours ago" string.
   * 
   * @param $ptime A dateime string
   * @return A "X hours ago" string
   */
  private function timeElapsedString($ptime){

    $etime = time() - strtotime($ptime);

    if ($etime < 1){
        return '0 seconds';
    }

    $a = array( 365 * 24 * 60 * 60  =>  'year',
                 30 * 24 * 60 * 60  =>  'month',
                      24 * 60 * 60  =>  'day',
                           60 * 60  =>  'hour',
                                60  =>  'minute',
                                 1  =>  'second'
                );
    $a_plural = array( 'year'   => 'years',
                       'month'  => 'months',
                       'day'    => 'days',
                       'hour'   => 'hours',
                       'minute' => 'minutes',
                       'second' => 'seconds'
                );

    foreach ($a as $secs => $str){
        $d = $etime / $secs;
        if ($d >= 1){
            $r = round($d);
            return $r . ' ' . ($r > 1 ? $a_plural[$str] : $str) . ' ago';
        }
    }
  }

  /**
   * Get notifications for the drop-down list.
   * 
   * @return A list of notifications
   */
  public function dropdown(){
    $user = Auth::user();
    $notifications = Notification::getGroupedNotifications($user);

    foreach ($notifications as $notification) {
      $notification->timestamp = $this->timeElapsedString($notification->timestamp);
    }
    Notification::where('to_user', '=', $user->id)->where('is_read', '=', 0)->update(array('is_read'=>1));
    return $notifications;
  }
}
