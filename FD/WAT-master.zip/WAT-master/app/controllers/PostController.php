<?php
use Repositories\post\PostRepository;
/**
* What: This class is used to provide handle ajax requests from front-end and deal with post data
* Why: This class will make integration between front-end and back-end possible.
* How: This class will verify the requests' data and then decide how to handle the requests and trigger methods
*		to handle the requests accordingly.
* Use-Cases: UC03-User can like a post
* 					 UC04-User can dislike a post
*/
class PostController extends \BaseController {
	private $model;

	/**
	* Function that will check whether user is authenticate or not.
	*/
	private $authFilter = ['except' => []];


	/**
	* Function that will check whether INPUT have csrf or not. (normally all of the form will have to check this)
	*/
	private $csrfFilter = ['on' => ['store', 'update']];

	public function __construct(PostRepository $postRes) {
		$this->beforeFilter('auth', $this->authFilter);
		$this->beforeFilter('csrf', $this->csrfFilter);
		$this->model = $postRes;
	}

	/**
	 * This method can direct user to thread detail display page
	 *
	 * @return Response
	 */
	public function index(){
		return View::make('threads.index');
	}


	/**
	 * Show the form for creating a new post.
	 * @deprecated This method is not currently used as now, the requirements are changed to
	 * 	allow the user to create posts within the thread pages.
	 * @return Response
	 */

	public function create($thread_id){
		// $thread = Thread::find($thread_id);
		// if( $thread->deleted != 1 ){
		// 	return View::make('threads.addpost',compact('thread'));
		// }
		// else{
		// 	throw new Exception(Lang::get('messages.permission_deny'));
		// }
	}


	/**
	* Store the post data in the DB
	* @param  Integer(thread_id): thread id
	* @param  String($postcontent): post detail
	* @return page: show.blade.php.
	*/
	public function store(){
		if( ! $this->model->isValid(Input::all()) ){
			return Redirect::back()->withInput()->withErrors(Post::$errors);
		}

		$thread_id = Input::get('thread_id');
		$post_detail = Input::get('postcontent');
		$thread = Thread::find($thread_id);

		if( $thread->deleted != 1 ){
			$post = new Post();
			$post->createPost($post_detail,Auth::user()->id,$thread_id);
		}
		else{
			throw new Exception(Lang::get('messages.create_deny'));
		}

		//event firing for notifcation to websocket redis and nodejs
		try{
			if(Auth::user()->id != $thread->user_id){
			$body = "posts a comment on your";
			$msg = array('text' => $body, 'pic' => Auth::user()->picture_url, 'threadId' => $thread_id, 'userId' => Auth::user()->id, 'user_firstname' => Auth::user()->first_name,
				'user_lastname' => Auth::user()->last_name, 'threadtopic' => $thread->topic, 'is_event' => 0);
	        $receiver = $thread->user_id;
	        $data = array('message' => $msg,'receiver' => $receiver );
			Event::fire(UpdateScoreEventHandler::EVENT, json_encode($data));
			}
		}
		catch(\Exception $e){
			Log::error("Error Can't connect to Redis or NodeJs Server: No real-time notification created for StorePost");
		}
		Session::put('_token', sha1(microtime()));
		return Redirect::action('ThreadController@show',array('id'=>$thread_id));
	}


	/**
	* Store the post data in the DB
	* @deprecated This method is not currently used as now, the requirements are changed to
	* @return direct to thread detail display page
	*/

	public function show($id)
	{

	}


	/**
	 * Show the form for editing the specified post.
	 * @deprecated This method is not currently used as now, the requirements are changed to
	 * 	allow the user to edit their posts within the thread pages.
	 * @param  $thread_id is thread id and $post_id is post id
	 * @return Response
	 */
	public function edit($thread_id,$post_id){
		// $thread = Thread::find($thread_id);
		// $post = Post::find($post_id);
		// if ($post->user_id == Auth::user()->id && $post->deleted != 1 && $thread->deleted != 1){
		// 	return View::make('threads.editpost',compact('post','thread'));
		// }
		// return Redirect::action('ThreadController@show',array('id'=>$thread_id));
	}


	/**
	 * Update the specified post in storage.
	 *
	 * @param  Integer($thread_id): thread id
	 * @param  Integer($post_id): post id
	 * @param  String($postcontent): post detail
	 * @return String JSON: post result.
	 */
	public function update($thread_id,$post_id){
		$thread = Thread::find($thread_id);
		$detail = Input::get("postcontent");
		$post = Post::find($post_id);
		if ($post->user_id == Auth::user()->id && $post->deleted != 1 && $thread->deleted != 1 ){
			$post->udpatePost($detail);
	  }
		else{
			throw new Exception(Lang::get('messages.update_deny'));
		}
		return $post->toJson();
	}

	/**
	*	perform liking the post by a specific user
	*
	* @param Integer(posts): post id
	*
	* @return String JSON: True or False.
	*/
	public function likePost(){
		$post = Post::find(Input::get('post'));
		$thread = Thread::find($post->thread_id);
		$user = Auth::user();
		if(!$user || !$post){
			return json_encode(array('error'=>'Error'));
		}
		Log::info($user->id.'likes post '.$post->id);
		$returnPost = $user->likePost($post);

		//event firing for notifcation to websocket redis and nodejs
		try{
			if(Auth::user()->id != $post->user_id){
				$body = "likes your post on";
				$msg = array('text' => $body, 'pic' => Auth::user()->picture_url, 'threadId' => $post->thread_id, 'userId' => Auth::user()->id, 'user_firstname' => Auth::user()->first_name,
					'user_lastname' => Auth::user()->last_name, 'threadtopic' => $thread->topic, 'is_event' => 0);
		        $receiver = $post->user_id;
		        $data = array('message' => $msg,'receiver' => $receiver );
				Event::fire(UpdateScoreEventHandler::EVENT, json_encode($data));
			}
		}
		catch(\Exception $e){
			Log::error("Error Can't connect to Redis or NodeJs Server: No real-time notification created for LikePost");
		}

		return ($returnPost)?$returnPost->toJson():json_encode(array('error'=>'Error'));
	}

	/**
	* perform unliking the post by a specific user
	*
	* @param Integer(posts): post id
	* @return String JSON: True or False.
	*/
	public function unlikePost(){
		$post = Post::find(Input::get('post'));
		$user = Auth::user();
		if(!$user || !$post){
			return json_encode(array('error'=>'Error'));
		}
		Log::info('User '.$user->id.' unlikes post '.$post->id);
		$returnPost = $user->unlikePost($post);

		return ($returnPost)?$returnPost->toJson():json_encode(array('error'=>'Error'));
	}

	/**
	* perform disliking the post by a specific user
	*
	* @param Integer(posts): post id
	* @return String JSON: True or False.
	*/
	public function dislikePost(){
		$post = Post::find(Input::get('post'));
		$user = Auth::user();
		if(!$user || !$post){
			return json_encode(array('error'=>'Error'));
		}
		Log::info('User '.$user->id.' dislikes post '.$post->id);
		$returnPost = $user->dislikePost($post);
		return ($returnPost)?$returnPost->toJson():json_encode(array('error'=>'Error'));
	}

	/**
	* perform undisliking the post by a specific user
	*
	* @param Integer(posts): post id
	* @return String JSON: True or False.
	*/
	public function undislikePost(){
		$post = Post::find(Input::get('post'));
		$user = Auth::user();
		if(!$user || !$post){
			return json_encode(array('error'=>'Error'));
		}
		Log::info('User '.$user->id.' undislikes post '.$post->id);
		$returnPost = $user->undislikePost($post);
		return ($returnPost)?$returnPost->toJson():json_encode(array('error'=>'Error'));
	}

	/**
	 * Remove the specified post from storage.
	 *
	 * @param  Integer($thread_id): thread id
	 * @param  Integer($post_id): post id
	 * @return page: show.blade.page
	 */
	public function destroy($thread_id,$post_id)
	{
		//
		$post = Post::find($post_id);
		if ($post->user_id == Auth::user()->id && $post->deleted != 1 ){
			$post->deletePost($post_id);
		}
		else{
			throw new Exception(Lang::get('messages.delete_deny'));
		}

		return Redirect::action('ThreadController@show',array('id'=>$thread_id));
	}

	/**
	* Report a post from a user
	*
	* @param  Integer(posts): post id
	* @return String JSON: True or False.
	*/
	public function reportPost() {
		$post = Post::find(Input::get('posts'));
		$user = Auth::user();

		if (empty($post)){
			return Response::json(array('success'=>false, 'errors'=>'Invalid Post[value:'.Input::get('posts').']'), 400);}

		if ($post->reportBy($user))
			return Response::json(array('success'=>false, 'errors'=>'post[id:'.$post->id.']->reportBy(user[id:'.$user->id.']) failed'), 500);

		Log::info('User id:['.$user->id.'] report Post id:['.$post->id.']');
		return Response::json(array('success'=>true), 200);
	}
}
