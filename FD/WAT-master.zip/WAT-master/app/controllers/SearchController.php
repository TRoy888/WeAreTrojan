<?php
/**
* What: This class is used to provide handle ajax requests from front-end and set the seachable data back in the json format.
* Why: This class will make integration between front-end and back-end possible.
* How: This class will verify the requests' data and then decide how to handle the requests and trigger methods
*		to handle the requests accordingly.
* Use-Cases: UC02-User can search the forum
*/
class SearchController extends \BaseController {
	/**
	* This method will direct users to the search result page.
	*/
	public function index(){
		return View::make("search.search");
	}
	/**
  * Search threads/posts/users data to be shown in the search popup.
  * @param String(query_text): the query text from users
  * @return String JSON: searchable result.
  */
	public function quickSearch(){
		$query_string = Input::get('query_text');
		$searchResults = SearchUtil::quickSearch($query_string)['hits']['hits'];
		if($searchResults){
			foreach($searchResults as $key => $searchResult){
				if($searchResult['_type']=='users'){
					$searchResults[$key]['fields']['picture_url'][0] = asset($searchResult['fields']['picture_url'][0]);
				}
			}
		}
		else{
			$searchResults=[];
			$searchResults['total']=0;
		}
		return json_encode($searchResults);
		//This is left here to show an example of the json result.
		// return '[{"_index":"wat","_type":"threads","_id":"4","_score":1,"_source":{"topic":"Does Isaac Newton deserve the praise and respect he\'s been given throughout history?","detail":"I always have a common argument with my brother who believes that since a lot of Newton\'s discoveries were later proved to be incorrect and some didn\'t even have proofs to begin with that Newton is undeserving of his historical status. My brother personally believes that Euler is the greatest mind our planet has ever known. I\'m not necessarily denying that, I\'m just asking if the Quora community believes that Newton deserved the praise and respect he got throughout history for his work?","deleted":"0","like_amt":"0","dislike_amt":"0","created_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"updated_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"test_data":true}},{"_index":"wat","_type":"posts","_id":"4","_score":1,"_source":{"detail":"No, we don\'t do \"Long Sleep\" now... it\'s not a real thing. Suspended Animation is a very common Sci-Fi trope, featured in MANY movies and books: 2001, Star Wars (Carbonite), Aliens, Prometheus, Heinlien, Star Trek, Futurama .... etc. etc. The earliest reference goes back to the earliest Science Fiction ... from 1879!:","deleted":"0","like_amt":"0","dislike_amt":"0","created_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"updated_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"thread_id":"1","test_data":true}},{"_index":"wat","_type":"posts","_id":"9","_score":1,"_source":{"detail":"This is the first post detail of the fourth thread","deleted":"0","like_amt":"0","dislike_amt":"0","created_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"updated_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"thread_id":"4","test_data":true}},{"_index":"wat","_type":"posts","_id":"11","_score":1,"_source":{"detail":"This is the first post detail of the sixth thread","deleted":"0","like_amt":"0","dislike_amt":"0","created_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"updated_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"thread_id":"6","test_data":true}},{"_index":"wat","_type":"users","_id":"4","_score":1,"_source":{"email":"pamorn@usc.edu","first_name":"Pittawat","last_name":"Pamornchaisirikij","degree":"Master","school":"Architecture","summary_profile":"Graduate student","hobbies":"Gym,Travelling,Tennis","other":"I have a dog, his name is Hulk!","class":"Fall 2017","created_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"updated_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"test_data":true}},{"_index":"wat","_type":"users","_id":"9","_score":1,"_source":{"email":"ekordy@usc.edu","first_name":"Ameer","last_name":"Ekordy","degree":"Master","school":"Thornton School of Music","summary_profile":"Graduate student","hobbies":"Gym,Travelling,Tennis","other":"I have a dog, his name is Hulk!","class":"Fall 2022","created_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"updated_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"test_data":true}},{"_index":"wat","_type":"threads","_id":"5","_score":1,"_source":{"topic":"During an interview what\'s an appropriate answer when asked where do you see yourself in 5 years?","detail":"I always feel like this is a trick question. If I say what I honestly think, then I feel like I risk losing the position I\'m interviewing for if my vision does not line up with the vision of the company or the recruiter. But if I lie, and say something to the effect of what the recruiter wants to hear, then I feel that s\/he can see through that. What is an appropriate answer to this question without risking your job, and without saying something that isn\'t true to what you want in the future?","deleted":"1","like_amt":"0","dislike_amt":"0","created_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"updated_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"test_data":true}},{"_index":"wat","_type":"posts","_id":"5","_score":1,"_source":{"detail":"This is the first post detail of the second thread","deleted":"0","like_amt":"0","dislike_amt":"0","created_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"updated_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"thread_id":"2","test_data":true}},{"_index":"wat","_type":"posts","_id":"12","_score":1,"_source":{"detail":"This is the second post detail of the sixth thread","deleted":"1","like_amt":"0","dislike_amt":"0","created_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"updated_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"thread_id":"6","test_data":true}},{"_index":"wat","_type":"users","_id":"5","_score":1,"_source":{"email":"srisopha@usc.edu","first_name":"Kamonphop","last_name":"Srisopha","degree":"Ph.D","school":"Leventhal School of Accounting","summary_profile":"Graduate student","hobbies":"Gym,Travelling,Tennis","other":"I have a dog, his name is Hulk!","class":"Fall 2018","created_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"updated_at":{"date":"2015-03-07 12:20:04.000000","timezone_type":3,"timezone":"UTC"},"test_data":true}}]';
	}

	/**
  * Search threads/posts/users data to be shown in the search detail page.
  * @param String(query_text): the query text from users
	* @param String(page_number): the page number of search pagination
	* @param String(search_target): the search target whether it is users/posts/threads
  * @return String JSON: searchable result.
  */
	public function search(){
		$query_string = Input::get('query_text');
		$page_number = intval(Input::get('page_number'));
		$search_target = Input::get('search_target');
		$targets = ['threads'=>'threads','posts'=>'posts','users'=>'users'];
		$searchResults = [];
		if(!empty($targets[$search_target])){
			$searchResults = SearchUtil::search($query_string, $page_number, $targets[$search_target])['hits'];
		}
		if($searchResults){
			foreach($searchResults['hits'] as $key => $searchResult){
				if($searchResult['_type']=='users'){
					$searchResults['hits'][$key]['fields']['picture_url'][0] = asset($searchResult['fields']['picture_url'][0]);
				}
			}
		}
		else{
			$searchResults['total'] = 0;
		}
		$searchResults['page_number'] = $page_number;
		$searchResults['query_string'] = $query_string;
		return json_encode($searchResults);
	}
}
