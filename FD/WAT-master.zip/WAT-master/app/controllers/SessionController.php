<?php
/**
* What: This class is used handle login/logout functionality (create/delete sessions)
* Why: This class separated create all authentication logic from user logic.
* How: This class will redirect the user to the page responsible for each tasks and handle login/logout logic
* Use-Cases: User can login to the system
*/
class SessionController extends \BaseController {

	/**
	 * Show the login form.
	 *
	 * @return Response
	 */
	public function create()
	{
		if(Auth::check()){
			return Redirect::action('ThreadController@index');
		}
		return View::make('sessions.login');
	}

	/**
	 * Authenticate user's credentials and store user's credentials in the session.
	 *
	 * @return Response
	 */
	public function store()
	{
		Log::info(Input::only('email', 'password', 'remember'));
		$remember = Input::get('remember')=='yes'?true:false;
		Log::info($remember);
		$loginData = Input::only('email','password');
		$loginData['confirmed'] = true;
		if(Auth::attempt($loginData, $remember)){
			//change to homepage after finishing it.
			if(Auth::user()->not_first_time){
				return Redirect::action('ThreadController@index');
			}
			else{
				if (Auth::user()->firstLogin()){
					return Redirect::action('UserController@index');
				}
			}
		}
		return Redirect::route('session.create')->withErrors([Lang::get('messages.login_fail')]);
	}

	/**
	 * Remove the user's session(logout)
	 *
	 * @return Response (Redirect user to the login page.)
	 */
	public function destroy()
	{
		Auth::logout();
		Session::flush();
		return Redirect::action('SessionController@create');
	}
}
