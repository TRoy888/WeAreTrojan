<?php
use Repositories\thread\ThreadRepository;
use Carbon\Carbon;
use Repositories\post\PostRepository;
/**
* What: This class is used to provide handle ajax requests from front-end and deal with thread data
* Why: This class will make integration between front-end and back-end possible.
* How: This class will verify the requests' data and then decide how to handle the requests and trigger methods
*		to handle the requests accordingly.
* Use-Cases: UC01-User can start a thread
* Use-Cases: UC03-User can like a thread
* Use-Cases: UC04-User can dislike a thread
*/
class ThreadController extends \BaseController {

	private $model;

	/**
	* Function that will check whether user is authenticate or not.
	*/
	private $authFilter = ['except' => []];

	/**
	* Function that will check whether INPUT have csrf or not. (normally all of the form will have to check this)
	*/
	private $csrfFilter = ['on' => ['store', 'update']];

	public function __construct(ThreadRepository $threadRes) {
		$this->beforeFilter('auth', $this->authFilter);
		$this->beforeFilter('csrf', $this->csrfFilter);
		$this->model = $threadRes;
	}

	/**
	* This method will direct users to the home page.
	*/
	public function index(){

		return Redirect::action('ThreadController@indexThreadByCategory', array('allthread'));
	}

	/**
	* Show Threads in the home page. Each page max thread is 4.
	* @param  Array($threads): thread data
	* @param  String($categoryName): Category Name
	* @return page: index.blade.php.
	*/
	public function showThreads($threads,$categoryName) {
		$user = Auth::user();
		$user['rank'] = $user->rank();
		$categories = User::findCategory(Auth::user()->id);

		$threads = $threads->paginate(4);
		$users = User::orderBy('semester', 'DESC')->get()->take(10);

		foreach($users as $u){
			$u['rank'] = $u->rank();
		}
		return View::make('threads.index')->with('threads', $threads)->with('thread_categories', $categories)->with('users', $users)->with('loginUser', $user)->with('categoryName', $categoryName);
	}

	/**
	* Show all threads in the home page
	* @param  String($category_id): Category id
	* @return function: showThreads().
	*/
	public function showAllThread() {
		// category id -1 means to show all categories' threads
		$category_id = Config::get('wat/specialThread.all_thread_id') ;
		$categoryName = ThreadCategory::getCategoryNameById($category_id);
		return $this->showThreads($this->model->getAll(),$categoryName);
	}

	/**
	* Show hot threads in the home page
	* @param  String($category_id): Category Id
	* @return function: showThreads().
	*/
	public function showHotThread() {
		// category id 0 means to show hot threads
		$category_id = Config::get('wat/specialThread.hot_thread_id') ;
		$categoryName = ThreadCategory::getCategoryNameById($category_id);

		$weekThread = $this->model->findHotTopicThread(1);
		if( count($weekThread->get()) != 0 )
			return $this->showThreads($weekThread,$categoryName);

		$monthThread = $this->model->findHotTopicThread(4);
		//dd($monthThread->get());
		if( count($monthThread->get()) != 0)
			return $this->showThreads($monthThread,$categoryName);

		$yearThread = $this->model->findHotTopicThread(48);
		if( count($yearThread->get()) != 0 )
			return $this->showThreads($yearThread,$categoryName);

	}

	/**
	* Show the specific category threads by the category id
	* @param  String($category_id): Category Id
	* @return function: showThreads().
	*/
	public function indexThreadByCategory($category_id){
		if ($category_id == 'hotthread')
			return $this->showHotThread();
		else if ($category_id == 'allthread')
			return $this->showAllThread();
		$thread = $this->model->findThreadByCategory($category_id);
		$categoryName = ThreadCategory::getCategoryNameById($category_id);
		return $this->showThreads($thread,$categoryName);
	}

	/**
	* Direct to create thread page
	* @param  String($name): Category name
	* @param  Integer($id): Category id
	* @return Page: addthread.blade.php
	*/
	public function create()
	{
		//Form::setValidation(Thread::$rules);

		$categories = ThreadCategory::lists('name','id');

		return View::make('threads.addthread')->with('categories',$categories);

	}

	/**
	* Store a thread in the DB
	* @param  String($topic): Thread topic
	* @param  String($detail): Thread details
	* @param  String($category-selection): Thread categories
	* @return Function: index()
	*/
	public function store()
	{
		if( ! $this->model->isValid(Input::all()) ){
			return Redirect::back()->withInput()->withErrors(Thread::$errors);
		}
		$topic = Purifier::clean(Input::get("topic"));
		$user_id = Auth::user()->id;
		$detail = Purifier::clean(Input::get("detail"));

		$category_id = Input::get("category-selection");

		$thread = new Thread();//$this->threadRepo->create();
		$thread->createThread($topic,$detail,$category_id);
		return $this->index();
	}




	/**
	* Direct to thread detail page and show more details about the given thread
	* @param  Integer($id): Thread id
	* @return Page: show.blade.php
	*/
	public function show($id)
	{
		//$id = Crypt::encrypt($id);
		$thread = $this->model->getPostBythread($id);
		$categories = ThreadCategory::lists('name','id');
		foreach( $thread->categories as $select_category ){
			$select_cate_arr[] = $select_category->id;
		}
		return View::make('threads.show')->with('thread', $thread)->with('categories', $categories)->with('thread_categories', json_encode($select_cate_arr));
	}


	/**
	 * Show the form for editing the specified resource.
	 * @deprecated This method is not currently used as now, the requirements are changed to
	 * 	allow the user to edit their threads within the thread pages.
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{

		// $thread = Thread::find($id);
		// $categories = ThreadCategory::lists('name','id');
		//
		// $select_categories = DB::table('thread_category_thread')
		// 						->select('thread_category_thread.thread_category_id')
		// 						->where('thread_id','=',$id)->get();
		//
		// foreach( $select_categories as $select_category ){
		// 	$select_cate_arr[] = $select_category->thread_category_id;
		// }
		//
		//
		// if( $thread->user_id == Auth::user()->id && $thread->deleted != 1 ){
		// 	return View::make('threads.editthread')->with('thread',$thread)->with('categories',$categories)->with('select_categories',$select_cate_arr);
		//
		// }
		// return Redirect::action('ThreadController@index');

	}


	/**
	* Update the given thread information by thread id
	* @param  Integer($id): Thread id
	* @param  String($topic): Thread topic
	* @param  String($detail): Thread details
	* @param  String($category-selection): Thread categories
	* @return String Json: thread information with its own categories
	*/
	public function update($id){

		if( ! $this->model->isValid(Input::all()) ){
			return Redirect::back()->withInput()->withErrors(Thread::$errors);
		}

		$thread = Thread::find($id);
		$topic = Input::get("topic");
		$detail = Input::get("detail");
		$category_id = Input::get("category-selection");
		Log::debug("categories: ".json_encode($category_id));

		if( $thread->user_id == Auth::user()->id && $thread->deleted != 1){
			$thread->updateThread($topic,$detail,$category_id);
		}
		else{
			throw new Exception(Lang::get('messages.update_deny'));
		}
		return Thread::with('categories')->find($id)->toJson();
	}


	/**
	* Delete the given thread by thread id
	* @param  Integer($id): Thread id
	* @return Function: index()
	*/
	public function destroy($id)
	{
		$thread = Thread::find($id);
		if( $thread->user_id == Auth::user()->id && $thread->deleted != 1 ){
				$thread->deleteThread();
		}
		return $this->index();
	}

	/**
	* peform liking the thread by a specific user
	*
	* @param  Integer(thread): Thread id.
	* @return String Json: thread data
	*/
	public function likeThread(){
		$threadId = Input::get('thread');
		$user = Auth::user();
		Log::info($user->id." likes ".$threadId);
		$thread = Thread::find($threadId);

		if (!$user || !$thread){
			return json_encode(array('error'=>'Error'));
		}
		$resultThread = $user->likeThread($thread);

		//event firing for notifcation to websocket redis and nodejs
		try{
			if(Auth::user()->id != $thread->user_id){
				$body = "likes your thread on";
				$msg = array('text' => $body, 'pic' => Auth::user()->picture_url, 'threadId' => $threadId, 'userId' => Auth::user()->id, 'user_firstname' => Auth::user()->first_name,
					'user_lastname' => Auth::user()->last_name, 'threadtopic' => $thread->topic, 'is_event' => 0);
		        $receiver = $thread->user_id;
		        $data = array('message' => $msg,'receiver' => $receiver );
				Event::fire(UpdateScoreEventHandler::EVENT, json_encode($data));
			}
		}
		catch(\Exception $e){
			Log::error("Error Can't connect to Redis or NodeJs Server: No real-time notification created for LikeThread");
		}

		return ($resultThread)?$resultThread->toJson():json_encode(array('error'=>'Error'));
	}

	/**
	* peform unliking the thread by a specific user
	*
	* @param  Integer(thread): Thread id.
	* @return String Json: thread data
	*/
	public function unlikeThread(){
		$threadId = Input::get('thread');
		$user = Auth::user();
		Log::info($user->id.' unlikes '.$threadId);
		$thread = Thread::find($threadId);
		if(!$user || !$thread){
			return json_encode(array('error'=>'Error'));
		}
		$resultThread = $user->unlikeThread($thread);

		return ($resultThread)?$resultThread->toJson():json_encode(array('error'=>'Error'));
	}

	/**
	* peform disliking the thread by a specific user
	*
	* @param  Integer(thread): Thread id.
	* @return String Json: thread data
	*/
	public function dislikeThread(){
		$threadId = Input::get('thread');
		$user = Auth::user();
		Log::info($user->id.' dislikes '.$threadId);
		$thread = Thread::find($threadId);
		if(!$user || !$thread){
			return json_encode(array('error'=>'Error'));
		}
		$resultThread = $user->dislikeThread($thread);
		return ($resultThread)?$resultThread->toJson():json_encode(array('error'=>'Error'));
	}

	/**
	* peform undisliking the thread by a specific user
	*
	* @param  Integer(thread): Thread id.
	* @return String Json: thread data
	*/
	public function undislikeThread(){
		$threadId = Input::get('thread');
		$user = Auth::user();
		Log::info($user->id.' undislikes '.$threadId);
		$thread = Thread::find($threadId);
		if(!$user || !$thread){
			return json_encode(array('error'=>'Error'));
		}
		$resultThread = $user->undislikeThread($thread);
		return ($resultThread)?$resultThread->toJson():json_encode(array('error'=>'Error'));
	}

	/**
	 * Report the thread
	 * @param  Integer(thread): Thread id.
	 * @return String Json: True or False
	 */
	public function reportThread() {
		$thread = Thread::find(Input::get('thread'));
		$user = Auth::user();

		if (empty($thread)){
			return Response::json(array('success'=>false, 'errors'=>'Invalid Thread[value:'.$thread.']'), 400);}

		if ($thread->reportBy($user))
			return Response::json(array('success'=>false, 'errors'=>'thread[id:'.$thread->id.']->reportBy(user[id:'.$user->id.']) failed'), 500);

		Log::info('User id:['.$user->id.'] report Thread id:['.$thread->id.']');
		return Response::json(array('success'=>true), 200);
	}
}
