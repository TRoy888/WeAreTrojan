<?php
/**
 * What: UserController class responsible for handle and event about user that come from front-end
 * Why:  MVC methodology.
 * How:  This is depend on what is the event come from user but basically we will response in html or json.
 * Use-Cases: UC09-User can update his/her profile
 */
use App\Libraries\TrojanValidator as TValidator;
use Repositories\User\UserRepository;

class UserController extends BaseController {

    /**
     * User model instance.
     */
    private $model;

    /**
     * Function that will check whether user is authenticate or not.
     */
    private $authFilter = ['except' => ['store', 'create', 'confirm']];

    /**
     * Function that will check whether INPUT have csrf or not. (normally all of the form will have to check this)
     */
    private $csrfFilter = ['on' => ['update', 'updatePicture', 'updatePassword', 'updateCategories']];

    /**
     * Instantiate a new UserController Instance.
     * @param $user userRepository insatance use to get user model, normally laravel will inject EloquentUserRepository instance.
     */
    public function __construct(UserRepository $user) {
      $this->beforeFilter('auth', $this->authFilter);
      $this->beforeFilter('csrf', $this->csrfFilter);
      $this->model = $user;
    }

    /**
     * Display his/her profile page.
     * @return Response
     */
    public function index() {
        return Redirect::action('UserController@show', array(Auth::user()->id));
    }

    /**
     * Store a newly created resource in storage.
     * @return Response
     */
    public function store() {
        // Validate that email has the correct format and does not
        // already exist in the database, email and password are not blank.
        $input = Input::all();
        $input['email'] = $input['email'].'@usc.edu';
        $validate = Validator::make($input, array(
                    'firstname' => 'required|name|min:1|max:255',
                    'lastname' => 'required|name|min:1|max:255',
                    'email' => 'required|email|unique:users,email',
                    'password' => 'required|confirmed|min:8|max:255')
        );

        if ($validate->fails()) {
            return Redirect::back()->withInput()->withErrors($validate);
        } else {
            $fields = [
                'firstname' => Input::get('firstname'),
                'lastname' => Input::get('lastname'),
                'email' => Input::get('email') . '@usc.edu',
                'password' => Hash::make(Input::get('password')),
                'confirmation_code' => str_random(20),
                'picture_url' => $this->model->getDefaultProfilePicture(),
                'cover_url' => $this->model->getDefaultCoverPicture()
            ];

            $this->model->createUser($fields);

//    Mail::send('emails.confirm', ['confirmation_code' => $user['confirmation_code']], function ($message) use($fields){
//    $message->to($fields['email'], $fields['firstname'].' '.$fields['lastname'])->subject('Please confirm your email address!');
//    });

            return View::make('emails.confirm')->with('confirmation_code', $fields['confirmation_code']);
        }
    }

    /**
     * Display the user profile page.
     * @param  int  $id
     * @return Response
     */
    public function show($id) {
        $user = $this->model->find($id);
        if (!$user) {
            $user = Auth::user();
        }
        $imagesize=$this->model->getMaxProfilePictureSize(); //in bytes, this is for photo upload section
        $uinfo = $user->getProfileInformation();
        return View::make('users.profile')->with($uinfo)->with("thread_categories", $this->model->findCategory($id))->with('imagesize',$imagesize);
    }

    /**
     * Update the user profile information.
     *
     * @param  int  $id
     * @return JSON Response
     * Response error example
     * "success": false,
     * "errors": {"username": ["The username field is required."],
     *            "password": ["The password field is required."]}
     */
    public function update($id) {
        $user = Auth::user();

        if (!$user) {
            return Response::json(array(
                        'success' => false,
                        'errors' => 'No authorization')
                            , 401); //Unauthorized code
        }
        $validator = Validator::make(Input::all(), $user->getProfileFilter());
        if ($validator->fails()) {
            return Response::json(array(
                        'success' => false,
                        'errors' => $validator->getMessageBag()->toArray())
                            , 400); //Bad Request code*/
        }
        $user->saveProfileInformation(Input::all());
        return Response::json(array('success' => true), 200);
    }

    /* User email verification */

    public function confirm($confirmation_code) {

        // Get user with this confirmation code
        $user = $this->model->where('confirmation_code', $confirmation_code)->first();
        //$user = User::whereConfirmationCode($confirmation_code)->first();

        // No users found with this code, return 404
        if ((!$user)) {
            App::abort(404, 'User not found');
        }

        // Invoke User model to confirm user
        $user->confirm();

        // Return view::create login with message
        return View::make('sessions.login')->with('confirmed', true);
    }

    /**
     * Check whether image valid or not.
     * @param object $img Input file.
     * @return string: when error happen
     */
    private function checkImage($img, $maxSize) {
        $extension = $img->getClientOriginalExtension();

        if (!$img->isValid()) {
            return 'File is not valid';
        }
        if ($img->getSize() > $maxSize) {
            return "File's size exceed";
        }
        if (!$this->model->allowImageExtension($extension)) {
            return 'Only ' . $this->model->strImageExtension() . ' are allowed';
        }
    }

    /**
     * Update Profile picture into database by create cropped picture and store the path to the cropped picture in database
     * @param object $img the Laravel Input object.
     * @param int $x1 is the left x coordinate of the cropped part.
     * @param int $y1 is the bottom y coordinate of the cropped part.
     * @param int $x2 is the right x coordinate of the cropped part.
     * @param int $y2 is the top y coordinate of the cropped part.
     * @return string of the new profile picture url: when success.
     */
    private function updateProfilePicture($img, $x1, $y1, $x2, $y2) {
        $user = Auth::user();
        $uid = uniqid($user->id);
        $fpath = $this->model->getProfilePicturePath() . '/' . $uid;
        $furl = $this->model->getProfilePictureURL() . '/' . $uid;
        $image = Image::make($img->getPathname());
        $image->crop(round($x2 - $x1), round($y2 - $y1), round($x1), round($y1));
        $image->resize(200, 200);
        $image->save($fpath);
        $user->saveProfilePicture($furl);
        return $furl;
    }

    /**
     * Update Cover picture into database by create cropped picture and store the path to the cropped picture in database
     * @param object $img the Laravel Input object.
     * @param int $x1 is the left x coordinate of the cropped part.
     * @param int $y1 is the bottom y coordinate of the cropped part.
     * @param int $x2 is the right x coordinate of the cropped part.
     * @param int $y2 is the top y coordinate of the cropped part.
     * @return string of the new cover picture url: when success.
     */
    private function updateCoverPicture($img, $x1, $y1, $x2, $y2) {
        $user = Auth::user();
        $uid = uniqid($user->id);
        $fpath = $this->model->getCoverPicturePath() . '/' . $uid;
        $furl = $this->model->getCoverPictureURL() . '/' . $uid;
        $image = Image::make($img->getPathname());
        $image->crop(round($x2 - $x1), round($y2 - $y1), round($x1), round($y1));
        $image->resize(1170, null, function ($constraint) {
          $constraint->aspectRatio();
        });
        $image->save($fpath);
        $user->saveCoverPicture($furl);
        return $furl;
    }

    /**
     * Update profile picture via ajax
     * Input structure
     * ["x1"          => Smaller X coordinate,
     *  "y1"          => Smaller Y coordinate,
     *  "x2"          => Larger X coordinate,
     *  "y2"          => Larger Y coordinate,
     *  "image_file"  => The image file,]
     * @return Response success or fail with error message.
     */
    public function updatePicture() {
        $strImage = 'image_file';
        $validator = Validator::make (Input::all(), array(
          'image_file' => Config::get('wat/users.filter_pic_profile')
        ));

        if ($validator->fails()) {
          return Response::json(array(
            'success' => false,
            'errors'  => $validator->getMessageBag()->toArray()), 400
          );
        }
        $file = Input::file('image_file');

        if (Input::get('inputtype') == 'profile') {
            $url = $this->updateProfilePicture($file, Input::get('x1'), Input::get('y1'), Input::get('x2'), Input::get('y2'));
        } else {
            $url = $this->updateCoverPicture($file, Input::get('x1'), Input::get('y1'), Input::get('x2'), Input::get('y2'));
        }

        return Response::json(array('success' => true,'url' => $url), 200); //OK
    }

    /**
     * Update user password via AJAX
     * Input structure
     * ["oldpassword"         => Current password,
     *  "newpassword"         => New password,
     *  "txtConfirmPassword"  => Confirm new password]
     * @return Response success or fail with with error message.
     */
    public function updatePassword() {
        $user = Auth::user();

        if (!Hash::check(Input::get('oldpassword'), $user->password)) {
            return Response::json(array('success' => false,'errors' => 'Incorrect password'), 400); //Bad Request
        }
        $user->savePassword(Input::get('newpassword'));
        return Response::json(array('success' => true), 200);
    }

    /**
     * Update user's favorite categories
     * Input in from of json
     *  {
     * 		'set':[cat1_id, cat2_id, cat3_id],
     *    'reset':[cat4_id, cat5_id, cat6_id]
     *  }
     * @return json response success or error if fail.
     */
    public function updateCategories() {
        $input = Input::json();
        $user = Auth::user();
        $user->insertCategory($input->get('set'));
        $user->deleteCategory($input->get('reset'));
        return Response::json(array('success' => true), 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create() {
        return View::make('users.registration');
    }

    public function resetPassword() {
        // Validate that email has the correct format and already
        // exists in the database.
        $validate = Validator::make(Input::all(), array(
                    'email' => 'required|usc_email|exists:users,email'
                        )
        );

        if ($validate->fails()) {
            return Redirect::back()->withErrors($validate);
        } else {
            Session::flash('message', "A password reset link has been sent to your USC e-mail.");
            return Redirect::back();
        }
    }

    /**
     * This method gets called from Ajax /see_notification, it will set the user has_seen_notifcation to true
     *
     * @return Response
     */
    public function updateSeeNotification(){
        $user = Auth::user();
        $user->seeNotification();
        return Response::json(array('success' => true), 200);
    }

}
