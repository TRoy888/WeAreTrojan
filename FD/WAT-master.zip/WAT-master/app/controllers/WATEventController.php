<?php

use Repositories\WATEvent\WATEventRepository;
/**
* What: This class is used to provide handle ajax requests from front-end and deal with event data
* Why: This class will make integration between front-end and back-end possible.
* How: This class will verify the requests' data and then decide how to handle the requests and trigger methods
*		to handle the requests accordingly.
*/
class WATEventController extends \BaseController {
	private $authFilter = ['except' => []];
	private $repo;

	public function __construct(WATEventRepository $repo) {
		$this->beforeFilter('auth', $this->authFilter);
    $this->repo = $repo;
	}

	/**
	 * Display the event calendar page that contain all of the events.
	 * @return Events calendar view.
	 */
	public function index()
	{
	  $events = $this->repo->all();
	  return View::make('events.event')->with('eventData', $events);
		//
	}

	public function display(){
		$eventData = watEvent::all();
		return View::make('events.event')->with('eventData',$eventData);
	}

	/**
	 * Show the form for creating a event.
	 * @return Response
	 */
	public function create()
	{
		echo View::make('events.create');
		exit;
	}

//-----------HELPER---------------------------------------------
/**
* get event picture path
* @return String: event picture path.
*/
private function getEventPicturePath() {
	$path = public_path().'/images/event_pic';
	if (!file_exists($path)) {
		mkdir($path, 0777, true);
	}
	return $path;
}

/**
* get event picture url
* @return String: event picture url
*/
private function getEventPictureURL() {
	return '/images/event_pic';
}

/**
* get picture url
* @param  File($file): file of the picture
* @param  Integer($x): the begining x point
* @param  Integer($y): the begining y point
* @param  Integer($width): the width of crop picture
* @param  Integer($hight): the height of crop picture
* @return String: picture url
*/
private function getURLOfPicture($file, $x, $y, $width, $hight) {
	$fname = uniqid(Auth::user()->id);
	$fpath = $this->getEventPicturePath().'/'.$fname;
	$furl = $this->getEventPictureURL().'/'.$fname;
	$image = Image::make($file);
	$image->crop($width, $hight, $x, $y);
	$image->resize(450, 350);
	$image->save($fpath);
	return $furl;
}

/**
* notify all users the event
* @param  Array($event): event data
*/
private function broadcastEvent($event) {
	$sender = Auth::user();
	$users = User::all();
	$body = "created an event";
	$msg = array(
		'text'=>$body,
		'pic'=>$event->picture,
		'userId'=>$sender->id,
		'user_firstname'=>$sender->first_name,
		'user_lastname'=>$sender->last_name,
		'threadtopic'=>$event->topic,
		'is_event'=>1);
	foreach ($users as $receiver)
	{
		$data = array('message'=>$msg, 'receiver'=>$receiver->id);
		Event::fire(UpdateScoreEventHandler::EVENT, json_encode($data));
	}
}
//--------------------------------------------------------------


	/**
	 * Store a new event into database.
	 * @param  File($event_picture): file of the picture
	 * @param  Integer($image_x): the begining x point
	 * @param  Integer($image_y): the begining y point
	 * @param  Integer($image_width): the width of crop picture
	 * @param  Integer($image_hight): the height of crop picture
	 * @return Response
	 */
	public function store()
	{
		$inputs = Input::all();
		$rules = [
			'topic' => 'required|min:5',
			'location' => 'required|min:10',
			'start_time' => 'required|date|after:now',
			'end_time' => 'required|date|after:'.Input::get('start_time'),
			'point_for_joining' => 'required|integer|min:0',
			'details' => 'required|min:5',
			'event_picture' => 'required|image|max:5000'];
		$validator = Validator::make($inputs, $rules);
		if ($validator->fails())
		{
			return Response::json(array(
				'success'=>false,
				'errors'=>$validator->getMessageBag()->toArray()), 400);
		}
		$inputs['user_id'] = Auth::user()->id;
		$inputs['event_picture'] = $this->getURLOfPicture(
				Input::file('event_picture')
				, Input::get('image_x')
				, Input::get('image_y')
				, Input::get('image_width')
				, Input::get('image_hight'));
		$inputs['start_time'] = date('Y-m-d H:i:s', strtotime($inputs['start_time']));
		$inputs['end_time'] = date('Y-m-d H:i:s', strtotime($inputs['end_time']));
		$event = $this->repo->createWATEvent($inputs);
		try{
		$this->broadcastEvent($event);
		}
		catch(\Exception $e){
			Log::error("Error Can't connect to Redis or NodeJs Server: No real-time notification created for createEvent");
		}
		return Response::json(array('success'=>true), 200);
	}
		/*
		THIS IS AN EXAMPLE OF HOW TO FIRE A NOTIFICATION EVENTS
		if(Auth::user()->id != $thread->user_id){
			$body = "create an event".event time here;
			$msg = array('text' => $body, 'pic' =>ev.pic, , 'userId' => creater->id, 'user_firstname' => Auth::user()->first_name,
				'user_lastname' => Auth::user()->last_name, 'threadtopic' => $event->topic , 'is_event' => 1);
					$receiver = $thread->user_id;
					$data = array('message' => $msg,'receiver' => $receiver );
			Event::fire(UpdateScoreEventHandler::EVENT, json_encode($data));
		}
		*/
		//return Response::json(array('success'=>false, 'errors'=>'this is errmsg'), 400);
		//return Response::json(array('success'=>true), 200);

	/** We can not go to specific event page Right now.
	 * Display the specified resource.
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{

	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//
	}


	/**
	 * Update the event information in database.
	 *
	 * @param  Integer($id): Event id
	 * @return Page: event.blade.php
	 */
	public function update($id)
	{
		$watEvent = watEvent::find($id);
		$fields = [
				'topic' => 'EventUpdated',
				'location' => '3Y',
				'start_time' => '2015-03-29T16:00:00',
				'end_time' => '2015-03-31T16:00:00',
				'detail' => 'Detail1',
				'picture' => 'none',
				'notification_time' => '2015-03-31T16:00:00',
				'point_for_joining' => 20
		];
		$watEvent->updateWATEvent($fields);
		return View::make('event.event');
	}


	/**
	 * Remove the given event from database.
	 *
	 * @param  Integer($id): Event id
	 * @return Page: event.blade.php
	 */
	public function destroy($id)
	{
		$watEvent = watEvent::find($id);
		$watEvent->deleteWATEvent();
		return View::make('event.event');
	}


}
