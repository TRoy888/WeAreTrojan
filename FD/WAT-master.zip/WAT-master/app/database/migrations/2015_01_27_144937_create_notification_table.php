<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateNotificationTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('notifications', function($table){
			$table->increments('id');
			$table->string('message');
			$table->timestamp('time');
			$table->boolean('is_read');
			$table->string('notification_type');
			$table->integer('object_id')->unsigned();
			$table->string('object_type');
			$table->integer('to_user')->unsigned();
			$table->integer('from_user')->unsigned();
			$table->boolean('is_seen')->default(false);
			$table->timestamps(); //created_at and updated_at
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('notifications');
	}

}
