<?php

class UserRolesSeeder extends BasedSeeder {

	public function __construct(){
		$this->table = 'user_roles'; // Your database table name
		$this->filename = app_path().'/database/csv/user_roles.csv'; // Filename and location of data in csv file
	}
	//See more at: http://laravelsnippets.com/snippets/seeding-database-with-csv-files-cleanly#sthash.6Zfbzl7A.dpuf

}
