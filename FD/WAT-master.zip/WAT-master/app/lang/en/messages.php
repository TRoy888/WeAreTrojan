<?php
return array(
  'login_fail' => 'Could not log in. Verify that e-mail and password is correct.',
  'permission_deny' => 'Error!!! The user has no permission to perform such an action.',
  'update_deny' => 'Error!!! The user has no permission to update',
  'delete_deny' => 'Error!!! The user has no permission to delete',
  'no_data'=>'The data is not reachable'
);
