<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Libraries;

use Illuminate\Validation\Validator as IValidator;

/**
 * TrojanValidator is an extension of the Laravel Validator class.
 * It provides custom validation functions.
 * 
 * @author Eirik Skogstad
 */
class TrojanValidator extends IValidator {
    private $_custom_messages = array(
        "name" => "Names may only contain letters, spaces and dashes",
        "usc_email" => "Invalid USC email."
    );
    
    public function __construct($translator, $data, $rules, $messages = array(), $customAttributes = array()) {
        //$this = IValidator::make($data, $rules);
    parent::__construct($translator, $data, $rules, $messages, $customAttributes);
        
        $this->_set_custom();
    }
    
    protected function _set_custom() {
        // Set custom error messages
        $this->setCustomMessages($this->_custom_messages);
    }
    
    /* CUSTOM VALIDATION FUNCTIONS */
    
    /**
     * Validate that name contains only letters, spaces and dashes.
     */
    protected function validateName($attribute, $value) {
        return (bool) preg_match("/^[A-Za-z\s-]+$/", $value );
    }
    
    /**
     * Validate usc email address.
     */
    protected function validateUscEmail($attribute, $value) {
        return (bool) preg_match("/^[0-9\.a-z_-]+$/", $value );
    }
}
