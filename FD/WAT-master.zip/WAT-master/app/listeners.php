<?php

Event::listen(UpdateScoreEventHandler::EVENT, 'UpdateScoreEventHandler');