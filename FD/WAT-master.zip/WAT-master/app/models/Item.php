<?php

class Item extends Eloquent{
  /**
  * The database table used by the model.
  *
  * @var string
  */
  protected $table = 'items';


  public function findItem()
  {

  }

  public function createItem()
  {
    return $this->save();
  }

  public function updateItem()
  {

  }

  public function deleteItem()
  {

  }


}
