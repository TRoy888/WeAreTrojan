<?php

class ItemCategory extends Eloquent{
  /**
  * The database table used by the model.
  *
  * @var string
  */
  protected $table = 'item_categories';


  public function findCategory()
  {

  }

  public function createCategory()
  {
    return $this->save();
  }

  public function updateCategory()
  {

  }

  public function deleteCategory()
  {

  }


}
