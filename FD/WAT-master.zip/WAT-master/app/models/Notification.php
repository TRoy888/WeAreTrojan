<?php
/**
 * This file contains the Notification class which represents a notification 
 * in the system. Win conditions grouped under the "Notification system" 
 * category specify how users can see and operate on notifications. The primary
 * purpose of the notifications is to let a user know if someone has commented 
 * on her thread, liked her thread or post etc.
 * 
 * Currently, notifications are created when:
 * - A new post is added to a thread (thread author is notified)
 * - A user clicks 'like' on a thread (thread author is notified)
 * - A user clicks 'like' on a post (post author is notified)
 * 
 * Notifications can be seen in a drop-down list from the navigation bar, or
 * in the notifications page. Notifications will also appear as messages in the 
 * bottom-left corner of the screen when the user is logged in.
 * 
 * @see Notification
 * @package Notifications
 */

/**
 * This class serves as a model for notifications in the system. It handles
 * generation, removal and retrieval of notifications to and from the storage.
 * 
 * New notifications should be created by calling the appropriate function in 
 * this class that will generate and store a notification based on its type
 * (e.g. Notification::likeThread()). Notifications can also be customized with
 * the functions that have a "set" prefix. A notification should be removed by
 * calling Notification::removeNotification() which will take care of the 
 * deletion.
 */
class Notification extends Eloquent {
    
    /**
     * Notification type string that identifies "liking" notifications.
     */
    const NOTIF_TYPE_LIKE = 'Like';
    /**
     * Notification type string that identifies "new comment" notifications.
     */    
    const NOTIF_TYPE_POST = 'Post';
    /**
     * Notification type string that identifies "new event" notifications.
     */      
    const NOTIF_TYPE_EVENT = 'Event';

    /**
     * The database table used by the model.
     */
    protected $table = 'notifications';

    /**
     * Delete a notification by id.
     *
     * @param type $notif_Id The notification id
     */
    public function deleteNotification($notif_Id) {
        $notification = Notification::find($notif_Id);
        $notification->delete();
    }

    /**
     * Get the user this notification belongs to, i.e. the receiver of the 
     * notification.
     *
     * @return User The user who received the notification
     */
    public function user() {
        return $this->belongsTo('User', 'to_user');
    }

    /**
     * Get the user this notification is sent from, i.e. the user who triggered 
     * the notification.
     *
     * @return User The user who triggered the notification
     */
    public function sender() {
        return $this->belongsTo('User', 'from_user');
    }

    /**
     * Specify the object that this notification is connected to (e.g. thread, 
     * post, event). This will set two columns in the database: object_id which 
     * contains the numeric id of the object (e.g. thread id) and object_type 
     * which contains the name of the object class (to determine the type of 
     * the object, e.g. 'Thread').
     *
     * @param $object The object this notification is associated to.
     * @return Notification The notification.
     */
    public function setObject($object) {
        $this->object_id = $object->id;
        $this->object_type = get_class($object);
        return $this;
    }

    /**
     * Specify the notification type, e.g. 'Like' or 'Comment'. This helps 
     * separate different events happening on the same object (e.g. thread) so
     * that notifications can be grouped by their type.
     * 
     * All valid notification types are specified as constants in the 
     * Notification class.
     *
     * @param string $type The notification type. Should always be a valid type
     * specified in the Notification class.
     * 
     * @return Notification The notification.
     */
    public function setType($type) {
        $this->notification_type = $type;
        return $this;
    }

    /**
     * Specify the message that the user will see for this notification,
     * e.g. "User X likes your thread".
     *
     * @param string $message The notification message
     * @return Notification The notification
     */
    public function setMessage($message) {
        $this->message = $message;
        return $this;
    }

    /**
     * Specify whether the notification has been seen by the user or not.
     * 
     * @param bool $seen True if the notification has been seen, false if not.
     * @return Notification The notification
     */
    public function setIsSeen($seen) {
        $this->is_seen = $seen;
        return $this;
    }

    /**
     * Specify which user the notification comes from, i.e. the sender.
     * If the notification is a 'Like', this will be the user who 'liked'.
     *
     * @param int $sender
     * @return Notification
     */
    public function setSender($sender) {
        $this->sender()->associate($sender);
        return $this;
    }

    /**
     * Store the notification.
     * 
     * @return Notification The notification
     */
    public function send() {
        $this->save();
        return $this;
    }

    /**
     * Remove a notification.
     * 
     * @param $object The object that the notification refers to
     * @param User $sender The user who triggered the notification
     * @param $notificationType The notification type
     */
    public static function removeNotification($object, $sender, $notificationType) {
        Log::debug('Undo notification of type '.$notificationType.' with obj id '.$object->id.' class '.get_class($object).' to user '.$object->user->id);

        if ($object instanceof Post && $notificationType == Notification::NOTIF_TYPE_POST) {
            $toUser = $object->thread->user;
            Log::debug('is post:'.$toUser);
        } else {
            Log::debug('is NOT post');
            $toUser = $object->user->id;
        }

        DB::table('notifications')->where('notification_type', '=', $notificationType)
                ->where('object_id', '=', $object->id)
                ->where('object_type', '=', get_class($object))
                ->where('to_user', '=', $toUser)
                ->where('from_user', '=', $sender->id)
                ->orderBy('created_at', 'desc')
                ->take(1)
                ->delete();
    }    
    
    /**
     * Generate and store a notification when a user likes a thread.
     * 
     * @param type $thread The thread that was liked
     * @param type $user The user who liked the thread
     */
    public static function likeThread($thread, $user) {
        // Create a new notification
        $notification = new Notification();
        
        // Associate the notification with the thread author, set properties
        // and send the notification.
        $thread->user->addNotification($notification)
                ->setObject($thread)
                ->setType(self::NOTIF_TYPE_LIKE)
                ->setMessage("liked your thread '" . $thread->topic . "'.")
                ->setSender($user)
                ->send();
    }

    /**
     * Generate and store a notification when a user likes a post.
     * 
     * @param type $post The post that was liked
     * @param type $user The user who liked the post
     */    
    public static function likePost($post, $user) {
        // Get the topic of the thread which this post belongs to
        $topic = $post->thread->topic;

        // Create a new notification
        $notification = new Notification();

        // Associate the notification with the post author, set properties
        // and send the notification.        
        $post->user->addNotification($notification)
                ->setObject($post)
                ->setType(self::NOTIF_TYPE_LIKE)
                ->setMessage("liked your post in the thread '" . $topic . "'.")
                ->setSender($user)
                ->save();
    }

    /**
     * Generate and store a notification when a user creates a post in a thread.
     * 
     * @param type $post The post that was authored
     * @param type $user The user who authored the post
     */     
    public static function commentThread($post, $user) {
        // Get the thread this post belongs to
        $thread = $post->thread;

        // Create a new notification
        $notification = new Notification();        
        
        // Associate the notification with the thread author, set properties
        // and send the notification.          
        $thread->user->addNotification($notification)
                ->setObject($post)
                ->setType(self::NOTIF_TYPE_POST)
                ->setMessage("commented on your thread '" . $thread->topic . "'.")
                ->setSender($user)
                ->save();
    }

    /**
     * Get the notifications of a user grouped by notification type and object.
     * 
     * The notification messages will be customized based on the number of users
     * who triggered a notification of the same type on the same object:
     * 
     * 1 user:      "Tom Riddle liked your thread ..." 
     * 2 users:     "Tom Riddle and Draco Malfoy liked your thread ..."
     * >2 users:    "Tom Riddle and 34 others liked your thread ..."
     *
     * @param type $user The receiving user of the notifications
     * @return A collection set of the result of the database query.
     */
    public static function getGroupedNotifications($user){

        return DB::table('notifications')->select('notification_type', 'message', 'object_id', 'object_type', 'is_read', 'from_user', 'users.picture_url',
                DB::raw('MAX(notifications.created_at) as timestamp'),
                DB::raw("case
                when count(DISTINCT(notifications.from_user)) = 1 then CONCAT(users.first_name,' ',users.last_name)
                when count(DISTINCT(notifications.from_user)) = 2 then GROUP_CONCAT(users.first_name, ' ', users.last_name SEPARATOR ' and ')
                when count(DISTINCT(notifications.from_user)) > 2 then CONCAT(users.first_name,' ', users.last_name, ' and ', count(distinct(notifications.from_user))-1, ' others' )
                end as sender_string"))
                ->join('users', 'users.id', '=', 'notifications.from_user')
                ->where('to_user', '=', $user->id)
                ->groupBy('notification_type', 'object_id', 'object_type')
                ->orderBy('timestamp', 'desc')
                ->get();
    }
}
