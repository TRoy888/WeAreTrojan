<?php

class Post extends Eloquent
{

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'posts';

    protected $fillable = ['postcontent'];
    public static $rules = [
        'postcontent' => 'required| min:10',
    ];
    public static $errors;

    public static $messages = [
        'postcontent.required' => 'Post contents is required',
        'postcontent.min' => 'Post contents can not less than 10 characters',
        'postcontent.max' => 'Post contents can not more than 255 characters'
    ];

    public function findPost()
    {

    }

    /**
     *   Validate a post content
     *
     */
    public static function isValid($data)
    {
        $validation = Validator::make($data, static::$rules, static::$messages);

        if ($validation->passes()) return true;

        static::$errors = $validation->messages();

        return false;
    }

    // /**
    // * Get information of like or dislike status for a post
    // *
    // */
    // public function getPostLike($post_id){
    //     $postInfo = DB::table("post_user")->where('post_id','=',$post_id)->get();
    //     return json_encode($postInfo);
    // }

    // /**
    // * Get users information for each post
    // *
    // */
    // public function getUserEachPost($post_id){
    //   $post = Post::with('user')->find($post_id);
    //   return $post->User;
    // }

    /**
     * Create Post
     *
     */
    public function createPost($detail, $user_id, $thread_id)
    {
        //save in posts table
        $this->detail = $detail;
        $this->user_id = $user_id;
        $this->number_of_report = 0;
        $this->verification_mark = 0;
        $this->thread_id = $thread_id;
        $this->is_pending = 1;
        $this->deleted = 0;
        $this->like_amt = 0;
        $this->dislike_amt = 0;
        $this->search_updated = true;
        $this->save();

        //add a post document to the Elastic server.
        try {
            SearchUtil::addPost($this);
        } catch (Exception $e) {
            Log::error('Post.php "createPost" Error when making an attempt to create a document in Elasticsearch: ' . $e->getMessage());
            $this->search_updated = false;
            $this->save();
        }

        // Add notification
        Notification::commentThread($this, Auth::user());

        return $this;

    }


    /**
     * Report post
     * Added by Pittawat
     */
    public function reportBy($user)
    {
        $this->number_of_report++;
        $this->save();
        return;
    }

    /**
     * Update Post
     *
     * @return Post
     */
    public function udpatePost($detail)
    {
        //only update in posts table
        $this->detail = $detail;
        $this->search_updated = true;
        $this->save();

        //update a post document in the Elastic server.
        try {
            SearchUtil::editPost($this);
        } catch (Exception $e) {
            Log::error('Post.php "updatePost" Error when making an attempt to change an updated document in Elasticsearch: ' . $e->getMessage());
            $this->search_updated = false;
            $this->save();
        }

        return $this;
    }

    /**
     * Delete Post
     *
     */
    public function deletePost()
    {
        //delete in posts table
        $this->deleted = 1;
        $this->search_updated = true;
        $this->save();

        /*
        * Remove point from the owner of the deleted posts.
        * There will be two cases that posts are deleted
        * 1. the owner of the user delete their own posts
        * 2. the maintainers decide that the posts are violating the system rules and delete the posts.
        * For Both cases, the points the owner get from such a post will be cleared out.
        * Remark: the reason why we need to requery a post before calculate the points
        *           because there may be a case when another user gives like or dislike to a post during an overlapped time that the owner clicks "delete"
        *           and the time when the posts are actually marked as deleted.
        */
        $deletedPost = Post::where("deleted","=",true)->find($this->id);
        if(!empty($deletedPost)){
          $currentPoint = $deletedPost->calculatePoint();
          $author = $deletedPost->author;
          $author->addLifePoint(-$currentPoint);
          $author->addSemesterPoint(-$currentPoint);
          if($deletedPost->is_pending){
            $author->addPendingPoint(-$currentPoint);
          }
          else{
            $author->addUsablePoint(-$currentPoint);
          }
          $author->save();
        }

        //delete a post document to the Elastic server.
        try {
            SearchUtil::deletePost($this);
        } catch (Exception $e) {
            Log::error('Post.php "deletePost" Error when making an attempt to remove a deleted document from Elasticsearch: ' . $e->getMessage());
            $this->search_updated = false;
            $this->save();
        }

        // Remove notification
        Notification::removeNotification($this, Auth::user(), Notification::NOTIF_TYPE_POST);

        return true;
    }

    /**
     * Calculate point of the post by it like_amt and dislike_amt data in the database corresponding with configured data
     *
     * @return int (points calculated)
     */
    private function calculatePoint()
    {
        Log::debug('calculate: ' . $this->like_amt . ' * ' . intVal(Config::get('wat/wat_point.like_point')) . ' - ' . $this->dislike_amt . ' * ' . intVal(Config::get('wat/wat_point.dislike_point')));
        $pointDiff = $this->like_amt * intval(Config::get('wat/wat_point.like_point')) - $this->dislike_amt * intval(Config::get('wat/wat_point.dislike_point'));
        return ($pointDiff > 0) ? $pointDiff : 0;
    }

    /**
     * update like_amt of the post by the user's liking action
     *
     */
    public function addLike()
    {
        $currentPoint = $this->calculatePoint();
        $this->like_amt += 1;
        $this->save();
        $newPoint = $this->calculatePoint();
        $pointDiff = $newPoint - $currentPoint;

        Log::debug('addlike: currentPoint ' . $currentPoint);
        Log::debug('addlike: newPoint ' . $newPoint);
        Log::debug('addlike: pointDiff ' . $pointDiff);

        $author = $this->author;
        $author->addLifePoint($pointDiff);
        $author->addSemesterPoint($pointDiff);
        if ($this->is_pending) {
            $author->addPendingPoint($pointDiff);
        } else {
            $author->addUsablePoint($pointDiff);
        }
        $author->save();
    }

    /**
     * update like_amt of the post by the user's unliking action
     *
     */
    public function unlike()
    {
        $currentPoint = $this->calculatePoint();
        $this->like_amt -= 1;
        $this->save();
        $newPoint = $this->calculatePoint();
        $pointDiff = $newPoint - $currentPoint;

        Log::debug('unlike: currentPoint ' . $currentPoint);
        Log::debug('unlike: newPoint ' . $newPoint);
        Log::debug('unlike: pointDiff ' . $pointDiff);

        $author = $this->author;
        $author->addLifePoint($pointDiff);
        $author->addSemesterPoint($pointDiff);
        if ($this->is_pending) {
            $author->addPendingPoint($pointDiff);
        } else {
            $author->addUsablePoint($pointDiff);
        }
        $author->save();
    }

    /**
     * update dislike_amt of the post by the user's disliking action
     *
     */
    public function addDislike()
    {
        $currentPoint = $this->calculatePoint();
        $this->dislike_amt += 1;
        $this->save();
        $newPoint = $this->calculatePoint();
        $pointDiff = $newPoint - $currentPoint;

        Log::debug('Dislike: currentPoint ' . $currentPoint);
        Log::debug('Dislike: newPoint ' . $newPoint);
        Log::debug('Dislike: pointDiff ' . $pointDiff);

        $author = $this->author;
        $author->addLifePoint($pointDiff);
        $author->addSemesterPoint($pointDiff);
        if ($this->is_pending) {
            $author->addPendingPoint($pointDiff);
        } else {
            $author->addUsablePoint($pointDiff);
        }
        $author->save();
    }

    /**
     * update dislike_amt of the post by the user's undisliking action
     *
     */
    public function undislike()
    {
        $currentPoint = $this->calculatePoint();
        $this->dislike_amt -= 1;
        $this->save();
        $newPoint = $this->calculatePoint();
        $pointDiff = $newPoint - $currentPoint;

        Log::debug('unDislike: currentPoint ' . $currentPoint);
        Log::debug('unDislike: newPoint ' . $newPoint);
        Log::debug('unDislike: pointDiff ' . $pointDiff);

        $author = $this->author;
        $author->addLifePoint($pointDiff);
        $author->addSemesterPoint($pointDiff);
        if ($this->is_pending) {
            $author->addPendingPoint($pointDiff);
        } else {
            $author->addUsablePoint($pointDiff);
        }
        $author->save();
    }

    public function verify()
    {
      $this->verification_mark = 1;
      $this->save();
      return true;
    }

    ////////////////////////////////////////////Relationship tables//////////////////////////////////////////////////
    /**
     * get author of the post
     *
     * @return User
     */
    public function author()
    {
        return $this->belongsTo('User', 'user_id');
    }
    
    /**
     * Get the thread which this post belongs to.
     * 
     * @return Thread The thread this post belongs to
     */
    public function thread()
    {
        return $this->belongsTo('Thread', 'thread_id');
    }
    
    /**
     * Get the user which this post is authored by.
     * 
     * @return User The user this post belongs to
     */    
    public function user()
    {
        return $this->belongsTo('User');
    }

    /**
     * Do further query from post query by scope down only reported post.
     * @return $query with only reported post.
     */
    public function scopeReported($query) {
      return $query->where('posts.number_of_report', '>', 0)->where('posts.verification_mark', 0);
    }

    public function scopeOfUndeletedThread($query) {
      return $query->join('threads', 'posts.thread_id', '=', 'threads.id')->where('threads.deleted',0)->select('posts.*');
    }

    /**
     * Do further query from post query by scope down only the undeleted post.
     * @return $query with only undeleted post.
     */
    public function scopeNotDeleted($query) {
      return $query->where('posts.deleted', 0);
    }
    ////////////////////////////////////////////Admin Functions//////////////////////////////////////////////////
    /**
     * get all the post information that are reported in number of reported descending order
     *
     * @param
     * @return Thread object
     */
    public function adminGetAllReportedPosts()
    {
        $posts = DB::table('Posts')
            ->where('posts.number_of_report', '>', 0)
            ->orderBy('number_of_report', 'desc');

        return $posts;
    }

    /**
     * Admin delete the reported thread
     *
     */
    public function adminDeleteReportedPost($post_id)
    {
        // delete from thread table
        $posts = Post::find($post_id);
        $posts->deleted = 1;
        $posts->search_updated = true;
        $posts->save();
        try {
            SearchUtil::deletePost($posts);
        } catch (Exception $e) {
            Log::error('Thread.php "deleteThread" Error when making an attempt to remove a deleted document from Elasticsearch: ' . $e->getMessage());
            $posts->search_updated = false;
            $posts->save();
        }
    }

    /**
     * Admin approve the reported thread
     *
     */
    public function adminApproveReportedPost($post_id)
    {
        $posts = Post::find($post_id);
        $posts->number_of_report = 0;
        $posts->save();
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
