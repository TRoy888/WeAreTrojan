<?php
use Carbon\Carbon;

class Thread extends Eloquent
{

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'threads';
    protected $fillable = ['topic', 'detail'];
    public static $rules = [
        'topic' => 'required | min:10',
        'detail' => 'required| min:25 ',
        'category-selection' => 'required'
    ];
    public static $errors;

    public static $messages = [
        'topic.required' => 'Topic is required',
        'topic.min' => 'Topic content can not less than 10 characters',
        'topic.exists' => 'Your topic is duplicated',
        'detail.required' => 'Detail is required',
        'detail.min' => 'Detail content can not less than 25 characters',
        'detail.max' => 'Detail content can not excceed 255 characters',
        'category-selection.required' => 'Category field is required'
    ];


    /**
     * Count the number of post based on the given thread_id
     * @param $thread_id is thread id
     * @return the total number of post in the given thread
     */

    public static function countPost($thread_id)
    {
        // only count those posts which deleted tag is 0
        $numberOfPost = Thread::find($thread_id)->post()->where('deleted','=','0')->get()->count();
        return $numberOfPost;
    }


    /**
     *   Validate a thread content
     *
     */
    public static function isValid($data)
    {
        $validation = Validator::make($data, static::$rules, static::$messages);

        if ($validation->passes()) return true;

        static::$errors = $validation->messages();

        return false;
    }


    /**
     * get post information(including user information) of the given thread
     *
     * @param $thread_id (thread id of the thread)
     * @return post(JSON Data)
     */

    public static function getPostBythread($thread_id)
    {

        /**get category**/
        $thread_category = DB::table('thread_category_thread')
            ->select('thread_categories.id',
                'thread_categories.name')
            ->where('thread_category_thread.thread_id', '=', $thread_id)
            ->join('thread_categories', 'thread_categories.id', '=', 'thread_category_thread.thread_category_id')->get();
        /**get thread information**/
        $thread = Thread::with('user')->where('deleted', '=', '0')->find($thread_id);
        if (empty($thread)) {
            throw new Exception(Lang::get('messages.no_data'));
        }
        $thread_user = DB::table('thread_user')->select(
            'thread_user.type as relation_type')
            ->where('thread_id', '=', $thread_id)->where('user_id', '=', Auth::user()->id)->first();
        /**get post that has the most like**/
        $post_liked = DB::table('posts')->select(
            'posts.*',
            'users.first_name as author_firstname',
            'users.last_name as author_lastname',
            'users.semester as author_semester_point',
            'users.school as author_school',
            'users.picture_url as author_picture_url',
            'post_user.type as relation_type'
        )->where('posts.deleted', '=', 0)/** filter out deleted post**/
        ->join('users', 'users.id', '=', 'posts.user_id')->where('posts.thread_id', '=', $thread_id)
            ->leftJoin('post_user', function ($join) {
                $join->on('post_user.post_id', '=', 'posts.id')
                    ->where('post_user.user_id', '=', Auth::user()->id);
            })->orderBy('posts.like_amt', 'DESC')->first();
        /**get post information**/
        $posts = DB::table('posts')->select(
            'posts.*',
            'users.first_name as author_firstname',
            'users.last_name as author_lastname',
            'users.semester as author_semester_point',
            'users.school as author_school',
            'users.picture_url as author_picture_url',
            'post_user.type as relation_type'
        )->where('posts.deleted', '=', 0)/** filter out deleted post**/
        ->join('users', 'users.id', '=', 'posts.user_id')->where('posts.thread_id', '=', $thread_id)
            ->leftJoin('post_user', function ($join) {
                $join->on('post_user.post_id', '=', 'posts.id')
                    ->where('post_user.user_id', '=', Auth::user()->id);
            })->orderBy('posts.created_at', 'ASC')->get();

        $thread['categories'] = $thread_category;
        $thread['relation_user'] = $thread_user;
        $thread['most_liked'] = $post_liked;
        $thread["posts"] = $posts;

        return $thread;
    }

    /**
     * find the threads that belongs to a particular category
     * @param category id
     * @return Thread object
     */

    public static function findThreadByCategory($category_id)
    {

        $thread = DB::table('threads')
            ->select('threads.*'
                , 'users.id as user_id'
                , 'users.first_name as first_name'
                , 'users.semester as semester'
                , 'users.school as school'
                , 'users.last_name as last_name'
                , 'users.picture_url as picture_url'
                , 'thread_user.type as relation_type')
            ->join('thread_category_thread', 'thread_category_thread.thread_id', '=', 'threads.id')
            ->where('thread_category_thread.thread_category_id', '=', $category_id)
            ->where('threads.deleted', '=', 0)
            ->join('users', 'threads.user_id', '=', 'users.id')
            ->leftJoin('thread_user', function ($join) {
                $join->on('thread_user.thread_id', '=', 'threads.id')
                    ->where('thread_user.user_id', '=', Auth::user()->id);
            })
            ->orderBy('updated_at', 'desc');

        return $thread;
    }

    /**
     * get all the threads information(including user information) in a update descending order
     *
     * @param
     * @return Thread object
     */
    public static function getAll()
    {

        $thread = DB::table('threads')
            ->select('threads.*'
                , 'users.first_name as first_name'
                , 'users.semester as semester'
                , 'users.school as school'
                , 'users.last_name as last_name'
                , 'users.picture_url as picture_url'
                , 'thread_user.type as relation_type')
            ->where('threads.deleted', '=', 0)
            ->join('users', 'threads.user_id', '=', 'users.id')
            ->leftJoin('thread_user', function ($join) {
                $join->on('thread_user.thread_id', '=', 'threads.id')
                    ->where('thread_user.user_id', '=', Auth::user()->id);
            })
            ->orderBy('updated_at', 'desc');

        return $thread;
    }

    /**
     * find hot topic daily thread
     * Hot topic is defined as the thread with most number of posts within a day
     *
     * @return thread object
     */

    public static function findHotTopicThread($time)
    {
        // set a period of the threads as one week
        $one_week_ago = Carbon::now()->subWeeks($time);

        $thread = DB::table('threads')
            ->select('threads.*'
                , 'users.first_name as first_name'
                , 'users.semester as semester'
                , 'users.school as school'
                , 'users.last_name as last_name'
                , 'users.picture_url as picture_url'
                , 'thread_user.type as relation_type'
                // numPosts is no of posts in $thread
                , DB::raw('count(distinct posts.id) as numPosts')
            )
            ->join('thread_category_thread', 'thread_category_thread.thread_id', '=', 'threads.id')
            // // get threads which are within user's category
            // ->whereIn('thread_category_thread.thread_category_id',$category_list)
            ->where('threads.deleted', '=', 0)
            ->join('posts', 'posts.thread_id', '=', 'threads.id')
            // only posts within a week are valid
            ->where('posts.deleted', '=', 0)
            ->where('posts.created_at', '>=', $one_week_ago)
            // only threads within a week are valid
            //->where('threads.created_at', '>=', $one_week_ago)
            ->join('users', 'threads.user_id', '=', 'users.id')
            ->leftJoin('thread_user', function ($join) {
                $join->on('thread_user.thread_id', '=', 'threads.id')
                    ->where('thread_user.user_id', '=', Auth::user()->id);
            })
            ->groupBy('threads.id')
            ->distinct()
            ->orderBy('numPosts', 'desc');

        return $thread;
    }

    /**
     * Create the thread
     *
     * @return Thread
     */
    public function createThread($topic, $detail, $category_id)
    {
        DB::beginTransaction();
        // save in Thread table
        $thread = new Thread();
        $thread->topic = $topic;
        $thread->user_id = Auth::user()->id;
        $thread->detail = $detail;
        $thread->is_pending = 1;
        $thread->number_of_report = 0;
        $thread->verification_mark = 0;
        $thread->deleted = 0;
        $thread->like_amt = 0;
        $thread->dislike_amt = 0;
        $thread->search_updated = true;
        $thread->save();

        // save in thread_category_thread
        if (!empty($category_id)) {
            foreach ($category_id as $id) {
                $thread->categories()->attach($id);
            }
        }

        try {
            SearchUtil::addThread($thread);
        } catch (Exception $e) {
            Log::error('Thread.php "createThread" Error when making an attempt to create a document in Elasticsearch: ' . $e->getMessage());
            $thread->search_updated = false;
            $thread->save();
        }
        DB::commit();
        return $thread;
    }

    /**
     * Added by Pittawat.
     */
    public function reportBy($user)
    {
        $this->number_of_report++;
        $this->save();
        return;
    }

    /**
     * Update the thread information.
     *
     * @return Thread
     */
    public function updateThread($topic, $detail, $category_id)
    {
        // update in thread table
        DB::beginTransaction();
        $this->topic = $topic;
        $this->detail = $detail;
        $this->search_updated = true;
        $this->save();
        //Delete thread record in thread category table first
        $this->categories()->detach();
        //Insert thread record
        if (!empty($category_id)) {
            foreach ($category_id as $id) {
                $this->categories()->attach($id);
            }
        }

        try {
            SearchUtil::editThread($this);
        } catch (Exception $e) {
            Log::error('Thread.php "updateThread" Error when making an attempt to update an updated document in Elasticsearch: ' . $e->getMessage());
            $this->search_updated = false;
            $this->save();
        }
        DB::commit();
        return $this;
    }

    /**
     * Delete the thread.
     *
     */

    public function deleteThread()
    {
        DB::beginTransaction();
        // delete from thread table
        $this->deleted = 1;
        $this->search_updated = true;
        $this->save();

        /*
        * Remove point from the owner of the deleted threads.
        * There will be two cases that threads are deleted
        * 1. the owner of the user delete their own threads
        * 2. the maintainers decide that the threads are violating the system rules and delete the threads.
        * For Both cases, the points the owner get from such a thread will be cleared out.
        * Remark: the reason why we need to requery a thread before calculate the points
        *           because there may be a case when another user gives like or dislike to a thread during an overlapped time that the owner clicks "delete"
        *           and the time when the threads are actually marked as deleted.
        */
        $deletedThread = Thread::where("deleted","=",true)->find($this->id);
        if(!empty($deletedThread)){
          $currentPoint = $deletedThread->calculatePoint();
          $author = $deletedThread->author;
          $author->addLifePoint(-$currentPoint);
          $author->addSemesterPoint(-$currentPoint);
          if($deletedThread->is_pending){
            $author->addPendingPoint(-$currentPoint);
          }
          else{
            $author->addUsablePoint(-$currentPoint);
          }
          $author->save();
        }

        try {
            SearchUtil::deleteThread($this);
        } catch (Exception $e) {
            Log::error('Thread.php "deleteThread" Error when making an attempt to remove a deleted document from Elasticsearch: ' . $e->getMessage());
            $this->search_updated = false;
            $this->save();
        }
        DB::commit();
        return true;
    }

    /**
     * Calculate point of the thread by it like_amt and dislike_amt data in the database corresponding with configured data
     *
     * @return int (points calculated)
     */
    private function calculatePoint()
    {
        Log::debug("calculate: " . $this->like_amt . " * " . intval(Config::get('wat/wat_point.like_point')) . " - " . $this->dislike_amt . " * " . intval(Config::get('wat/wat_point.dislike_point')));
        $pointDiff = $this->like_amt * intval(Config::get('wat/wat_point.like_point')) - $this->dislike_amt * intval(Config::get('wat/wat_point.dislike_point'));
        return ($pointDiff > 0) ? $pointDiff : 0;
    }

    /**
     * update to like_amt of the thread by the user's liking action.
     *
     */
    public function addLike()
    {
        $currentPoint = $this->calculatePoint();
        $this->like_amt += 1;
        $this->save();
        $newPoint = $this->calculatePoint();
        $pointDiff = $newPoint - $currentPoint;

        Log::debug('addlike: currentPoint ' . $currentPoint);
        Log::debug('addlike: newPoint ' . $newPoint);
        Log::debug('addlike: pointDiff ' . $pointDiff);

        $author = $this->author;
        $author->addLifePoint($pointDiff);
        $author->addSemesterPoint($pointDiff);
        //30day = 30*24*60*60 secs = 2592000secs
        // if ((time() - 2592000) > strtotime($this->$created_at)){
        if ($this->is_pending) { // the script which will be run each day will change is_pending after the thread has been created for 30 days.
            $author->addPendingPoint($pointDiff);
        } else {
            $author->addUsablePoint($pointDiff);
        }
        $author->save();
    }

    /**
     * update like_amount of likes of the thread by the user's unliking action.
     *
     */
    public function unLike()
    {
        $currentPoint = $this->calculatePoint();
        $this->like_amt -= 1;
        $this->save();
        $newPoint = $this->calculatePoint();
        $pointDiff = $newPoint - $currentPoint;

        Log::debug('unlike: currentPoint ' . $currentPoint);
        Log::debug('unlike: newPoint ' . $newPoint);
        Log::debug('unlike: pointDiff ' . $pointDiff);

        $author = $this->author;
        $author->addLifePoint($pointDiff);
        $author->addSemesterPoint($pointDiff);
        if ($this->is_pending) {
            $author->addPendingPoint($pointDiff);
        } else {
            $author->addUsablePoint($pointDiff);
        }
        $author->save();
    }

    /**
     * update dislike_amt of dislike to the thread by the user's disliking action.
     *
     */
    public function addDislike()
    {
        $currentPoint = $this->calculatePoint();
        $this->dislike_amt += 1;
        $this->save();
        $newPoint = $this->calculatePoint();
        $pointDiff = $newPoint - $currentPoint;

        Log::debug('Dislike: currentPoint ' . $currentPoint);
        Log::debug('Dislike: newPoint ' . $newPoint);
        Log::debug('Dislike: pointDiff ' . $pointDiff);

        $author = $this->author;
        $author->addLifePoint($pointDiff);
        $author->addSemesterPoint($pointDiff);
        if ($this->is_pending) {
            $author->addPendingPoint($pointDiff);
        } else {
            $author->addUsablePoint($pointDiff);
        }
        $author->save();
    }

    /**
     * update dislike_amt of dislikes of the thread by the user's undisliking action.
     *
     */
    public function unDislike()
    {
        $currentPoint = $this->calculatePoint();
        $this->dislike_amt -= 1;
        $this->save();
        $newPoint = $this->calculatePoint();
        $pointDiff = $newPoint - $currentPoint;

        Log::debug('unDislike: currentPoint ' . $currentPoint);
        Log::debug('unDislike: newPoint ' . $newPoint);
        Log::debug('unDislike: pointDiff ' . $pointDiff);

        $author = $this->author;
        $author->addLifePoint($pointDiff);
        $author->addSemesterPoint($pointDiff);
        if ($this->is_pending) {
            $author->addPendingPoint($pointDiff);
        } else {
            $author->addUsablePoint($pointDiff);
        }
        $author->save();
    }

    /**
     * Verify this thread by change the verification mark to 1
     */
    public function verify() {
      $this->verification_mark = 1;
      $this->save();
      return true;
    }

    ////////////////////////////////////////////Relationship tables//////////////////////////////////////////////////
    /**
     * get author of the thread
     *
     * @return User
     */
    public function author()
    {
        return $this->belongsTo('User', 'user_id');
    }

    /**
     * get author of the thread
     *
     * @return User
     */
    public function user()
    {
        return $this->belongsTo('User');
    }

    /**
     * get posts of the thread
     *
     * @return list of posts
     */
    public function post()
    {
        return $this->hasMany('Post');
    }

    /**
     * get threads's relationship liked by the user
     *
     * @return list of pivot data
     */
    public function relationUsers()
    {
        return $this->belongsToMany('User', 'thread_user', 'thread_id', 'user_id')->withTimestamps()->withPivot('type');
    }

    /**
     * get threads's relationship by category
     *
     * @return list of threads
     */
    public function categories()
    {
        return $this->belongsToMany('ThreadCategory', 'thread_category_thread', 'thread_id', 'thread_category_id')->withTimestamps();
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Do further query from thread query by scope down only reported thread.
     * @return $query with only reported thread.
     */
    public function scopeReported($query) {
      return $query->where('threads.number_of_report', '>', 0)->where('threads.verification_mark', 0);
    }

    /**
     * Do further query from thread query by scope down only undeleted thread.
     * @return $query with only undeleted thread.
     */
    public function scopeNotDeleted($query) {
      return $query->where('threads.deleted', 0);
    }
    ////////////////////////////////////////////Admin Functions//////////////////////////////////////////////////
    /**
     * get all the threads information that are reported in number of reported descending order
     *
     * @param
     * @return Thread object
     */
    public function adminGetAllReportedThread()
    {
        $thread = DB::table('threads')
            ->where('threads.number_of_report', '>', 0)
            ->orderBy('number_of_report', 'desc');
        return $thread;
    }

    /**
     * Admin delete the reported thread
     *
     */
    public function adminDeleteReportedThread($thread_id)
    {
        // delete from thread table
        $thread = Thread::find($thread_id);
        $thread->deleted = 1;
        $thread->search_updated = true;
        $thread->save();
        try {
            SearchUtil::deleteThread($thread);
        } catch (Exception $e) {
            Log::error('Thread.php "deleteThread" Error when making an attempt to remove a deleted document from Elasticsearch: ' . $e->getMessage());
            $thread->search_updated = false;
            $thread->save();
        }
    }

    /**
     * Admin approve the reported thread
     *
     */
    public function adminApproveReportedThread($thread_id)
    {
        $thread = Thread::find($thread_id);
        $thread->number_of_report=0;
        $thread->save();
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
