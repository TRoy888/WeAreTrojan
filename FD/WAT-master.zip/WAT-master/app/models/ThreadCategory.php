<?php

class ThreadCategory extends Eloquent{
  /**
   * The database table used by the model.
   *
   * @var string
   */
  protected $table = 'thread_categories';

  // private $categoryCode;
  // private $categoryName;

  public function findCategory()
  {

  }
  /**
  * Get the category name
  * @var category id
  * @return category name
  */
  public static function getCategoryNameById($category_id){
    if( $category_id == Config::get('wat/specialThread.hot_thread_id') ){
      return $category_name = Config::get('wat/specialThread.hot_thread_name');
    }
    if( $category_id == Config::get('wat/specialThread.all_thread_id') ){
      return $category_name = Config::get('wat/specialThread.all_thread_name');
    }

    $category_name = ThreadCategory::find($category_id)->name;

    return $category_name;
  }


  /**   ==========================================================================
    *   Unused code
    *   This contains createCategory, updateCategory and deleteCategory
    *   Since currently we do not allow users to create their categories
    *   We just comment these functions

  public function createCategory($code,$name,$thread_category_id)
  {
      $threadCategory = new ThreadCategory();
      $threadCategory->code = $code;
      $threadCategory->name = $name;
      $threadCategory->thread_category_id = $thread_category_id;

      $threadCategory->save();
  }

  public function updateCategory($code,$name,$category_id)
  {
    $threadCategory = ThreadCategory::find($category_id);
    $threadCategory->code = $code;
    $threadCategory->name = $name;

    $threadCategory->save();
  }

  public function deleteCategory($category_id)
  {
    $threadCategory = ThreadCategory::find($category_id);
    $threadCategory->delete();
  }
  */
}
