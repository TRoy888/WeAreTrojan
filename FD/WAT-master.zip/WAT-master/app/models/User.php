<?php
use Illuminate\Auth\UserTrait;
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;

class User extends Eloquent implements UserInterface, RemindableInterface {

  use UserTrait,
       RemindableTrait;

    /**
    * like and dislike types values which are used in the thread_user and post_user tables
    */
    public static $like = 1;
    public static $dislike = 2;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'users';

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = array('password', 'remember_token');

    /**
     * add a relation like/dislike with a specific thread.
     *
     * @param  Thread  $thread	the thread object.
     * @param User::$like or User::$dislike -> $type is a relationship type which will be either 1=like , 2=dislike
     * @return true: adding is successful, false: user already has a relationship with the thread.
     */
    private function addThreadRelation($thread, $type) {
        Log::debug($this->id . ' add ' . $type . ' to thread' . $thread->id);
        if ($type != User::$like && $type != User::$dislike)
            return false;
        Log::debug('Exists: ' . $this->relationThread->contains($thread->id));
        if (!$this->relationThread->contains($thread->id)) {
            $this->relationThread()->save($thread, array('type' => $type));
            return true;
        }
        return false;
    }

    /**
     * Get user ranking by semester point
     * @return integer, rank of the user
     */
    public function rank() {
      return self::where('semester', '>', $this->semester)->count() + 1;
    }

    /**
     * find categories of the user
     *
     * @param  userId
     * @return category
     */
    public static function findCategory($user_id) {

        $categories = DB::table('thread_categories')
                        ->select('thread_categories.*')
                        ->join('thread_category_user', 'thread_categories.id', '=', 'thread_category_user.thread_category_id')
                        ->where('thread_category_user.user_id', '=', $user_id)->get();

        return $categories;
    }

    /**
     * Add categories to user favorite categories list by array of categories id.
     * @param  array $category array of category id that want to add ex. [1,2,3].
     * @return $this
     */
    public function insertCategory($category) {
        $attach = array();
        foreach ($category as $category_id) {
            if (is_numeric($category_id) && !$this->categories->contains($category_id) && ThreadCategory::find($category_id)) {
                $attach[] = $category_id;
            }
        }
        if (!empty($attach)) {
            $this->categories()->attach($attach);
        }
        return $this;
    }

    /**
     * Delete categories from user favorites categories list by array of categories id.
     * @param  array $category array of category id that want to remove ex. [1, 2, 3].
     * @return $this
     */
    public function deleteCategory($category) {
        $detach = array();
        foreach ($category as $category_id) {
            if (is_numeric($category_id) && $this->categories->contains($category_id)) {
                $detach[] = $category_id;
            }
        }
        if (!empty($detach)) {
            $this->categories()->detach($detach);
        }
        return $this;
    }

    /**
     * delete a relation like/dislike with a specific thread
     *
     * @param  Thread  $thread	the thread object
     * @param User::$like or User::$dislike -> $type is a relationship type which will be either 1=like , 2=dislike
     * @return true: deleting is successful, false: either user has different type of relationship with the thread or user does not have any relationship with the thread
     */
    private function deleteThreadRelation($thread, $type) {
        Log::debug($this->id . ' remove ' . $type . ' from thread' . $thread->id);
        if ($this->relationThread->contains($thread->id) && $this->relationThread->find($thread->id)->pivot->type == $type) {
            $this->relationThread()->detach($thread->id);
            return true;
        }
        return false;
    }

    /**
     * add a relation like/dislike with a specific post.
     *
     * @param Post $post the post instance
     * @param User::$like or User::$dislike -> $type is a relationship type which will be either 1=like, 2=dislike
     * @return Boolean true:adding is successful, false: either user has different type of relationship with the post
     */
    private function addPostRelation($post, $type) {
        Log::debug($this->id . ' add ' . $type . ' to post ' . $post->id);
        if ($type != User::$like && $type != User::$dislike)
            return false;
        Log::debug('Exists: ' . $this->relationPost->contains($post->id));
        if (!$this->relationPost->contains($post->id)) {
            $this->relationPost()->save($post, array('type' => $type));
            return true;
        }
        return false;
    }

    /**
     * 	delete a relation like/dislike with a specific post.
     *
     * @param Post $post the post instance
     * @param User::$like or User::$dislike -> $type is a relationship type which will be either 1=like, 2=dislike
     * @return Boolean true:deleting is successful, false: either user has different type of relationship with the post or user does not have any relationship with the post
     */
    private function deletePostRelation($post, $type) {
        Log::debug($this->id . ' remove ' . $type . ' from post ' . $post->id);
        if ($this->relationPost->contains($post->id) && $this->relationPost->find($post->id)->pivot->type == $type) {
            $this->relationPost()->detach($post->id);
            return true;
        }
        return false;
    }

    /**
     * Get maximum size of profile picture in Mbytes
     * I extract maximum size of profile picture from filter_pic_profile.
     * @return max profile picture.
     */
    public static function getMaxProfilePictureSize() {
      $filter = Config::get('wat/users.filter_pic_profile');
      return intval(substr($filter, strrpos($filter, 'max:') + strlen('max:'), strlen($filter))) * 1000;
    }

    /**
     * Get string of full path to profile picture folder.
     * If the folder is not exist then create the folder.
     * @return string of full path to profile picture folder.
     */
    public static function getProfilePicturePath(){
        if (!file_exists(public_path() . self::getProfilePictureURL())) {
            mkdir(public_path() . self::getProfilePictureURL(), 0777, true);
        }
        return public_path() . self::getProfilePictureURL();
    }

    /**
     * Get string of profile picture folder URL.
     * @return string of profile picture folder URL.
     */
    public static function getProfilePictureURL() {
        return Config::get('wat/users.url_folder_profile_pic');
    }

		/**
		* This method will change the flag in the users table so that the system will know whether the user is using the system for the first time or not.
		*
		* @return boolean
		*/
		public function firstLogin(){
			$this->not_first_time = true;
			return $this->save();
		}

    /**
     * Get string of full path to cover picture folder.
     * If the folder is not exist then create the folder.
     * @return string of full path to cover picture folder.
     */
    public static function getCoverPicturePath() {
        if (!file_exists(public_path() . self::getCoverPictureURL())) {
            mkdir(public_path() . self::getCoverPictureURL(), 0777, true);
        }
        return public_path() . self::getCoverPictureURL();
    }

    /**
     * Get stringf of cover picture folder URL.
     * @return string of cover picture folder URL.
     */
    public static function getCoverPictureURL() {
        return Config::get('wat/users.url_folder_cover_pic');
    }

    /**
     * Get Profile filter to use with validation
     * @return array: filter of validation.
     */
    public static function getProfileFilter() {
      return [
        'firstname'   => Config::get('wat/users.filter_firstname'),
        'lastname'    => Config::get('wat/users.filter_lastname'),
        'degree'      => Config::get('wat/users.filter_degree'),
        'class'       => Config::get('wat/users.filter_class'),
        'school'      => Config::get('wat/users.filter_school'),
        'description' => Config::get('wat/users.filter_description')];
    }

    public static function createUser(array $fields) {
        $user = new User();
        $user->first_name = $fields['firstname'];
        $user->last_name = $fields['lastname'];
        $user->email = $fields['email'];
        $user->password = $fields['password'];
        $user->confirmation_code = $fields['confirmation_code'];
        $user->picture_url = User::getDefaultProfilePicture();
        $user->cover_url = User::getDefaultCoverPicture();
        $user->search_updated = true;
        $user->role()->associate(UserRole::where('name', 'user')->first());
        $user->save();

        //add a user document to the Elastic server.
        try{
          SearchUtil::addUser($user);
        }
        catch(Exception $e){
          Log::error('User.php "createUser" Error when making an attempt to add a new user document in Elasticsearch: '.$e->getMessage());
          $user->search_updated = false;
          $user->save();
        }

    }

    public function deleteUser() {
      //to implement user-deleting features
      //do not forget to remove the user from Elasticsearch after deleting users.
    }

    /**
    * Check whether the user is the owner of the thread or not.
    * @return boolean
    */
    private function isThreadOwner($thread) {
        return ($thread->author->id == $this->id) ? true : false;
    }
    /**
    * Check whether the user is the owner of the post or not.
    * @return boolean
    */
    private function isPostOwner($post) {
        return ($post->author->id == $this->id) ? true : false;
    }

    /**
     * User like a thread.
     *
     * @param  Thread  $thread	the thread object.
     * @return Thread: when liking is successful, null:when the user has already either liked, disliked the thread.
     */
    public function likeThread($thread) {
        DB::beginTransaction();
        $result = false;
        if (!$this->isThreadOwner($thread)
          && $this->addThreadRelation($thread, self::$like)
          && !$thread->deleted) {
            $thread->addLike();
            $result = true;
        } else {
            //handle relation already exists and owner issues.
        }
        DB::commit();

        // Send notification
        if (!$this->isThreadOwner($thread))
            Notification::likeThread($thread, $this);

        return ($result) ? $thread : null;
    }

    /**
     * User unlike a thread
     *
     * @param Thread $thread that is unliked by a user
     * @return Thread: when unliking is successful, null:when there is inconsistency, (e.g., the user has previously disliked the thread instead of liking, and the user hasn't previously liked the thread)
     */
    public function unlikeThread($thread) {
        DB::beginTransaction();
        $result = false;
        if (!$this->isThreadOwner($thread)
          && $this->deleteThreadRelation($thread, self::$like)
          && !$thread->deleted) {
            $thread->unLike();
            $result = true;
        } else {
            //handle relation does not exist and owner issues.
        }
        DB::commit();

        // Remove notification
        if (!$this->isThreadOwner($thread))
            Notification::removeNotification($thread, $this, Notification::NOTIF_TYPE_LIKE);

        return ($result) ? $thread : null;
    }

    /**
     * User dislike a thread.
     *
     * @param  Thread  $thread	the thread object.
     * @return Thread: when disliking is successful, null:when the user has already either liked, disliked the thread.
     */
    public function dislikeThread($thread) {
        DB::beginTransaction();
        $result = false;
        if (!$this->isThreadOwner($thread)
          && $this->addThreadRelation($thread, self::$dislike)
          && !$thread->deleted) {
            $thread->addDislike();
            $result = true;
        } else {
            //handle relation already exists and owner issues.
        }
        DB::commit();
        return ($result) ? $thread : null;
    }

    /**
     * User undislike a thread.
     *
     * @param  Thread  $thread	the thread object.
     * @return Thread: when undisliking is successful, null:when there is inconsistency, (e.g., the user has previously liked the thread instead of disliking, and the user hasn't previously disliked the thread)
     */
    public function undislikeThread($thread) {
        DB::beginTransaction();
        $result = false;
        if (!$this->isThreadOwner($thread)
          && $this->deleteThreadRelation($thread, self::$dislike)
          && !$thread->deleted) {
            $thread->unDislike();
            $result = true;
        } else {
            //handle relation already exists and owner issues.
        }
        DB::commit();
        return ($result) ? $thread : null;
    }

    /**
     * User like a post
     *
     * @param Post $post the post instance that the user likes
     * @return Post: when liking is successful, null:when there is inconsistency, (e.g., the user has previously disliked the post, and the user has already liked the post, etc.)
     */
    public function likePost($post) {
        DB::beginTransaction();
        $result = false;
        if (!$this->isPostOwner($post)
          && $this->addPostRelation($post, self::$like)
          && !$post->deleted) {
            $post->addLike();
            $result = true;
        } else {
            //to handle relation already exists and owner issues.
        }
        DB::commit();

        // Add notification
	if (!$this->isPostOwner($post))
        Notification::likePost($post, $this);
        return ($result) ? $post : null;
    }

    /**
     * User unlike a post
     *
     * @param Post $post the post instance that the user likes
     * @return Post: when unliking is successful, null:when there is inconsistency, (e.g., the user has previously disliked the post instead of liking, and the user hasn't previously liked the post)
     */
    public function unlikePost($post) {
        DB::beginTransaction();
        $result = false;
        if (!$this->isPostOwner($post)
          && $this->deletePostRelation($post, self::$like)
          && !$post->deleted) {
            $post->unlike();
            $result = true;
        } else {
            //to handle relation already exists and owner issues.
        }
        DB::commit();

        // Remove notification
        if (!$this->isPostOwner($post))
            Notification::removeNotification($post, $this, Notification::NOTIF_TYPE_LIKE);

        return ($result) ? $post : null;
    }

    /**
     * User dislike a post
     *
     * @param Post $post the post instance that the user likes
     * @return Post: when disliking is successful, null:when there is inconsistency, (e.g., the user has previously liked the post, and the user has already disliked the post, etc.)
     */
    public function dislikePost($post) {
        DB::beginTransaction();
        $result = false;
        if (!$this->isPostOwner($post)
          && $this->addPostRelation($post, self::$dislike)
          && !$post->deleted) {
            $post->addDislike();
            $result = true;
        } else {
            //to handle relation already exists and owner issues
        }
        DB::commit();
        return ($result) ? $post : null;
    }

    /**
     * User undislike a post
     *
     * @param Post $post the post instance that the user likes
     * @return Post: when undisliking is successful, null:when there is inconsistency, (e.g., the user has previously liked the post instead of disliking, and the user hasn't previously disliked the post)
     */
    public function undislikePost($post) {
        DB::beginTransaction();
        $result = false;
        if (!$this->isPostOwner($post)
          && $this->deletePostRelation($post, self::$dislike)
          && !$post->deleted) {
            $post->undislike();
            $result = true;
        } else {
            //to handle relation already exists and owner issues
        }
        DB::commit();
        return ($result) ? $post : null;
    }

    /**
     * add $amount to life point.
     *
     * @param  int  $amount	amount to add.
     */
    public function addLifePoint($amount) {
        $this->life_time += $amount;
    }

    /**
     * add $amount to semester point.
     *
     * @param  int  $amount	amount to add.
     */
    public function addSemesterPoint($amount) {
        $this->semester += $amount;
    }

    /**
     * add $amount to usable point.
     *
     * @param  int  $amount	amount to add.
     */
    public function addUsablePoint($amount) {
        $this->usable += $amount;
    }

    /**
     * add $amount to pending point.
     *
     * @param  int  $amount	amount to add.
     */
    public function addPendingPoint($amount) {
        $this->pending_point += $amount;
    }

    /**
     * create a new notification for this user
     */
    public function addNotification($notification) {
        //set user to not seen the notification (handle when they are offline)
        if($this->has_seen_notification != 0){
            $this->has_seen_notification = 0;
            $this->save();
        }
        // Associate notification with this user
        $notification->user()->associate($this);

        return $notification;
    }

    ////////////////////////////////////////////Relationship tables//////////////////////////////////////////////////
    /**
     * get threads created by the user
     *
     * @return list of Threads
     */
    public function ownThread() {
        return $this->hasMany('Thread');
    }

    /**
     * get posts created by the user
     *
     * @return list of Posts
     */
    public function ownPosts() {
        return $this->hasMany('Post');
    }

    /**
     * get user's notifications
     * @return list of notifications to this user.
     */
    public function notifications() {
        return $this->hasMany('Notification', 'to_user');
    }

    /**
     * get threads liked/disliked by the user
     *
     * @return list of threads
     */
    public function relationThread() {
        return $this->belongsToMany('Thread', 'thread_user', 'user_id', 'thread_id')->withTimestamps()->withPivot('type');
    }

    /**
     * get posts liked/disliked by the user
     *
     * @return list of Posts
     */
    public function relationPost() {
        return $this->belongsToMany('Post', 'post_user', 'user_id', 'post_id')->withTimestamps()->withPivot('type');
    }

    /**
     * get user favorite categories list.
     * @return list of ThreadCategory.
     */
    public function categories() {
        return $this->belongsToMany('ThreadCategory', 'thread_category_user', 'user_id', 'thread_category_id')->withTimestamps();
    }

    /**
     * Get user role. Ex. user, admin, maintainer.
     * @return a role in user_roles table that have the same id as $this->role_id.
     */
    public function role() {
      return $this->belongsTo('UserRole', 'role_id');
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Is the user has authority or not, The user's $id is the same as the authorize's $id.
     *
     * @return true: If the user has authority, false: If not.
     */
    public function isAuthenticated() {
        return ($this == Auth::user()) ? true : false;
    }

    /**
     * Get array of the user's profile information from database
     *
     * @return array: The user's profile information from database.
     */
    public function getProfileInformation() {
      $threads = $this->ownThread()->notDeleted()->orderBy('created_at', 'desc');
        return array(
            'picture_url' => asset($this->picture_url),
            'email' => $this->email,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'degree' => $this->degree,
            'school' => $this->school,
            'lpoint' => $this->life_time ? $this->life_time : 0,
            'spoint' => $this->semester ? $this->semester : 0,
            'upoint' => $this->usable ? $this->usable : 0,
            'ppoint' => $this->pending_point ? $this->pending_point : 0,
            'summary_profile' => $this->summary_profile,
            'cover_url' => asset($this->cover_url),
            'hobbies' => $this->hobbies,
            'other' => $this->other,
            'class' => $this->class,
            'id' => $this->id,
            'editable' => $this->isAuthenticated(),
            'threadnumber' => $threads->count(),
            'threads' => $threads->paginate(4)
        );
    }
    
    /**
     * Modify user's has_seen_notification to true once the user click the dropdown menu.
     *
     * @return true: success
     */
    public function seeNotification(){
        if($this->has_seen_notification != 1){
        $this->has_seen_notification = 1;
        $this->save();
        }
        return true;
    }

    /**
     * Save the user profile information except image related information
     *
     * @param array $info profile information.
     * @return true: success, false: fail
     */
    public function saveProfileInformation($info) {
        if (!empty($info['firstname']))
            $this->first_name = $info['firstname'];
        if (!empty($info['lastname']))
            $this->last_name = $info['lastname'];
        if (!empty($info['degree']))
            $this->degree = $info['degree'];
        else
            $this->degree = null;
        if (!empty($info['school']))
            $this->school = $info['school'];
        else
            $this->school = null;
        if (!empty($info['description']))
            $this->summary_profile = $info['description'];
        else
            $this->summary_profile = null;
        if (!empty($info['class']))
            $this->class = $info['class'];
        if (!empty($info['email']))
            $this->email = $info['email'];

        $this->search_updated = true;
        $this->save();

        //update a user document to the Elastic server.
        try{
          SearchUtil::editUser($this);
        }
        catch(Exception $e){
          Log::error('User.php "saveProfileInformation" Error when making an attempt to change an updated document in Elasticsearch: '.$e->getMessage());
          $this->search_updated = false;
          $this->save();
        }

        return true;
    }

    /**
     * Save user profile picture
     * @param string $url url to new picture location
     * @param int $width the width to show of the new picture.
     * @param int $top the top that use to crop the new picture.
     * @param int $left the left that use to crop the new picture.
     */
    public function saveProfilePicture($url) {
        $oldPic = public_path() . $this->picture_url;
        if (file_exists($oldPic) && !is_dir($oldPic) &&
                $this->picture_url != self::getDefaultProfilePicture()) {
            unlink($oldPic);
        }
        $this->search_updated = true;
        $this->picture_url = $url;
        $this->save();

        //update a user document to the Elastic server.
        try{
          SearchUtil::editUser($this);
        }
        catch(Exception $e){
          Log::error('User.php "saveProfilePicture" Error when making an attempt to change an updated document in Elasticsearch: '.$e->getMessage());
          $this->search_updated = false;
          $this->save();
        }
    }

    /**
     * Get URL to the default cover picture.
     * @return string of URL to the default cover picture.
     */
    public static function getDefaultCoverPicture() {
        return Config::get('wat/users.url_pic_default_cover');
    }

    /**
     * Get URL to the default profile picture.
     * @return string of URL to the default profile picture.
     */
    public static function getDefaultProfilePicture() {
        return Config::get('wat/users.url_pic_default_profile');
    }

    /**
     * Save user cover picture
     * @param string $url url to new picture location
     * @param int $width the width to show of the new picture.
     * @param int $top the top that use to crop the new picture.
     * @param int $left the left that use to crop the new picture.
     */
    public function saveCoverPicture($url) {
        $oldPic = public_path() . $this->cover_url;
        if (file_exists($oldPic) && !is_dir($oldPic) &&
                $this->cover_url != self::getDefaultCoverPicture()) {
            unlink($oldPic);
        }
        $this->cover_url = $url;
        $this->search_updated = true;
        $this->save();

        //update a user document to the Elastic server.
        try{
          SearchUtil::editUser($this);
        }
        catch(Exception $e){
          Log::error('User.php "saveCoverPicture" Error when making an attempt to change an updated document in Elasticsearch: '.$e->getMessage());
          $this->search_updated = false;
          $this->save();
        }
    }

    /**
     * Save password
     * @param string $new the new password
     */
    public function savePassword($new) {
        $this->password = Hash::make($new);
        $this->save();
    }

    public function confirm() {
        $this->confirmed = 1;
        $this->confirmation_code = null;
        $this->save();
    }
}
