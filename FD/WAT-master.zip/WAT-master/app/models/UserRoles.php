<?php

class UserRole extends Eloquent{
  /**
  * The database table used by the model.
  *
  * @var string
  */
  protected $table = 'user_roles';

  public function users() {
    return $this->hasMany('User', 'role_id', 'id');
  }

}
