<?php
/**
* What: This class is used to build up event model in this project. It contains the functionalities dealing with Event object.
* Why: This class will provide Event functions for controller layer
* How: This class can be called in controller layer.
*
*
*/
class WATEvent extends Eloquent{
  /**
  * The database table used by the model.
  *
  * @var string
  */
  protected $table = 'events';


  public function findWATEvent()
  {

  }

  /**
	* Create an event object
	* @param  Array($fields): this is an array containing event topic, location, start_time,end_time
  *                         notification_time,point_for_joining,details,event_picture and user_id
	* @return Object: WATEvent
	*/
  public static function createWATEvent($fields)
  {
    $event = new WATEvent();
    $event->topic = $fields['topic'];
    $event->location = $fields['location'];
    $event->start_time = $fields['start_time'];
    $event->end_time = $fields['end_time'];
    $event->point_for_joining = $fields['point_for_joining'];
    $event->detail = $fields['details'];
    $event->picture = $fields['event_picture'];
    $event->user_id = $fields['user_id'];
    $event->save();

    return $event;
  }

/*
  public static function createWATEvent(array $fields)
  {
        // save in Event table
        $eventOb = new WATEvent();
        $eventOb->topic = $fields['topic'];
        $eventOb->location = $fields['location'];
        $eventOb->start_time = $fields['start_time'];
        $eventOb->end_time = $fields['end_time'];
        $eventOb->detail = $fields['detail'];
        $eventOb->picture = $fields['picture'];
        $eventOb->user_id = 6;
        $eventOb->notification_time = $fields['notification_time'];
        $eventOb->point_for_joining = $fields['point_for_joining'];
        $eventOb->save();

        return $eventOb;

  }*/

  /**
	* Update an event object information
	* @param  Array($fields): this is an array containing event topic, location, start_time,end_time
  *                         notification_time,point_for_joining,details,event_picture and user_id
	* @return Object: WATEvent
	*/
  public function updateWATEvent(array $fields)
  {

        $this->topic = $fields['topic'];
        $this->location = $fields['location'];
        $this->start_time = $fields['start_time'];
        $this->end_time = $fields['end_time'];
        $this->detail = $fields['detail'];
        $this->picture = $fields['picture'];
        $this->user_id = 6;
        $this->notification_time = $fields['notification_time'];
        $this->point_for_joining = $fields['point_for_joining'];
        $this->save();

        return $this;
  }

  /**
	* Delete an event object information
	*/
  public function deleteWATEvent()
  {
      $this->delete();
  }


}
