<?php namespace Repositories\Admin;

interface AdminRepository {

  /**
   * Get all events
   * @return list of all events.
   */
  public function allEvents();

  /**
   * Get all threads.
   * @return list of all threads.
   */
  public function allThreads();

  /**
   * Get a specific post by id
   * @param int $id post id
   * @return post instance.
   */
  public function findPost($id);

  /**
   * Get a specific thread by id
   * @param int $id thread id
   * @return thread instance.
   */
  public function findThread($id);

  /**
   */
  public function notDeletedThreads();

  /**
   * Get all reported posts
   * @return array of reported post.
   */
  public function reportedPosts();
  /**
   * Get all reposted threads
   * @return array of reported threads.
   */
  public function reportedThreads();
}
