<?php namespace Repositories\Admin;

use Repositories\Admin\AdminRepository;
use Thread;
use Post;
use WATEvent;

class EloquentAdminRepository implements AdminRepository
{
  protected $postModel;
  protected $threadModel;
  protected $eventModel;

  public function __construct(Thread $thread, Post $post, WATEvent $event) {
    $this->threadModel = $thread;
    $this->postModel = $post;
    $this->eventModel = $event;
  }

  public function allEvents() {
    return $this->eventModel->paginate(10);
  }

  public function allThreads() {
    return $this->threadModel->all();
  }

  public function findPost($id) {
    return $this->postModel->find($id);
  }

  public function findThread($id) {
    return $this->threadModel->find($id);
  }

  public function notDeletedThreads() {
    return $this->threadModel->notDeleted();
  }

  public function reportedPosts() {
    return $this->postModel->reported();
  }

  public function reportedThreads() {
    return $this->threadModel->reported();
  }
}
