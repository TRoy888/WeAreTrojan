<?php namespace Repositories\post;

use Repositories\post\PostRepository;
use Post;

class EloquentPostRepository implements PostRepository
{
  protected $model;

  public function __construct (Post $model) {
    $this->model = $model;
  }

  /**
  *   Validate a post content
  *   @param $data is the given data
  *   @return True if data is valid,otherwise,false
  */
  public function isValid($data){
    return $this->model->isValid($data);
  }

}
