<?php namespace Repositories\User;

use Repositories\User\UserRepository;
use User;

class EloquentUserRepository implements UserRepository
{
  protected $model;

  public function __construct (User $model) {
    $this->model = $model;
  }

  public function all() {
    return $this->model->all();
  }

  public function allowImageExtension($ext) {
    return $this->model->allowImageExtension($ext);
  }

  public function create($input) {
    return $this->model->create($input);
  }

  public function createUser($fields) {
    return $this->model->createUser($fields);
  }

  public function find($id) {
    return $this->model->find($id);
  }

  public function findCategory($id) {
    return $this->model->findCategory($id);
  }

  public function getCoverPicturePath() {
    return $this->model->getCoverPicturePath();
  }

  public function getCoverPictureURL() {
    return $this->model->getCoverPictureURL();
  }

  public function getDefaultCoverPicture() {
    return $this->model->getDefaultCoverPicture();
  }

  public function getDefaultProfilePicture() {
    return $this->model->getDefaultProfilePicture();
  }

  public function getMaxProfilePictureSize() {
    return $this->model->getMaxProfilePictureSize();
  }

  public function getProfilePicturePath() {
    return $this->model->getProfilePicturePath();
  }

  public function getProfilePictureURL() {
    return $this->model->getProfilePictureURL();
  }

  public function strImageExtension() {
    return $this->model->strImageExtension();
  }

  public function where($field, $value1=NULL, $value2=NULL) {
    if (func_num_args() == 2)
      return $this->model->where($field, $value1);
    return $this->model->where($field, $value1, $value2);
  }
}
