<?php namespace Repositories\WATEvent;

use Repositories\WATEvent\WATEventRepository;
use WATEvent;

class EloquentWATEventRepository implements WATEventRepository
{
  protected $model;

  public function __construct(WATEvent $model) {
    $this->model = $model;
  }

  public function all() {
    return $this->model->all();
  }

  public function createWATEvent($fields)
  {
    return $this->model->createWATEvent($fields);
  }

  public function find($id) {
    return $this->model->find($id);
  }
}
