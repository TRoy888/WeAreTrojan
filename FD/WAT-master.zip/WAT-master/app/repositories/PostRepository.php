<?php namespace Repositories\post;

interface PostRepository {

  /**
  *   Validate a post content
  *   @param $data is the given data
  *   @return True if data is valid,otherwise,false
  */
  public function isValid($data);
}
