<?php namespace Repositories;

use Illuminate\Support\ServiceProvider;
use Repositories\User\UserRepository;
use Repositories\User\EloquentUserRepository;
use Repositories\Admin\AdminRepository;
use Repositories\Admin\EloquentAdminRepository;
use Repositories\WATEvent\WATEventRepository;
use Repositories\WATEvent\EloquentWATEventRepository;
use User;
use Thread;
use Post;
use WATEvent;

use Repositories\thread\ThreadRepository;
use Repositories\thread\EloquentThreadRepository;
use Repositories\post\PostRepository;
use Repositories\post\EloquentPostRepository;


class RepositoriesServiceProvider extends ServiceProvider {
  public function register() {
    $this->app->bind ('Repositories\User\UserRepository', function ($app) {
      return new EloquentUserRepository(new User);
    });

    $this->app->bind ('Repositories\Admin\AdminRepository', function ($app) {
      return new EloquentAdminRepository(new Thread, new Post, new WATEvent);
    });
    $this->app->bind ('Repositories\WATEvent\WATEventRepository', function ($app) {
      return new EloquentWATEventRepository(new WATEvent);
    });

    $this->app->bind ('Repositories\thread\ThreadRepository', function ($app) {
      return new EloquentThreadRepository(new Thread);
    });

    $this->app->bind ('Repositories\post\PostRepository', function ($app) {
      return new EloquentPostRepository(new Post);

    });
  }
}
