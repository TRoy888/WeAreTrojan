<?php namespace Repositories\thread;

interface ThreadRepository {

  /**
   * Get the number of post
   * @param $thread_id is thread id
   * @return the number of post of the given thread
   */
  public function countPost($thread_id);

  /**
   * Valid if the input data of the thread
   * @param $data is given input data
   * @return true if the data is valid,otherwise,false
   */
  public function isValid($data);

   /**
    * Get post information based on given thread id
    * @param $thread_id is thread id
    * @return Get the posts from the given thread
    */
  public function getPostBythread($thread_id);

  /**
   * Find all the Hot Thread belonging to login user's categories
   * within one week period
   * @return hot threads in login user's categories
   */
   public function findHotTopicThread($time);

   /**
    * Find all the Threads belonging to the given category id
    *
    * @return threads in the given category
    */
   public function findThreadByCategory($category_id);


   /**
    * Find all the Threads
    *
    * @return all threads in DB
    */
   public function getAll();
}
