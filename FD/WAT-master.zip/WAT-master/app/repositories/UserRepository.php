<?php namespace Repositories\User;

interface UserRepository {
  /**
   * Get all of the user as an array
   * @return all user
   */
  public function all();

  /**
   * Check whether an extension file is allow to use or not.
   * @param $ext string, string of extension file
   * @return true if $ext allow, false if not.
   */
  public function allowImageExtension ($ext);

  /**
   * Create a user instance
   * @param $input array of the user instance data Ex. ['firstname'=>'MyFirstName']
   * @return new user instance with input data
   */
  public function create($input);

  /**
   * Create a user instance using field array
   * @param $fields array of the user table
   * @return new user instance
   */
  public function createUser($fields);

  /**
   * Get a user with specific $id
   * @param $id integer, User id.
   * @return return user instance with the specific id.
   */
  public function find($id);

  /**
   * Get a list of Thread categories that belong to the $id of that user.
   * @param $id integer, User id.
   * @return a list of Thread categories.
   */
  public function findCategory($id);

  /**
   * Get Path to the directory that keep user cover picture files.
   * @return string, user cover picture path.
   */
  public function getCoverPicturePath();

  /**
   * Get URL to the folder that keep user cover picture files.
   * @return string, user cover picture URL.
   */
  public function getCoverPictureURL();

  /**
   * Get User default cover picture path.
   * @return string, default cover picture path.
   */
  public function getDefaultCoverPicture();

  /**
   * Get User default profile picture path.
   * @return string, default profile picture pathl.
   */
  public function getDefaultProfilePicture();

  /**
   * Get Maximum size of user profile picture.
   * @return integer, Maximum size of profile picture.
   */
  public function getMaxProfilePictureSize();

  /**
   * Get Path to the directory that keep user profile picture files.
   * @return string, user profile pricture path.
   */
  public function getProfilePicturePath();

  /**
   * Get URL to the folder that keep user profile picture files.
   * @return string, user profile picture URL.
   */
  public function getProfilePictureURL();

   /**
    * Get String format of allow image extension. Ex. "jpg, jpeg, png"
    * @return string, image extension.
    */
  public function strImageExtension();

   /**
    * Query specific data in user table
    * @return array, list of matched row in the table.
    */
   public function where($field, $value1, $value2);
}
