<?php namespace Repositories\WATEvent;

interface WATEventRepository {
  /**
   * Get a list of all events
   * @return list of all events.
   */
  public function all();

  public function createWATEvent($fields);

  /**
   * Find an event from event's id.
   * @return an event instance.
   */
  public function find($id);
}
