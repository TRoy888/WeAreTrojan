<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::filter('admin', function() {
	if (Auth::user()->role->name != 'admin')
		return Redirect::to('/');
});

//thread
// Route::patch('/thread/{thread_id}/post/{post_id}', 'PostController@update');
Route::get('/addthread','ThreadController@create');
Route::resource('thread','ThreadController');
Route::patch('thread/{thread}',['as'=>'thread.update', 'uses'=>'ThreadController@update', 'before'=>'csrf']);
Route::put('thread/{thread}',['as'=>'thread.update', 'uses'=>'ThreadController@update', 'before'=>'csrf']);
Route::resource('thread.post','PostController');
Route::post('thread/{thread}/post', ['as'=>'thread.post.store', 'uses'=>'PostController@store', 'before'=>'csrf']);
Route::patch('thread/{thread}/post/{post}',['as'=>'thread.post.update', 'uses'=>'PostController@update', 'before'=>'csrf']);
Route::put('thread/{thread}/post/{post}',['as'=>'thread.post.update', 'uses'=>'PostController@update', 'before'=>'csrf']);

//Event
Route::resource('event', 'WATEventController');

Route::post('/like_thread', ['as'=>'like_thread', 'uses'=>'ThreadController@likeThread']);
Route::post('/unlike_thread', ['as'=>'unlike_thread', 'uses'=>'ThreadController@unlikeThread']);
Route::post('/dislike_thread', ['as'=>'dislike_thread', 'uses'=>'ThreadController@dislikeThread']);
Route::post('/undislike_thread', ['as'=>'undislike_thread', 'uses'=>'ThreadController@undislikeThread']);
Route::post('/report_thread', ['as'=>'report_thread', 'uses'=>'ThreadController@reportThread']);

Route::get('/home/{category_id}', ['as'=>'home', 'uses'=>'ThreadController@indexThreadByCategory']);
//Route::get('/home/hotthread', ['as'=>'hotthread', 'uses'=>'ThreadController@showHotThread']); This will go to /home/{category_id} anyway
//Route::get('/home/allthread', ['as'=>'allthread', 'uses'=>'ThreadController@showAllThread']); This will go to /home/{category_id} anyway
Route::get('/home', 'ThreadController@index');

//post
Route::post('/like_post', ['as'=>'like_post', 'uses'=>'PostController@likePost']);
Route::post('/unlike_post', ['as'=>'unlike_post', 'uses'=>'PostController@unlikePost']);
Route::post('/dislike_post', ['as'=>'dislike_post', 'uses'=>'PostController@dislikePost']);
Route::post('/undislike_post', ['as'=>'undislike_post', 'uses'=>'PostController@undislikePost']);
Route::post('/report_post', ['as'=>'report_post', 'uses'=>'PostController@reportPost']);

//authentication
Route::resource('/session','SessionController');
Route::get('/','SessionController@create');
Route::get('/login','SessionController@create');
Route::get('/logout', ['as'=>'logout', 'uses'=>'SessionController@destroy']);
Route::post('/session', ['as'=>'session.store', 'uses'=>'SessionController@store', 'before'=>'csrf']);

//user
Route::resource('/users','UserController');
Route::post('/updatepic', array('as'=>'updatepic', 'uses'=>'UserController@updatePicture'));
Route::post('/updatepassword', array('as'=>'updatepassword', 'uses'=>'UserController@updatePassword'));
Route::post('/see_notification', array('as'=>'notified', 'uses'=>'UserController@updateSeeNotification'));
/*
Update User Categories Example.

function updateUserCategoryList() {
	var postData = {
		set: ["4", "5"], 				//id of category that want to set.
		reset: ["1", "2", "3"] 	//id of category that want to reset.
	}

	alert(JSON.stringify(postDat));
	$.ajax({
		url:"{{{ asset('/updateCategories') }}}",
		type: "POST",
		data: JSON.stringify(postData),
		success: function(result){
			alert(result.success);
		},
		error: function (xhr, textStatus, errorThrown){
			var resp = jQuery.parseJSON(xhr.responseText);
			alert(resp);
		}
	})
};
*/
Route::post('/updateCategories', array('as'=>'update_user_categories', 'uses'=>'UserController@updateCategories'));

Route::get('/about', array('as'=>'about',function(){
	return View::make('layouts.about');
}));

//email confirmation
Route::get('registration/confirm/{confirmationCode}', [
    'as' => 'confirmation_path',
    'uses' => 'UserController@confirm'
]);

// Password remind/reset
Route::get('resetpassword', 'RemindersController@getRemind');
Route::post('resetpassword', 'RemindersController@postRemind');
Route::get('password/reset/{token}', [
    'as' => 'reset_path',
    'uses' => 'RemindersController@getReset'
]);
Route::post('password/reset', 'RemindersController@postReset');

//get school group information ex dornsif, viterbi
Route::get('/schoolGroup', array('as'=>'schoolgroup', function(){
	return Response::json(Config::get('school.group'));
}));

// Notifications
Route::delete('notifications/delete', array('uses' => 'NotificationController@destroy', 'as' => 'notification.destroy'));
Route::get('notifications', array('as'=>'notification', 'uses' => 'NotificationController@index'));
// Below route is deprecated (only for testing)?
//Route::get('notifications/create', array('as'=>'notifications_create', 'uses' => 'NotificationController@create'));
Route::get('notifications/redirect', array('as'=>'notifications_redirect', 'uses' => 'NotificationController@redirect'));
Route::get('notifications/dropdown', array('as'=>'notifications_dropdown', 'uses' => 'NotificationController@dropdown'));

// Search
Route::get('/search', ['as'=>'search', 'uses'=>'SearchController@index']);
Route::get('/search_popup', ['as'=>'quick_search', 'uses'=>'SearchController@quickSearch']);
Route::post('/search_popup', ['as'=>'quick_search_post', 'uses'=>'SearchController@quickSearch']);
Route::get('/search_detail', ['as'=>'search_detail', 'uses'=>'SearchController@search']);
Route::post('/search_detail', ['as'=>'search_detail_post', 'uses'=>'SearchController@search']);


/*ThreadCategories -> GET /threadCategories
Response in json
Example
{
    {id:id1, code:code1, name:name1},
    {id:id2, code:code2, name:name2},
    {id:id3, code:code3, name:name3}
}

Ex
function getAllThreadCategories() {
	$.ajax({
		url: "{{{ asset('/schoolGroup') }}}",
		type: "GET",
		success: function(result){
			for (var key in result) {
				result[key]['id']
				result[key]['code']
				result[key]['name']
			}
		}
	});
}*/
//get array of all thread categories name
Route::get('/threadCategories', array('as'=>'threadcategories', function(){
	return Response::json(ThreadCategory::all());
}));

/*JUST FOR TESTING*/
Route::get('/namview', function(){
	return View::make('mytest')->with('threads', Auth::user()->threads()->orderBy('created_at', 'desc')->paginate(1));
});

Route::get('test', function(){
	return Auth::user()->id;
});

// Administration
Route::get('/ajax/admin/reported_threads', array('as'=>'admin.reportedthreads', 'uses'=>'AdminController@getReportedThreads'));
Route::get('/ajax/admin/reported_posts', array('as'=>'admin.reportedposts', 'uses'=>'AdminController@getReportedPosts'));
Route::get('/ajax/admin/events', array('as'=>'admin.events', 'uses'=>'AdminController@showEvents'));
Route::post('/ajax/admin/verify_thread', array('as'=>'admin.thread.verify', 'uses'=>'AdminController@verifyThread'));
Route::post('/ajax/admin/verify_post', array('as'=>'admin.post.verify', 'uses'=>'AdminController@verifyPost'));
Route::post('/ajax/admin/delete_thread', array('as'=>'admin.thread.delete', 'uses'=>'AdminController@deleteThread'));
Route::post('/ajax/admin/delete_post', array('as'=>'admin.post.delete', 'uses'=>'AdminController@deletePost'));
Route::resource('admin', 'AdminController',array('only' => array('index', 'show')));
