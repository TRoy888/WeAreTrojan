<?php

/**
 * This test will verify that a new notification is properly written to the DB.
 *
 * @author Eirik Skogstad
 */
class NotificationTest extends TestCase {
    
    // Make sure in-memory database is migrated and mail is faked
    private function prepare() {
        Artisan::call('migrate');
        Mail::pretend(true);
        // Seed the database with test data
        $this->seed();
    }    

    /**
     * This function is run before all test cases in this file.
     */
    public function setUp() {
        parent::setUp();
        
        // Call prepare ONLY when you need to migrate and seed test db:
        //$this->prepare();
        
        // Encapsulate test cases in a transaction
        DB::beginTransaction();
    }
    
    /**
     * This function is run after all test cases in this file have finished.
     */
    public function tearDown() {
        parent::tearDown();
        
        // Roll back the database transaction to clean up the test db
        DB::rollBack();
    } 

    /**
     * Add a 'Like' notification to a thread and verify that the notification
     * was properly recorded in the database.
     */
    public function testaddNotification() {
        // Find a thread to 'like' and a user to act as the 'liker'
        $thread = Thread::find(1);
        $sender = User::find(1);
        
        // Get the author of the thread (who will receive the notification)
        $author = $thread->user;
        
        // Create and send the notification
        $notification = new Notification();
        $author->addNotification($notification)
                ->setType('Like')
                ->setObject($thread, 'thread')
                ->setMessage($sender->first_name.' likes your thread!')
                ->setSender($sender)
                ->send();
        
        // Fetch the notification
        $notification = $author->notifications()->first();
        
        // Check if notification was found, check notification fields in assertions:
        if ($notification) {
            $this->assertTrue($notification->notification_type == 'Like', 'Wrong notification type');
            $this->assertTrue($notification->object_id == $thread->id, 'Wrong ID for notification object');
            $this->assertTrue($notification->object_type == get_class($thread), 'Wrong classname (type) for notification object');
            $this->assertTrue($notification->message == $sender->first_name.' likes your thread!', 'Wrong notification message');

            $this->assertTrue($notification->to_user == $author->id, 'The notification was not sent to the correct user');
            $this->assertTrue($notification->from_user == $sender->id, 'The notification was not sent from the correct user');            
        } else {
            $this->fail('The thread author did not receive the notification.');
        }
    }
}
