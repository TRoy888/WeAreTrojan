<?php

class PostControllerTest extends TestCase {

  /**
   * A basic functional test example.
   *
   * @return void
   */
   public function setUp()
   {
       parent::setUp();

       Session::start();

   }

   public function testCreatePost(){
     $userId = 1;
     Auth::loginUsingId($userId);
     $input = [
       'postcontent' => "TestPostContent",
       'thread_id'=> 1
     ];

     $response = $this->call('POST', 'thread/1/post', $input);
     $this->assertResponseStatus(302);
   }

  public function testUpdatePost(){
       $post = DB::table('posts')->where('detail','TestPostContent')->get();
       $userId = $post['0']->user_id;
       Auth::loginUsingId($userId);
       $input = [
         'postcontent' => 'Modify PostContent'
       ];
       $this->action('PUT', 'PostController@update', array($post['0']->thread_id,$post['0']->id),$input);
       $this->assertResponseOk();

       $post = DB::table('posts')->where('id',$post['0']->id)->get();
       $this->assertEquals('Modify PostContent', $post['0']->detail);

  }

  public function testDeletePost(){
    $post = DB::table('posts')->where('detail','Modify PostContent')->get();
    $userId = $post['0']->user_id;
    Auth::loginUsingId($userId);

    $this->action('DELETE', 'PostController@destroy', array($post['0']->thread_id,$post['0']->id));
    $this->assertResponseStatus(302);

    DB::table('posts')->where('id',$post['0']->id)
                  ->delete();
  }

  // public function testThatTrueIsTrue()
  // {
  //   $this->assertTrue(true);
  // }
}
