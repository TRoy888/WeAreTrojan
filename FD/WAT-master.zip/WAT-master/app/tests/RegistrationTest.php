<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of RegistrationTest
 *
 * @author Eirik Skogstad
 */
class RegistrationTest extends TestCase {

    public function setUp() {
        parent::setUp();
        $this->markTestSkipped('Register user test skipped.');
    }

    public function testCreateUser() {
        $params = [
            'firstname' => 'Eirik',
            'lastname' => 'Skogstad',
            'email' => 'skogstad',
            'password' => 'iameirik',
            'password_confirmation' => 'iameirik'
        ];

        $this->action('POST', 'UserController@store', null, $params);


        $user = DB::table('users')->first();

        $this->assertTrue($user->first_name == $params['firstname'], 'No match');
    }
}
