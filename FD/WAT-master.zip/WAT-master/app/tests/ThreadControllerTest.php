<?php

class ThreadControllerTest extends TestCase {

  /**
   * A basic functional test example.
   *
   * @return void
   */
  //  public function __construct(){
  //    $this->mock = Mockery::mock('Eloquent','Thread');
  //  }
  //  public function tearDown(){
  //    Mockery::close();
  //  }

   public function setUp()
   {
       parent::setUp();

       Session::start();

       // Enable filters
       //Route::enableFilters();
   }

   public function testCreateThread(){

        $thread = new Thread;
        // Thread could save
        $userId = 1;
    		Auth::loginUsingId($userId);
        $input = [
          'topic' => "What's BFS ?",
          'detail'=> "BFS is a level-by-level search",
          'category-selection' => [1,2]
        ];

        $response = $this->call('POST', '/thread', $input);
        $this->assertResponseStatus(302);
   }

   public function testUpdateThread(){
        $thread = DB::table('threads')->where('topic','What\'s BFS ?')->get();
      
        $userId = $thread[0]->user_id;
    		Auth::loginUsingId($userId);
        $input = [
          'topic' => 'What\'s BFS ?',
          'detail'=> 'DFS is a depth first search',
          'category-selection' => [2,3]
        ];
        $this->action('PUT', 'ThreadController@update', $thread[0]->id, $input);
        $this->assertResponseOk();

        $thread = DB::table('threads')->where('topic','What\'s BFS ?')->get();
        $this->assertEquals('DFS is a depth first search', $thread[0]->detail);
   }

   public function testDeleteThread(){
     $thread = DB::table('threads')->where('topic','What\'s BFS ?')->get();
     $userId = $thread[0]->user_id;
     Auth::loginUsingId($userId);
     $this->action('DELETE', 'ThreadController@destroy', $thread[0]->id);
     $this->assertResponseStatus(302);

     DB::table('thread_category_thread')->where('thread_id',$thread[0]->id)
                   ->delete();
     DB::table('threads')->where('topic','What\'s BFS ?')
            ->delete();

   }

   public function testIndex(){
     $response = $this->call('GET','thread');
   }
}
