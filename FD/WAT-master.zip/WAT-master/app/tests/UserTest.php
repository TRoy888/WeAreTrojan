<?php

class UserTest extends TestCase {

	public function setup()
	{
		parent::setup();
	}

	/**
	 * A basic functional test example.
	 *
	 * @return void
	 */
	public function testUnauthorizedPageAccess() {
		Route::enableFilters();
    $this->call('GET', '/users');
    $this->assertRedirectedTo('/login');
		$this->client->request('GET', '/users');
		$this->assertTrue($this->client->getResponse()->isRedirect());
	}

	public function testLoginSuccess() {
		$userId = 1;
		Auth::loginUsingId($userId);
		$this->client->request('GET', '/users');
		$this->assertTrue($this->client->getResponse()->isRedirect());
		$this->call('GET', '/users/'.$userId);
		$this->assertResponseOk();
	}

	public function testUpdateUser() {
		$user = new User();
		$user->role()->associate(UserRole::where('name', 'user')->first());

		$updateField = [
				'firstname' => 'first',
				'lastname' => 'last',
				'degree' => 'degree',
				'school' => 'school',
				'description' => 'testDescription',
				'class' => 'testClass',
				'email' => 'ttestUpdateUserd@usc.edu'
		];
		$this->be($user);
		$this->action('PUT', 'UserController@update', $user->id, $updateField);
		$this->assertResponseOk();
		$user->delete();
	}

	public function testUpdateUserProfilePicture() {
		$path = public_path()."/images/";
		$filename = 'test.jpg';
		$user = new User();
		$user->role()->associate(UserRole::where('name', 'user')->first());
		$file = new \Symfony\Component\HttpFoundation\File\UploadedFile($path.$filename, $filename);
		$this->be($user);
		$this->call('POST', '/updatepic', ['inputtype'=>'profile', 'x1'=>'0', 'x2'=>'10', 'y1'=>'0','y2'=>'10'], ['image_file'=>$file]);
		$this->assertResponseOk();
		$user->delete();
	}

	public function testUpdateUserPassword() {
		$oldpwd = '123456';
		$newpwd = '123456789';
		$user = new User();
		$user->role()->associate(UserRole::where('name', 'user')->first());
		$user->password = Hash::make($oldpwd);
		$updateField = [
			'oldpassword' => $oldpwd,
			'newpassword' => $newpwd];
		$this->be($user);
		$this->call('POST', '/updatepassword', $updateField);
		$this->assertResponseOk();
		$this->assertTrue(Hash::check($newpwd, $user->password));
		$user->delete();
	}

	public function testCreateUser() {
		$input = [
			'firstname' => 'testfirstname',
			'lastname' => 'testlastname',
			'email' => 'testemail',
			'password' => 'asdfasdf',
			'password_confirmation' => 'asdfasdf'];

/*		$fakeRedir = Mockery::mock('Illuminate\Http\RedirectResponse');
		Redirect::shouldReceive('back')->once()->andReturn($fakeRedir);
		Redirect::shouldReceive('withErrors')->once()->andReturn($fakeRedir);
*/
    $response = $this->call('POST', '/users', $input);
		$this->assertViewHas('confirmation_code');
		User::where('first_name', $input['firstname'])->delete();
	}
}
