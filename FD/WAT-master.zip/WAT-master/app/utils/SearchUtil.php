<?php
/**
* What: This class is used to provide indexing, reindexing, and deleting indices in/from Elasticsearch for wat system
* Why: This class will make integration between WAT and elasticsearch used in WAT's search features easier and maintainable.
* How: This class will use PHP elasticsearch API provided by the elasticsearch team, and it can be located
*   via 'http://www.elastic.co/guide/'
* Use-Cases: This class does not directly implement any Use-case, but it supports a use-case 'Search Forum'
*/
class SearchUtil{
  public static $client;
  static function init(){
    $params = array();
    $params['hosts'] = Config::get('wat/search.elasticsearch_hosts');
    self::$client = new Elasticsearch\Client($params);
  }

  /**
  * Add a thread document to an elasticsearch server so that it will become searchable
  * @param Thread: a thread model used in WAT system
  * @return Integer: id of the index data used in Elasticsearch
  *   , which will be the same id used in the passed thread instance
  */
  public static function addThread($thread){
    if(!($thread instanceof Thread))
      throw new InvalidArgumentException('The parameter must be an instance of a Thread class');
    $params = array();
  	$params['body']  = array(
      'topic' => strip_tags($thread->topic)
      , 'detail' => strip_tags($thread->detail)
      , 'deleted' => $thread->deleted
      , 'like_amt' => $thread->like_amt
      , 'dislike_amt' => $thread->dislike_amt
      , 'created_at' => $thread->created_at
      , 'updated_at' => $thread->updated_at);
  	$params['index'] = 'wat';
  	$params['type']  = 'threads';
  	$params['id']    = $thread->id;
    return self::$client->index($params)['_id'];
  }

  /**
  * Add a post document to an elasticsearch server so that it will become searchable.
  * @param Post: a post model used in WAT system.
  * @return Integer: id of the index data used in Elasticsearch
  *   , which will be the same id used in the passed post instance.
  */
  public static function addPost($post){
    if(!($post instanceof Post))
      throw new InvalidArgumentException('The parameter must be an instance of a Post class');
    $params = array();
  	$params['body']  = array(
      'detail' => strip_tags($post->detail)
      , 'deleted' => $post->deleted
      , 'like_amt' => $post->like_amt
      , 'dislike_amt' => $post->dislike_amt
      , 'created_at' => $post->created_at
      , 'updated_at' => $post->updated_at
      , 'thread_id' => $post->thread_id);
  	$params['index'] = 'wat';
  	$params['type']  = 'posts';
  	$params['id']    = $post->id;
  	return self::$client->index($params)['_id'];
  }

  /**
  * Add a user document to an elasticsearch server so that it will become searchable.
  * @param User: a user model used in WAT system.
  * @return Integer: id of the index data used in Elasticsearch
  *   , which will be the same id used in the passed user instance.
  */
  public static function addUser($user){
    if(!($user instanceof User))
      throw new InvalidArgumentException('The parameter must be an instance of a User class');
    $params = array();
  	$params['body']  = array(
      'email' => $user->email
      , 'first_name' => strip_tags($user->first_name)
      , 'last_name' => strip_tags($user->last_name)
      , 'degree' => strip_tags($user->degree)
      , 'school' => strip_tags($user->school)
      , 'summary_profile' => strip_tags($user->summary_profile)
      , 'hobbies' => strip_tags($user->hobbies)
      , 'other' => strip_tags($user->other)
      , 'class' => strip_tags($user->class)
      , 'picture_url' => $user->picture_url
      , 'created_at' => $user->created_at
      , 'updated_at' => $user->updated_at);
  	$params['index'] = 'wat';
  	$params['type']  = 'users';
  	$params['id']    = $user->id;
  	return self::$client->index($params)['_id'];
  }

  /**
  * Edit an existing thread document in an elasticsearch server
  *   (This method will internally call addThread as the elasticserach API uses
  *   the same method for both creating and updating (indexing), but this method
  *   would provide more readable codes)
  * @param Thread: a thread instance used in WAT system.
  * @return Integer: id of the indexed document used in Elasticsearch
  *   , which will be the same id used in the passed Thread instance.
  */
  public static function editThread($thread){
    return self::addThread($thread);
  }

  /**
  * Edit an existing post document in an elasticsearch server
  *   (This method will internally call addPost as the elasticserach API uses
  *   the same method for both creating and updating (indexing), but this method
  *   would provide more readable codes)
  * @param Post: a post instance used in WAT system.
  * @return Integer: id of the indexed document used in Elasticsearch
  *   , which will be the same id used in the passed post instance.
  */
  public static function editPost($post){
    return self::addPost($post);
  }

  /**
  * Edit an existing user document in an elasticsearch server
  *   (This method will internally call addUser as the elasticserach API uses
  *   the same method for both creating and updating (indexing), but this method
  *   would provide more readable codes)
  * @param User: a user instance used in WAT system.
  * @return Integer: id of the indexed document used in Elasticsearch
  *   , which will be the same id used in the passed User instance.
  */
  public static function editUser($user){
    return self::addUser($user);
  }

  /**
  * Delete a thread document from an elasticsearch server so that it will be no longer searchable.
  * @param Thread: an instance of a Thread model that will be deleted from the elasticsearch server.
  * @return Integer: id of the deleted thread document used in the elasticsearch server
  *   , which will be the same id used in the passed thread instance.
  */
  public static function deleteThread($thread){
    if(!($thread instanceof Thread))
      throw new InvalidArgumentException('The parameter must be an instance of a Thread class');
    $params = array();
    $params['index'] = 'wat';
    $params['type'] = 'threads';
    $params['id'] = $thread->id;
    return self::$client->delete($params)['_id'];
  }

  /**
  * Delete a post document from an elasticsearch server so that it will be no longer searchable.
  * @param Post: an instance of a Post model that will be deleted from the elasticsearch server.
  * @return Integer: id of the deleted post document used in the elasticsearch server
  *   , which will be the same id used in the passed post instance.
  */
  public static function deletePost($post){
    if(!($post instanceof Post))
      throw new InvalidArgumentException('The parameter must be an instance of a Post class');
    $params = array();
    $params['index'] = 'wat';
    $params['type'] = 'posts';
    $params['id'] = $post->id;
    return self::$client->delete($params)['_id'];
  }

  /**
  * Delete a user document from an elasticsearch server so that it will be no longer searchable.
  * @param User: an instance of a Post model that will be deleted from the elasticsearch server.
  * @return Integer: id of the deleted user document used in the elasticsearch server
  *   , which will be the same id used in the passed user instance.
  */
  public static function deleteUser($user){
    if(!($user instanceof User))
      throw new InvalidArgumentException('The parameter must be an instance of a User class');
    $params = array();
    $params['index'] = 'wat';
    $params['type'] = 'users';
    $params['id'] = $user->id;
    return self::$client->delete($params)['_id'];
  }

  /**
  * Query threads, posts, users in the Elasticsearch server.
  * @param String: a query string
  * @return Object an returned by the Elasticsearch's PHP API
  */
  public static function search($query_string, $pageNumber, $target){
    if(!empty($query_string) && is_int($pageNumber)){
      $searchParams = self::generateCommonSearchParameters($query_string);
      $searchParams['type'] = [$target];
      $searchParams['size'] = Config::get('wat/search.number_of_search_result');
      $searchParams['from'] = Config::get('wat/search.number_of_search_result')*($pageNumber-1);
      $highlightParams = [
        'fields' => ['topic' => ['index_options' => 'offsets', 'number_of_fragments' => 0],
                      'topic.std' => ['index_options' => 'offsets', 'number_of_fragments' => 0],
                      'detail' => ['index_options' => 'offsets', 'number_of_fragments' => 0],
                      'detail.std' => ['index_options' => 'offsets', 'number_of_fragments' => 0],
                      'email' => ['index_options' => 'offsets', 'number_of_fragments' => 0],
                      'email.std' => ['index_options' => 'offsets', 'number_of_fragments' => 0],
                      'first_name' => ['index_options' => 'offsets', 'number_of_fragments' => 0],
                      'first_name.std' => ['index_options' => 'offsets', 'number_of_fragments' => 0],
                      'last_name' => ['index_options' => 'offsets', 'number_of_fragments' => 0],
                      'last_name.std' => ['index_options' => 'offsets', 'number_of_fragments' => 0]
                    ]
      ];
      $searchParams['body']['highlight'] = $highlightParams;
      $threadFields = ['topic'
                      // , 'detail' //sharing a detail field from the postFields
                      ];
      $postFields = ['detail',
                      'thread_id'
                    ];
      $userFields = ['email'
                    , 'first_name'
                    , 'last_name'
                    , 'picture_url'
                    , 'degree'
                    , 'school'
                    , 'summary_profile'
                    , 'hobbies'
                    , 'other'
                    , 'class'];
      $searchParams['body']['fields'] = array_merge($threadFields, $postFields, $userFields);
      return self::$client->search($searchParams);
    }
    return false;
  }

  /**
  * Query short version of the threads, posts, and users in the Elasticsearch server.
  * @param String: a query string
  * @return Object: an object returned by the ElasticSearch's PHP API
  */
  public static function quickSearch($query_string){
    if(!empty($query_string)){
      $searchParams = self::generateCommonSearchParameters($query_string);
      $searchParams['type'] = ['threads', 'posts', 'users'];
      $searchParams['size'] = Config::get('wat/search.number_of_search_result_in_dropdown');
      $highlightParams = [
        'fields' => ['topic' => ['index_options' => 'offsets'],
                      'topic.std' => ['index_options' => 'offsets'],
                      'detail' => ['index_options' => 'offsets'],
                      'detail.std' => ['index_options' => 'offsets'],
                      'first_name' => ['index_options' => 'offsets'],
                      'first_name.std' => ['index_options' => 'offsets'],
                      'last_name' => ['index_options' => 'offsets'],
                      'last_name.std' => ['index_options' => 'offsets']
                    ]
      ];
      $searchParams['body']['highlight'] = $highlightParams;
      $searchParams['body']['fields'] = ['first_name', 'last_name', 'picture_url', 'thread_id'];
      return self::$client->search($searchParams);
    }
    return false;
  }

  /**
  * Genearate common parameters for querying threads, posts, and users data in the Elasticsearch server
  * @param String: a query string
  * @return Object: an object constructed in the format accepted by the Elasticsearch server.
  */
  private static function generateCommonSearchParameters($query_string){
    $queryParams = [
      'multi_match' => [
        'query' => $query_string,
        'type' => 'cross_fields',
        'fields' => ['topic',
                      'topic.std',
                      'detail',
                      'detail.std',
                      'email',
                      'email.std',
                      'first_name',
                      'first_name.std',
                      'last_name',
                      'last_name.std',
                      // 'degree',
                      // 'degree.std',
                      // 'school',
                      // 'school.std',
                      // 'summary_profile',
                      // 'summary_profile.std',
                      // 'hobbies',
                      // 'hobbies.std',
                      // 'other',
                      // 'other.std',
                      // 'class',
                      // 'class.std'
                    ]
      ]
    ];
    $searchParams['index'] = 'wat';
    $searchParams['body']['query'] = $queryParams;
    return $searchParams;
  }
}
SearchUtil::init();
