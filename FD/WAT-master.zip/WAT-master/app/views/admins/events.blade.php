@foreach($events as $event)
<div class="panel panel-default">
  <div class="panel-heading clearfix">
    <strong>{{$event->topic}}</strong>
  </div>
  <div class="panel-body">
    <p>{{$event->detail}}</p>
    <div>
      <time class="timeformat" datetime="{{$event->start_time}}"></time>
      <time class="timeformat" datetime="{{$event->end_time}}"></time>
      <p>{{$event->location}}</p>
      <p>{{$event->point_for_joining}}</p>
    </div>
  </div>
</div>
@endforeach
{{$events->links()}}
