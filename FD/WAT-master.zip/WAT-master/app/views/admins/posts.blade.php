@foreach($posts as $post)
<div class="panel panel-default">
  <div class="panel-heading clearfix">
    <strong>{{ HTML::linkAction('ThreadController@show',"Go to the post",array($post->thread->id, "#post-anchor-".$post->id),array()) }}</strong>
  </div>
  <div class="panel-body">
    <p>{{$post->detail}}</p>
    <div class="btn-group">
       <a id='post-verify-btn-{{$post->id}}' href="#" class="btn btn-default btn-sm"><span class="fa fa-check-circle" onclick="post.verify({{$post->id}}, {{Auth::user()->id}})"> Verify</span></a>
       <a id='post-delete-btn-{{$post->id}}' href="#" class="btn btn-default btn-sm"><span class="fa fa-times-circle" onclick="post.delete({{$post->id}}, {{Auth::user()->id}})"> Delete</span></a>
    </div>
  </div>
</div>
@endforeach
{{$posts->links()}}
