@extends('layouts.default')

@section('header')
{{ HTML::style('lib/eonasdan-bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css'); }}
{{ HTML::style('lib/cropper/cropper.min.css'); }}
@stop

@section('js')
{{ HTML::script('lib/eonasdan-bootstrap-datetimepicker/js/moment.min.js') }}
{{ HTML::script('lib/eonasdan-bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js') }}
{{ HTML::script('lib/cropper/cropper.min.js') }}
<script>
var verify_thread_url = "{{route('admin.thread.verify')}}"
    , verify_post_url = "{{route('admin.post.verify')}}"
    , delete_thread_url = "{{route('admin.thread.delete')}}"
    , delete_post_url = "{{route('admin.post.delete')}}"
    , event_store_url = "{{route('event.store')}}"
    , create_event_form = $('#event-create-form')
    , reported_threads_url = "{{route('admin.reportedthreads')}}"
    , reported_posts_url = "{{route('admin.reportedposts')}}"
    , events_url = "{{route('admin.events')}}";
</script>
{{ HTML::script('js/admin/show.js') }}
@stop

@section ('content')
<div class="container" style="padding-top:60px;">
  <div id='message-div' class="row" style='display:none;'></div>
  <div class="row"><!--create event row-->
    <div id='create-event-div' class="row" style='margin-bottom:10px; display:none;'></div>
  </div>
  <div class="row"><!--content row-->
    <!--Left side menu bar-->
    <div class="col-md-3">
      <button id='create-event-btn' class="btn btn-default vcenter">Create Event</button>
    </div>
    <!--End Left side menu bar-->

    <!--Main content-->
    <div class="col-md-9">
      <!--Main content | Tab nav-->
      <ul id="admin-tab-bar" class="nav nav-tabs" role="tablist" style="margin-bottom:10px;">
        <li role="presentation" class="active">
          <a id="thread-tab-bar" href="#thread-tab-content" aria-controls="thread" role="tab" data-toggle="tab">Reported threads</a>
        </li>
        <li role="presentation">
          <a id="post-tab-bar" href="#post-tab-content" aria-controls="post" role="tab" data-toggle="tab">Reported posts</a>
        </li>
        <!--
        <li role="presentation">
          <a id="event-tab-bar" href="#event-tab-content" aria-controls="event" role="tab" data-toggle="tab">Events</a>
        </li>-->
      </ul>
      <!--End Tab nav-->

      <!--Main content | Tab content-->
      <div id="admin-tab-content" class="tab-content">
        <!--Main content | Tab content | Tab Thread-->
        <div role="tabpanel" class="tab-pane active" id="thread-tab-content"></div>
        <!--End Tab Thread-->
        <!--Main content | Tab content | Tab Post-->
        <div role="tabpanel" class="tab-pane" id="post-tab-content"></div>
        <!--End Tab Post-->
        <!--Main content | Tab content | Tab Event --
        <div role="tabpanel" class="tab-pane" id="event-tab-content"></div>
        <!--End Tab Event-->
      </div>
      <!--End Tab content-->
    </div>
    <!--End Main content-->
  </div><!--content row-->
</div>
@stop
