@foreach($threads as $thread)
<div class="panel panel-default">
  <div class="panel-heading clearfix">
    <strong>{{ HTML::linkAction('ThreadController@show',$thread->topic,array($thread->id),array()) }}</strong>
  </div>
  <div class="panel-body">
    <p>{{$thread->detail}}</p>
    <div class="btn-group">
       <a id='thread-verify-btn-{{$thread->id}}' href="#" class="btn btn-default btn-sm"><span class="fa fa-check-circle" onclick="thread.verify({{$thread->id}}, {{Auth::user()->id}})"> Verify</span></a>
       <a id='thread-delete-btn-{{$thread->id}}' href="#" class="btn btn-default btn-sm"><span class="fa fa-times-circle" onclick="thread.delete({{$thread->id}}, {{Auth::user()->id}})"> Delete</span></a>
    </div>
  </div>
</div>
@endforeach
{{$threads->links()}}
