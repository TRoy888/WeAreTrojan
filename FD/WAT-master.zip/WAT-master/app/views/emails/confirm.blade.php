<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <h2>Please Verify Your Email Address</h2>

        <div>
            Thank you for creating a profile in the WAT network! <br/>
            Please follow the link below to verify your email address <br/>
            <a href="{{ URL::to('registration/confirm/' . $confirmation_code) }}">VERIFY</a>.<br/>
        </div>

    </body>
</html>