<div class="col-md-2"></div><!--give some space on left side-->
<div class="col-md-8">
  {{ Form::open(array('route'=>'event.store','files'=>true, 'method'=>'post', 'class'=>'form-horizontal', 'id'=>'event-create-form')) }}
    <div id="form-topic" class="form-group">
      {{ Form::label('topic', "Event's topic", array('class'=>'col-sm-3 control-label')) }}
      <div class="col-sm-9">
        {{ Form::text('topic', Input::old('topic'), array('class'=>'form-control', 'placeholder'=>"party, concert, giveaway")) }}
      </div>
    </div>
    <div id="form-location" class="form-group">
      {{ Form::label('location', 'Location', array('class'=>'col-sm-3 control-label')) }}
      <div class="col-sm-9">
        {{ Form::text('location', Input::old('location'), array('class'=>'form-control', 'placeholder'=>"1234 1st Street Los Angeles CA 98765")) }}
      </div>
    </div>
    <div id="form-start_time" class="form-group">
      {{ Form::label('start_time', 'StartTime', array('class'=>'col-sm-3 control-label')) }}
      <div class="col-sm-9">
        <div class='input-group date' id='start-date-input'>
          {{ Form::text('start_time', Input::old('start_time'), array('class'=>'form-control', 'placeholder'=>"mm/dd/yyyy hh:mm")) }}
          <span class="input-group-addon">
            <span class="glyphicon glyphicon-calendar"></span>
          </span>
        </div>
      </div>
    </div>
    <div id="form-end_time" class="form-group">
      {{ Form::label('end_time', 'EndTime', array('class'=>'col-sm-3 control-label')) }}
      <div class="col-sm-9">
        <div class='input-group date' id='end-date-input'>
          {{ Form::text('end_time', Input::old('end_time'), array('class'=>'form-control', 'placeholder'=>'mm/dd/yyyy hh:mm')) }}
          <span class="input-group-addon">
            <span class="glyphicon glyphicon-calendar"></span>
          </span>
        </div>
      </div>
    </div>
    <div id="form-point_for_joining" class="form-group">
      {{ Form::label('point_for_joining', 'RewardPoints', array('class'=>'col-sm-3 control-label')) }}
      <div class="col-sm-9">
        {{ Form::text('point_for_joining', Input::old('point_for_joining'), array('class'=>'form-control', 'placeholder'=>'1, 2, 5, 10, 100')) }}
      </div>
    </div>
    <div id="form-event_picture" class="form-group">
      {{ Form::label('event_picture', 'Event picture', array('class'=>'col-sm-3 control-label')) }}
      <div class="col-sm-9" style="margin-top:5px;">
        {{ Form::file('event_picture', array('id'=>'event-picture-file', 'accept'=>'image/*')) }}
        <div id='event-picture-preview' style='overflow: hidden;height:50px;margin-top:5px;display:none;'></div>
      </div>
    </div>
    <div id="form-details" class="form-group">
      {{ Form::label('details', 'Details', array('class'=>'col-sm-3 control-label')) }}
      <div class="col-sm-9">
        {{ Form::textarea('details', Input::old('details'), array('class'=>'form-control', 'placeholder'=>'Please put the event details here')) }}
      </div>
    </div>
    <div>
      <div class="pull-right">
        {{ Form::submit('Submit', array('class'=>'btn btn-default')) }}
        {{ Form::button('Cancel', array('id'=>'cancel-create-event-btn','class'=>'btn btn-default')) }}
      </div>
    </div>
    {{ Form::hidden('image_x', Input::old('image_x'), array('id'=>'form-input-image-x')) }}
    {{ Form::hidden('image_y', Input::old('image_y'), array('id'=>'form-input-image-y')) }}
    {{ Form::hidden('image_width', Input::old('image_width'), array('id'=>'form-input-image-width')) }}
    {{ Form::hidden('image_hight', Input::old('image_hight'), array('id'=>'form-input-image-hight')) }}
  {{ Form::close() }}

<!-- Cropped event picture modal -->
  <div class="modal fade" id="event-cropper-modal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
          <div id="event-cropper">
            <img id="event-picture-img" src="" alt="Event Picture">
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
<div class="col-md-2"></div><!--give some space on right side-->
