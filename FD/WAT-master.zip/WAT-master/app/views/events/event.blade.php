@extends('layouts.default')
@section('header')
{{HTML::style('js/fullcalendar/fullcalendar.css')}}
{{HTML::style('css/events/eventIndex.css'); }}
@stop


@section('js')
{{HTML::script('js/moment.min.js')}}
{{HTML::script('js/fullcalendar/fullcalendar.js')}}
<script>
      $(document).ready(function() {

          // page is now ready, initialize the calendar...
          var eventSource = <?php echo $eventData;?>;

          var eventArray = [];
          for( var topic in eventSource){
            if (eventSource.hasOwnProperty(topic)) {
                  eventArray[topic] ={
                    title: eventSource[topic]['topic'],
                    description: eventSource[topic]['detail'],
                    location: eventSource[topic]['location'],
                    point: eventSource[topic]['point_for_joining'],
                    imageUrl: eventSource[topic]['picture'],
                    description: eventSource[topic]['detail'],
                    start: eventSource[topic]['start_time'],
                    end: eventSource[topic]['end_time'],
                    allDay : false,
                    color: '#990000',     // an option!
                    textColor: '#FFCC00' // an option!
                  };
            }
          }

          $('#calendar').fullCalendar({
              // put your options and callbacks here
              header: {
        				left: 'prev,next today',
        				center: 'title',
                right: 'month,agendaWeek,agendaDay'
        			},
              eventLimit: true,
              allDayDefault: false,
              events: eventArray,
              eventClick:  function(event, jsEvent, view) {
                  $('#modalTitle').html(event.title).append("&nbsp;&nbsp;&nbsp;<small>Points:"+event.point+"</small>");
                  $('#eventPoint').html(event.point);
                  console.log(event);
                  var eventStart = moment(event.start).format("hh:mm A");
                  var eventEnd = moment(event.end).format("hh:mm A");

                  $('#eventLocation').html("Location: "+event.location);
                  $('#eventTime').html("Time:&nbsp;"+eventStart+"&nbsp; - &nbsp;"+eventEnd);
                  //$('#modalBody').html(event.description);
                  //$('#eventImage').attr('src',event.imageUrl);
                  $('#eventImage').css('background-image', 'url(' + event.imageUrl + ')');
                  $('#eventImage').css('background-size', 'cover');
                  $('#eventUrl').attr('href',event.url);
                  $('#eventDescription').html(event.description);
                  $('#fullCalModal').modal();
              }
          });

      });
</script>
@stop
<!--End of Javascript for search box-->
@section ('content')
    <div>
     <div class="container" style="background-color:white;" >

       <input type="hidden" id="eventSource" value={{$eventData}} />

       <div class="row" id="calendar"></div>

       <div id="fullCalModal" class="modal fade">
         <div class="modal-dialog">
             <div class="modal-content">
                 <div class="modal-header">
                     <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span> <span class="sr-only">close</span></button>
                     <h4 id="modalTitle" class="modal-title"></h4>
                 </div>
                 <div id="modalBody" class="modal-body">
                   <div>
                     <h5 id="eventLocationAndTime">
                       <div id="eventLocation"></div>
                       <div id="eventTime"></div>
                     </h5>
                    </div>

                  <div id = "eventImage" >
                    <!-- <img id = "eventImage" src="" alt="..." class="img-thumbnail"> -->

                  </div>

                  <div>
                    <h5>Description:</h5>
                    <p id = "eventDescription"></p>
                  </div>

                </div>
                 <div class="modal-footer">
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                     <!-- <button class="btn btn-primary"><a id="eventUrl" target="_blank">Event Page</a></button> -->
                 </div>
             </div>
           </div>
         </div>
      </div>
   </div>
@stop
