@extends('layouts.default')
@section('header')
  <style>
    .parallax-window {
    min-height: 400px;
    background: transparent;
  }
    .image-shadow{
    box-shadow: 0 12px 12px -2px #232323;
    -moz-box-shadow: 0 12px 12px -2px #232323;
    -webkit-box-shadow: 0 12px 12px -2px #232323;
    }
  </style>
@stop
@section('js')
{{ HTML::script('js/parallax.min.js') }}
@stop
@section('content')
<section>
<div class="container" style="padding-top:170px;padding-bottom:100px;">
      <div class="row">
        <div class="col-xs-6" style="height:315px;"><h1 style="padding-top:70px;">Trojans Family Grows Stronger<br><small>Connect with your friends from different schools all in one place</small></h1></div>
        <div class="col-xs-6" style="text-align:center;"><img src="images/usclogo.jpg" class="image-shadow"/></div>
      </div>
      </div>
</section>
    <div class="parallax-window" data-parallax="scroll" data-position="top" data-bleed="10" data-image-src="images/usc3.jpg" data-natural-width="682" data-natural-height="401">
        </div>
<section>
<div class="container" style="padding-top:100px;padding-bottom:100px;">
      <div class="row">
        <div class="col-xs-6" style="text-align:center;"><img src="images/questions-mark.png"/></div>
        <div class="col-xs-6" style="height:315px;"><h1 style="padding-top:70px;">All questions get answered<br><small>One-stop shop to answer your questions</small></h1></div>
      </div>
      </div>
</section>
    <div class="parallax-window" data-parallax="scroll" data-position="top" data-bleed="10" data-image-src="images/usc4.jpg" data-natural-width="900" data-natural-height="414">
        </div>
<section>
<div class="container" style="padding-top:100px;padding-bottom:100px;">
      <div class="row">
        <div class="col-xs-6" style="text-align:center;"><img src="images/treasure.png"/></div>
                <div class="col-xs-6" style="height:300px;"><h1 style="padding-top:70px;">Earn We-Are-Trojans Point when you help other fellow trojans<br><small>By liking a thread, you can give another Trojans a WAT point, which can be exchanged for a cool swag from the bookstore</small></h1></div>
      </div>
      </div>
</section>
    <div class="parallax-window" data-parallax="scroll" data-position="top" data-bleed="10" data-image-src="images/usc7.jpg" data-natural-width="900" data-natural-height="414">
        </div>
<section>
<div class="container" style="padding-top:100px;padding-bottom:100px;">
      <div class="row">
        <div class="col-xs-6" style="height:315px;"><h1 style="padding-top:70px;">News and Events send directly to you<br><small>Stay up-to-date on news and events happening around campus</small></h1></div>
        <div class="col-xs-6" style="text-align:center;"><img src="images/envelope.png"/></div>
      </div>
      </div>
</section>
    <div class="parallax-window" data-parallax="scroll" data-position="top" data-bleed="10" data-image-src="images/scnumber1.jpg" data-natural-width="959" data-natural-height="617">
        </div>
<section>
<div class="container" style="padding-top:100px;padding-bottom:100px;">
      <div class="row">
        <div class="col-xs-6" style="text-align:center;"><img src="images/numberone.png"/></div>
        <div class="col-xs-6" style="height:315px;"><h1 style="padding-top:30px;">Striving for the number one spot<br><small>Compete with your fellow Trojans by helping others so you can gain more WAT points and be the number one in the leaderboard</small></h1></div>
      </div>
      </div>
</section>
    <div class="parallax-window" data-parallax="scroll" data-position="top" data-bleed="10" data-image-src="images/uscschool.jpg" data-natural-width="900" data-natural-height="414">
        </div>
<section>
<div class="container" style="padding-top:100px;padding-bottom:100px;">
        <div class="col-xs-12" style="text-align:center;">
          <h1>Are You Ready?</h1>
          <p><button type="button" class="btn btn-danger" onclick="window.location.href='{{route('home', array('hotthread'))}}'">I'm Ready!</button></p>
        </div>
      </div>
</section>
@stop