<!DOCTYPE html>
<html>
	<head>
	<?php date_default_timezone_set("America/Los_Angeles"); ?>
	<title>We Are Trojans Network</title>
	<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
	{{HTML::script('js/jquery-2.1.3.min.js')}}
  <meta name="viewport" content="width=device-width, initial-scale = 0.7, maximum-scale=1">
  {{HTML::script('js/bootstrap.js')}}
  {{HTML::style('css/bootstrap.min.css')}}
  {{HTML::script('js/jquery.notify.min.js')}}
  {{HTML::style('css/default/jquery.notify.css')}}
  {{HTML::style('css/default/notification.css')}}
  {{HTML::style('css/default/nav.css'); }}
	{{HTML::style('css/search.css')}}
	<script>
	//this piece of code must be placed here not in the separate js files as they require php
	  var nav_bar={}
		, quick_search_url = "{{route('quick_search_post')}}"
		, thread_url_link = "{{route('thread.show','thread_id')}}"
		, seen_notification_url = "{{route('notified')}}"
		, list_notification_url = "{{route('notifications_dropdown')}}"
		, user_url_link = "{{route('users.show','user_id')}}"
		, public_url = "{{asset('')}}";
		nav_bar.search_url = "{{route('search')}}";
	</script>
	<!--notification toggle-->
	<script type="text/javascript">
		$(document).ready(function () {
			$.get(list_notification_url,function(resultString){
				updatedropdown(resultString);
			});
			var windowSize;
			function getWinSize(){
				windowSize = $(window).width() < 993;
			}
			$(window).on("load resize",getWinSize);

			$("#notificationicon").click(function () {
				if({{Auth::user()->has_seen_notification}} != 1){
					$.post(seen_notification_url,function(resultString){
						console.log(resultString);
					});
				}
				//reset exclamation mark
				document.getElementById("notificationicon").innerHTML = "<span class='fa fa-bell'>Notification</span>";
				if(windowSize){
					//TODO: this path might change when notification page is done (also at line 289).
					window.location.href = "{{route('notification')}}";
				}else{
					$(this).toggleClass("open");
					$("#notificationMenu").toggleClass("open");
				}
			});
		});
	</script>
	<!--socket io for notification-->
	<!--<script src="http://cdn.socket.io/socket.io-1.3.4.js"></script>
	<script type="text/javascript">
		var socket = io.connect('http://127.0.0.1:3000/');
		socket.on('handshake', function (incoming) {
			socket.emit('check in', {userId: {{Auth::user()->id}}});
		});
		socket.on('notification', function (data) {
			document.getElementById("notificationicon").innerHTML = "<span class='fa fa-bell'>Notification</span><span class='notification-counter'><i class='fa fa-exclamation-circle'></i></span>";
			//Ajax to backend to retrieve new data about notification when there is new notification coming in
			$.get(list_notification_url,function(resultString){
				updatedropdown(resultString);
			});
			//textbox will popup
			if(data.is_event != 0){
				notify({
				type: "warning",
				title: '<a href="'+user_url_link.replace("user_id",data.userId)+'">'+data.user_firstname+' '+data.user_lastname+'</a>',
				message: data.text+' <b>'+data.threadtopic+'</b>',
				position: {
					x: "left",
					y: "bottom"
				},
				icon: '<img src="'+data.pic+'"/>',
				autoHide: true,
				delay: 6000,
				template: '<div class="notify"><div class="notify-text"></div></div>'
			});
			}else{
			notify({
				type: "warning",
				title: '<a href="'+user_url_link.replace("user_id",data.userId)+'">'+data.user_firstname+' '+data.user_lastname+'</a>',
				message: data.text+'<a href="'+thread_url_link.replace("thread_id",data.threadId)+'""> '+data.threadtopic+'</a>',
				position: {
					x: "left",
					y: "bottom"
				},
				icon: '<img src="'+data.pic+'"/>',
				autoHide: true,
				delay: 6000,
				template: '<div class="notify"><div class="notify-text"></div></div>'
			});
			}
		});
	</script>-->
	<!--SEARCH-->

	<!--Javascript for Search Pop-up Box-->
	<script>
	// 	(function($){
	//     $.fn.outside = function(ename, cb){
	//     	return this.each(function(){
	//       	// var $this = $(this)
	// 				// 	,	self = this;
	//
	//         // $(document).bind(ename, function tempo(e){
	//         // 	if(e.target !== self && !$.contains(self, e.target)){
	//         //     //cb.apply(self, [e]);
	//         //     if(!self.parentNode) $(document.body).unbind(ename, tempo);
	//         // 	}
	//     		// });
	// 			});
	//     };
	// }(jQuery));
		var request_search;
		function content () {
			if(request_search && request_search.readyState != 4){
				request_search.abort();
			}
			request_search = $.post(quick_search_url, {'query_text':$('#searchcontent').val()}, function(resultString){
	    	var result = jQuery.parseJSON(resultString);
				$("#searchMenu").html('');
				if(result){
					if(result['total'] == 0 && $('#searchcontent').val()!="") {
						// $('#searchMenu').hide();
						$("#searchMenu").append("<li>No Results Found</li>");
					}
					else {
						for(var key in result) {
						  var value = result[key]
							, highlight = value.highlight
							, item = document.getElementById('searchMenu');
						  if(value._type == "threads") {
							  if(highlight.topic){
								 var text = highlight.topic[0];
							  }
							  else if(highlight['topic.std']){
								 var text = highlight['topic.std'][0];
							  }
							  else if(highlight.detail){
								 var text = highlight.detail[0];
							  }
							  else{
								 var text = highlight['detail.std'][0];
							  }
							  $("#searchMenu")
								.append("<a href='"+thread_url_link.replace("thread_id",value._id)+"'><li class='ThreadClass'><div class=\"border\"><div><img src={{asset('images/search/Thread.png')}} style=\"height:40px;width:40px;\" alt=\"ThreadImage\"></div><div style=\"margin-top:-40px;margin-left:45px;overflow:hidden;height:40px;\">"+text+"</div></div></li></a>");
						  }
						  else if (value._type == "posts") {
							  var text = (highlight.detail)?highlight.detail[0]:highlight['detail.std'][0];
							  $("#searchMenu").append("<a href='"+thread_url_link.replace("thread_id",value.fields.thread_id)+"#post-anchor-"+value._id+"'><li class='PostClass'><div class=\"border\"><div><img src={{asset('images/search/Post.png')}} style=\"height:40px;width:40px;\"></div><div style=\"margin-top:-40px;margin-left:45px;overflow:hidden;height:45px;\">"+text+"</div></div></li></a>");
							  // $("#searchMenu").append("<a href='"+thread_url_link.replace("thread_id",value.fields.thread_id)+"#search_post_"+value._id+"'><li class='PostClass'><div class=\"border\"><div><img src={{asset('images/search/Post.png')}} style=\"height:40px;width:40px;\" alt=\"PostImage\"></div><div style=\"margin-top:-40px;margin-left:45px;overflow:hidden;height:45px;\">"+text+"</div></div></li></a>");
						  }
              else if (value._type == "users") {
							  if(value.highlight){
									var fname = (value.highlight.first_name)?value.highlight.first_name[0]:((value.highlight['first_name.std'])?value.highlight['first_name.std'][0]:"");
									var lname = (value.highlight.last_name)?value.highlight.last_name[0]:((value.highlight['last_name.std'])?value.highlight['last_name.std'][0]:"");
							  }
							  if(!fname){
									var fname = value.fields.first_name;
							  }
							  if(!lname){
									var lname = value.fields.last_name;
							  }
							  var text = fname+" "+lname;
							  $("#searchMenu").append("<a href='"+user_url_link.replace("user_id",value._id)+"'><li class='UserClass'><div class=\"border\"><div><img src='"+value.fields.picture_url[0] +"' style=\"height:40px;width:40px;\" alt=\"Profile\"></div><div style=\"margin-top:-40px;margin-left:45px;overflow:hidden;height:45px;padding-top:8px;\">"+text+"</div></div></li></a>");
						  }
				    }
					}
				}
	    });
    }

		function hidesearch() {
			$('#searchMenu').hide();
		}

		$(document).ready(function () {
      //UPDATED:
      //Keep track of intial placeholder value for searchcontent
			$('#searchcontent').each(function() {
				$(this).data('placeholder', $(this).attr('placeholder'));
			});
			//End

			//Delete the previously entered data to enable the functionality in moble view
			$(window).resize(function(){
				$('#searchMenu').hide();

				//Reset back to the placeholder field on re-size to mean the placeholder text message meaningful
				$('#searchcontent').val(function() {
					return this.defaultValue;
				});
				//End

				if($(window).width() < 992) {
					$('#searchcontent').attr('placeholder','Enter content: Hit search icon to view results');
				}
				else{
					$('#searchcontent').each(function() {
						$(this).attr('placeholder', $(this).data('placeholder'));
					});
				}
			});

			//UPDATED:End
			$('#searchcontent').focusout(function() {
				//$('#searchMenu').hide();
			});

			$('#searchcontent').keyup(function(event) {
				if(event.which == 13) {
					searchDetail();
					return;
  			}
				var width = $(window).width();
				if(width > 992){
					$('#searchMenu').hide();
					if($(this).hasClass("open")) {
						content();
						$('#searchMenu').show();
					}
					else{
						$(this).toggleClass("open");
						$("#searchMenu").toggleClass("open");
						content();
						$('#searchMenu').show();
					}
				}
			});

			function searchDetail(){
				window.location = nav_bar.search_url+"?query_text="+$("#searchcontent").val();
			};

			$("#search_button").click(function(){
				searchDetail();
			});
		});
	</script>
	<!--End of Javascript for search box-->
	<script>
		function updatedropdown(resultString){
			if(resultString.length == 0){
				var divtext = "<li style='text-align:center;'>No Notification</li>";
				document.getElementById("notificationdatabox").innerHTML = divtext;
			}
			else{
				var divtext = "";
				for( var i = 0; i<resultString.length; i++){
					if(resultString[i].is_read == 0){
						divtext +=
						"<li class='notif unread'><a href='{{URL::to('notifications/redirect?id="+resultString[i].object_id+"&type="+resultString[i].object_type+"')}}'><div class='imageblock'>"+
						"<img src='"+resultString[i].picture_url+"' style='height:55px;width:55px;'/>"
						+"</div><div class='messageblock'><div class='message'><span class='text-muted'><b>"
						+resultString[i].sender_string+"</b></span><br>"
						+resultString[i].message+
						"</div><div class='messageinfo'>"+
						resultString[i].timestamp+
						"</div><div></a></li>";
					}
					else{
						divtext +=
						"<li class='notif'><a href='{{URL::to('notifications/redirect?id="+resultString[i].object_id+"&type="+resultString[i].object_type+"')}}'><div class='imageblock'>"+
						"<img src='"+resultString[i].picture_url+"' style='height:55px;width:55px;'/>"
						+"</div><div class='messageblock'><div class='message'><span class='text-muted'><b>"
						+resultString[i].sender_string+"</b></span><br>"
						+resultString[i].message+
						"</div><div class='messageinfo'>"+
						resultString[i].timestamp+
						"</div><div></a></li>";
					}
					document.getElementById("notificationdatabox").innerHTML = divtext;
				}
			}
			console.log(resultString.length);
		}
	</script>
	@yield('header')
	</head>
	<body onclick="hidesearch()">
	<div class="wrapper">
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navheaderCollapsible">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
					<a href="{{route('home', array('hotthread'))}}"><img src="<?php echo URL::asset('images/icon.png');?>" class="pull-left" style="width:45px;height:auto; padding-top:7px; padding-right:5px;"/></a>
          {{link_to_route('home', 'We Are Trojans', array('hotthread'), array('class' => 'navbar-brand'))}}
        </div>
        <div id="navbar" class="navbar-collapse collapse navheaderCollapsible">
          <ul class="nav navbar-nav navbar-right">
            <li>{{link_to_route('home', 'Home', array('hotthread'), array('class' => 'fa fa-home'))}}</li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle fa" data-toggle="dropdown" role="button" aria-expanded="false"><img src="{{asset(Auth::user()->picture_url)}}" style="width:20px;height;20px"/> {{Auth::user()->first_name}}<span class="caret"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li>{{link_to_route('users.index', 'Profile', array(), array('class' => 'fa'))}}</li>
								@if (Auth::user()->role->name == 'admin')
								<li>{{link_to_route('admin.index', 'Admin', array(), array('class' => 'fa'))}}</li>
								@endif
                <li>{{link_to_route('logout', 'Logout', array(), array('class' => 'fa'))}}</li>
              </ul>
            </li>
						<li>{{link_to_route('event.index', ' Event', array(), array('class' => 'fa fa-calendar'))}}</li>
            <li>
            		<!-- User has seen the notification 1 = seen, 0 = not seen-->
            		@if(Auth::user()->has_seen_notification == 1)
            			<a href="#" id="notificationicon"><span class="fa fa-bell">Notification</span></a>
            		@else
            			<a href="#" id="notificationicon"><span class="fa fa-bell">Notification</span><span class='notification-counter'><i class='fa fa-exclamation-circle'></i></span></a>
            		@endif
            		<!-- comment this out because we need to implement this in the future-->
 						<ul id="notificationMenu" class="notifications">
						    <li class="titlebar">
						        <span class="title">Notifications</span>
						        <span class="settings"><i class="icon-cog"></i>
						        </span>
						     </li>
						     <div class="notifbox" id="notificationdatabox">
						     </div>
						      	<li class="seeall">
						        	{{link_to_route('notification', 'See All', array(), array('class' => ''))}}
						    	</li>
						    </ul>
					</li>
            <li><button type="button" class="btn add-color btn-sm btn-style" onclick="window.location='{{ URL::route('thread.create'); }}'">
              <span class="fa fa-comment fa-flip-horizontal" aria-hidden="true" id ="addThread" ></span> Add a thread
              </button>
            </li>
          </ul>
        <form class="navbar-form-alt">
            <div class="form-group">
              <div class="input-group" id="Searchdiv">
                <input type="text" class="form-control inputAB" id="searchcontent" placeholder="Search" autocomplete="off">
								<ul id="searchMenu" class="search_popup" style="margin-left:120px;width:400px;margin-top:-8px;border-radius:5px;"></ul>
                  <span class="input-group-btn">
                    <span class="btn btn-default" id="search_button"><span><i class="glyphicon glyphicon-search"></i></span></span>
                  </span>
              </div>
            </div>
          </form>
        </div>
      </div>
    </nav>
		@yield('content')
	</div>
		<footer class="footer">
			<div class="container" style="padding-top:5px;height:50px;">
				<div class="pull-right" id="footer-right">
					<a href="mailto:someone@gmail.com">
						<div style="margin-left:-40px;">
							<i id="social" class="fa fa-envelope-square fa-3x social-em"></i>
						</div>
						<div style="margin-top:-32px;">
							<span>Contact us</span>
						</div>
					</a>
					<div style="margin-left:-120px;margin-top:-20px;">
						{{link_to_route('about', 'About us')}}
					</div>
				</div>
				<div class="pull-left" id="footer-left">
					<a href="https://www.facebook.com"><i id="social" class="fa fa-facebook-square fa-3x social-fb"></i></a>
					<a href="https://twitter.com"><i id="social" class="fa fa-twitter-square fa-3x social-tw"></i></a>
					<a href="https://plus.google.com/"><i id="social" class="fa fa-google-plus-square fa-3x social-gp"></i></a>
				</div>
				<div class="text-align-center" id="footer-center">
					<div style="margin-top:10px;">
					Copyright © 2015 We Are Trojans Network
					</div>
				</div>
			</div>
		</footer>
		@yield('js')
	</body>
</html>
