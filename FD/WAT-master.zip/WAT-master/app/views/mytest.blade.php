<!DOCTYPE html>
<html>
<head>
<script src="//code.jquery.com/jquery-1.11.2.min.js"></script>
<script>
/*  $(document).ready(function(){
    $("#myform").submit(function(event){
      event.preventDefault();
      $.ajax({
        url: "{{{ asset('/schoolGroup') }}}",
        type: "GET",
        success: function(result){
          var str='';
          for (var key in result) {
            str = ''+str+result[key]+'\n'
          }
          alert(str);
        }
      });
    });
  });*/
  /*function sendAJAX() {
    var postDat = {
      set: ["1", "2"],
      reset: ["4", "5", "3"]
    }

    alert(JSON.stringify(postDat));
    $.ajax({
      url:"{{{ asset('/updateCategories') }}}",
      type: "POST",
      data: JSON.stringify(postDat),
      success: function(result){
        alert(result.success);
      },
      error: function (xhr, textStatus, errorThrown){
        var resp = jQuery.parseJSON(xhr.responseText);
        alert(resp);
      }
    })
  };*/
  /*function sendAJAX(){
    var report_thread_url = "{{route('report_thread')}}";
    var post_data = {
      'thread':'1',
      'user':'1'
    }

    $.ajax({
      type:"POST",
      url:report_thread_url,
      data: post_data
    })
    .done(function(msg){
      alert('done with msg:'+msg.success);
    })
    .fail(function(xhr, textStatus){
      var response = jQuery.parseJSON(xhr.responseText)
      alert('fail with errors:' + response.errors);
    });
  }*/
</script>
</head>
<body>
  <!--{{ Form::open (['enctype'=>'multipart/form-data', 'id'=>'myform']) }}
    <div>
      {{ Form::label('Select image to upload:') }}
      <!--{{ Form::file('fileToUpload', ['id'=>'fileToUpload']) }}--
      {{ Form::submit('Upload Image', ['name'=>'submit']) }}
    </div>
  {{ Form::close() }}-->
  <!--{{Form::button('Hit me', array('onclick'=>'sendAJAX()'))}}-->
  @foreach ($threads as $thread)
    <div>thread id is {{{$thread->id}}}</div>
    <div>post number of this thread is {{{$thread->post()->count()}}}</div>
    <div>Thread detail is {{$thread->detail}} </div>
    <div>Thread topic is {{$thread->topic}} </div>
    <div>like number of this thread is {{{$thread->like_amt}}}</div>
    <div>dislike number of this thread is {{{$thread->dislike_amt}}} </div>
  @endforeach
  {{$threads->links()}}
  <div>
    <img src='' id='image'/>
  </div>
</body>
</html>
