<!DOCTYPE html>
<html lang="en">
<head>
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
{{ HTML::style('css/include.css'); }}
{{ HTML::style('css/animate.css'); }}
<script type="text/javascript">
$(document).ready(function() {
  //$(".content").animate({top: 0},{duration:1000, easing:'easeInBack'});
  $(".content").addClass('animated fadeInUp');
});
</script>
<script type="text/javascript">
$(document).ready(function() {
  $(".align").addClass('animated fadeInLeft');
});
</script>
<script type="text/javascript">
var call_view = function(name)
  {
      window.location = name;
  }
</script>
</head>
<body>

  <div class="align"><h1 class="textchange">We Are Trojans Network</h1></p></div>
  <div class="container">
    <div class="content" id="div1">
      <div class="row vertical-offset-100">
        <div class="col-md-4 col-md-offset-4">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3 class="panel-title">Reset password</h3>
            </div>
            <div class="panel-body">
            @if($errors->any())
              <div class="alert alert-danger" role="alert">
                <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                <span class="sr-only">Error:</span>
                  {{$errors->first()}}
              </div>
            @endif
            
            @if (Session::has('error'))
                <div class="alert alert-info">{{ Session::get('error') }}</div>
            @elseif (Session::has('status'))
                <div class="alert alert-info">{{ Session::get('status') }}</div>
            @else
              {{ Form::open(array('action' => 'RemindersController@postRemind')) }}
                <fieldset>
                  <!-- Don't know why had problem using cellspacing and cellpadding..-->
                  <div class="form-group">
                <table>
                    <tr><td>{{ Form::label('email', 'Please enter your USC email address    ') }}</td></tr>
                  <tr>
                    <td width="76%">{{ Form::text('email', '', ['class' => 'form-control', 'placeholder' => 'tommy_trojan@usc.edu']) }}</td>
                  </tr>
                </table>
                  </div>
                  <div class="navbar-form navbar-left">
                    {{ Form::submit('Submit', array('class' => 'btn btn-lg btn-primary loginButton')) }}
                  </div>
                </fieldset>
                {{ Form::close() }}
            @endif
            {{ HTML::linkAction('SessionController@create', 'Back to login') }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
