@extends('layouts.default')

@section('header')
{{ HTML::style('css/forumpage.css'); }}
{{ HTML::style('css/search/search.css');}}
@stop
@section('js')

<script>
//this piece of code must be placed here not in the separate js files as they require php
  var search_url = "{{route('search_detail_post')}}"
  , results_per_page = {{Config::get('wat/search.number_of_search_result')}}
  , profile_url = decodeURI("{{route('users.show')}}")
  , thread_detail_url = decodeURI("{{route('thread.show')}}");
</script>

<script>
  var search = {}
  , request_search=null;
search.search = function(target, page) {
  if(request_search && request_search.readyState != 4){
    request_search.abort();
  }
  var dataFiller=null;
  if(target === 'threads'){
    dataFiller = fillThread;
  }
  else if(target === 'posts') {
    dataFiller = fillPost;
  }
  else if(target === 'users') {
    dataFiller = fillUser;
  }
  var params = {'query_text':search.query_text
              , 'page_number':page
              , 'search_target': target};
  request_search = $.post(search_url, params, dataFiller);
}

function fillThread(resultString){
  var result = jQuery.parseJSON(resultString)
  , total = result['total']
  , threads = result['hits']
  , thread_contents = $("#thread-contents").empty()
  , query_string = result['query_string'];
  if(total = result['total']==0){
    var span = $("<span></span>");
    span.html('No threads were found for "'+query_string+'"');
    thread_contents.append(span);
    return;
  }
  for(var i=0; i<threads.length; i++){
    var thread_template = $("#thread-template").find(".tp-thread-contents").clone();
    thread_template.find(".tp-thread-topic-link").attr("href",thread_detail_url.replace("{thread}",threads[i]["_id"]));
    //filling the data into the template
    if(threads[i]["highlight"]["topic"]){
      thread_template.find(".tp-thread-heading").html(threads[i]["highlight"]["topic"]);
    }
    else if(threads[i]["highlight"]["topic.std"]){
      thread_template.find(".tp-thread-heading").html(threads[i]["highlight"]["topic.std"]);
    }
    else{
      thread_template.find(".tp-thread-heading").html(threads[i]["fields"]["topic"]);
    }

    if(threads[i]["highlight"]["detail"]){
      thread_template.find(".tp-thread-detail").html(threads[i]["highlight"]["detail"]);
    }
    else if(threads[i]["highlight"]["detail.std"]){
      thread_template.find(".tp-thread-detail").html(threads[i]["highlight"]["detail.std"]);
    }
    else{
      thread_template.find(".tp-thread-detail").html(threads[i]["fields"]["detail"]);
    }
    thread_contents.append(thread_template);
  }
  //Paginaion Here
  paginationDiv(result, "thread-contents", "threads");
  //End
}

function fillPost(resultString){
  var result = jQuery.parseJSON(resultString)
  , total = result['total']
  , posts = result['hits']
  , post_contents = $("#post-contents").empty()
  , query_string = result['query_string'];
  if(total = result['total']==0){
    var span = $("<span></span>");
    span.html('No comments were found for "'+query_string+'"');
    post_contents.append(span);
    return;
  }
  for(var i=0; i<posts.length; i++){
    //Access the template
    var post_template = $("#post-template").find(".tp-post-contents").clone();
    post_template.attr("onclick", 'document.location="'+thread_detail_url.replace("{thread}",posts[i]["fields"]["thread_id"])+'#post-anchor-'+posts[i]["_id"]+'"');
    post_template.addClass("post-link");
    if(posts[i]["highlight"]["detail"]){
      var detail = posts[i]["highlight"]["detail"];
    }
    else if(posts[i]["highlight"]["detail.std"]){
      var detail = posts[i]["highlight"]["detail.std"];
    }
    else{
      var detail = posts[i]["fields"]["detail"];
    }
    post_template.find(".tp-post-detail").html(detail);
    post_contents.append(post_template);
  }
  //Paginaion Here
  paginationDiv(result, "post-contents", "posts");
  //End
}

function fillUser(resultString){
  var result = jQuery.parseJSON(resultString)
  , total = result['total']
  , user_contents = $("#user-contents").empty()
  , query_string = result['query_string']
  , users = result['hits'];
  if(total = result['total']==0){
    var span = $("<span></span>");
    span.html('No users were found for "'+query_string+'"');
    user_contents.append(span);
    return;
  }
  for(var i=0; i<users.length; i++){
    //Access the template
    var user_template = $("#user-template").find(".tp-user-contents").clone();
    user_template.find(".tp-user-pic-link").attr("href", profile_url.replace("{users}", users[i]["_id"]));
    user_template.find(".tp-user-name-link").attr("href", profile_url.replace("{users}", users[i]["_id"]));
    if(users[i]["highlight"]["first_name"]){
      var first_name = users[i]["highlight"]["first_name"];
    }
    else if(users[i]["highlight"]["first_name.std"]){
      var first_name = users[i]["highlight"]["first_name.std"];
    }
    else{
      var first_name = users[i]["fields"]["first_name"];
    }
    if(users[i]["highlight"]["last_name"]){
      var last_name = users[i]["highlight"]["last_name"];
    }
    else if(users[i]["highlight"]["last_name.std"]){
      var last_name = users[i]["highlight"]["last_name.std"];
    }
    else{
      var last_name = users[i]["fields"]["last_name"];
    }
    user_template.find(".tp-user-name").html(first_name+" "+last_name);
    user_template.find(".tp-user-school").html(users[i]["fields"]["school"]);
    user_template.find(".tp-user-image").attr("src", users[i]["fields"]["picture_url"][0]);
    user_contents.append(user_template);
  }
  //Paginaion Here
  paginationDiv(result, "user-contents", "users");
  //End
}

function paginationDiv(result, target_content_id, type) {
  var ul = $("#pagination-contents").find("ul").clone()
  , previous = $("#pagination-contents").find('li.pagination-previous-sign').clone()
  , next = $("#pagination-contents").find('li.pagination-next-sign').clone()
  , page_number = result['page_number']
  , total = result['total']
  , number_of_pages = Math.ceil(parseFloat(total)/parseFloat(results_per_page))
  , target_conents = $("#"+target_content_id);
  if(number_of_pages!=1){
    if(page_number==1){
      previous.attr("class", "disabled");
    }
    else{
      previous.attr('onclick',"search.search('"+type+"', "+(page_number-1)+")");
    }
    ul.append(previous);
    for(var i=1;i<=number_of_pages;i++){
      var li = $('<li onclick="search.search(\''+type+'\', '+i+')"></li>')
      , span=$('<span></span>');
      if(page_number==i){
        li.attr("class", "active");
      }
      span.html(i);
      li.append(span);
      ul.append(li);
      target_conents.append(ul);
    }
    if(page_number==number_of_pages){
      next.attr("class", "disabled");
    }
    else{
      next.attr('onclick',"search.search('"+type+"', "+(page_number+1)+")");
    }
    ul.append(next);
  }
}

$(document).ready(function () {
  search.query_text = decodeURI(window.location.search).slice(1).split("&")[0].split("=")[1];
  $("#threads").addClass("active");
  search.search('threads', 1);
});
</script>
@stop
@section('content')
<div class="container" style="padding-top:60px;">
  <div class="row">
    <div class="col-sm-12">
      <div  style="background-color: #f5f5f5" class="panel panel-default">
        <div class="panel-body" style="opacity:1.0">
          <div role="tabpanel">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active" onclick="search.search('threads', 1)">
                <a href="#threads" aria-controls="thread" role="tab" data-toggle="tab"><b>Thread</b></a>
              </li>
              <li role="presentation" onclick="search.search('posts', 1)">
                <a href="#posts" aria-controls="post" role="tab" data-toggle="tab"><b>Post</b></a>
              </li>
              <li role="presentation" onclick="search.search('users', 1)">
                <a href="#users" aria-controls="user" role="tab" data-toggle="tab"><b>User</b></a>
              </li>
            </ul>
            <!-- Tab panes -->
            <div class="tab-content">
              <!-- Thread Tab -->
              <div role="tabpanel" class="tab-pane" id="threads">
                <div id="thread-contents"></div>
              </div>
              <!-- End -->
              <!-- Post Tab -->
              <div role="tabpanel" class="tab-pane" id="posts">
                <div id="post-contents"></div>
              </div>
              <!-- End -->
              <!-- User Tab -->
              <div role="tabpanel" class="tab-pane" id="users">
                <div id="user-contents"></div>
              </div>
              <!-- End -->
            </div>
          </div><!--end tab Panel-->
        </div><!--end panel body-->
      </div><!--end panel-->
    </div><!--end col-xs-->
  </div><!--end row-->
</div><!--end container-->
<!---------------------------- Template parts-------------------------->
<!-- Thread Template -->
<div style="display:none;" id="thread-template">
  <div class="tp-thread-contents">
    <div class="panel panel-primary" style="margin-top:20px;">
      <div class="panel-body">
        <div><strong><a class="tp-thread-topic-link"><span style="color:#990000" class="tp-thread-heading"></span></a></strong></div>
        <div class="tp-thread-detail"></div>
      </div>
    </div>
  </div>
</div>
<!-- Post Template -->
<div style="display:none;" id="post-template">
  <div class="tp-post-contents">
    <div class="panel panel-primary" style="margin-top:20px;">
      <div class="panel-body">
        <div class="tp-post-detail"></div>
      </div>
    </div>
  </div>
</div>
<!-- User Template -->
<div style="display:none;" id="user-template">
  <div style="margin-top:20px;" class="tp-user-contents">
    <div class="pull-left image-left-bar">
      <a class="tp-user-pic-link"><img src="" class="picstyle tp-user-image" style="height:35px;width:35px;"></a>
    </div>
    <div class="post-content">
      <b><a class="tp-user-name-link"><span class="tp-user-name" style="color:#990000"></span></a></b>
      <div class ="text-mued user-detail">
        <span class="tp-user-school"><span>
      </div>
    </div>
  </div>
</div>
<!-- Pagination -->
<div id="pagination-contents" style="display:none;">
  <li class="pagination-previous-sign"><span aria-hidden="true">&laquo;</span></li>
  <li class="pagination-next-sign"><span aria-hidden="true">&raquo;</span></li>
  <ul class="pagination pagination-sm"></ul>
</div>
@stop
