<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
  <meta http-equiv="X-Frame-Options" content="deny">
</head>
<body id="container-main">
<div id="fullpage">
  <div class="login_section section">
    <div class="footer" id="about-us">
      <span>About Us</span>
    </div>
    <div class="login-title-container"><h1 class="login-title">We Are Trojans Network</h1></div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title">Log in</h3>
      </div>
      <div class="panel-body">
        @if($errors->any())
          <div class="alert alert-danger" role="alert">
            <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
            <span class="sr-only">Error:</span>
              {{$errors->first()}}
          </div>
        @endif
        @if(isset($confirmed))
            Thank you for registering!<br/>Your profile has been created.<br/>
        @endif
        {{ Form::open(array('route' => 'session.store')) }}
        <fieldset>
          <div class="form-group">
            <div>
              {{ Form::label('email', 'E-mail') }} <br/> {{ Form::text('email', '', ['class' => 'form-control', 'placeholder' => 'E-mail']) }}
            </div>
            <div>
              {{ Form::label('password', 'Password') }} ({{ HTML::linkAction('RemindersController@getRemind', 'Forgot password?') }})
              <br>
              {{ Form::password('password', ['class' => 'form-control', 'placeholder' => 'Password']) }}
            </div>
            <div class="checkbox">
              {{ Form::checkbox('remember', 'yes', array('class' => 'form-control')) }}
              {{ Form::label('remember', 'Remember me') }}
            </div>
            <div class="login-btn-container">
              {{ Form::submit('Log in', array('class' => 'btn btn-lg btn-primary loginButton')) }}
            </div>
          </div>
        </fieldset>
        {{ Form::close() }}
        {{ HTML::linkAction('UserController@create', 'Not a member? Register here.') }}
      </div>
    </div>
  </div>
  <div class="section" id="section2">
    <div class="container">
      <div class="row">
        <div class="col-xs-6 about-text">
          <h1 class="about-text-header wat-theme-white">Trojans Family Grows Stronger<br>
            <small>Connect with your friends from different schools all in one place</small>
          </h1>
        </div>
        <div class="col-xs-6 about-img"><img src="{{asset('images/usclogo.jpg')}}" class="image-shadow"></div>
      </div>
    </div>
  </div>
  <div class="section" id="section3">
    <div class="container">
      <div class="row">
        <div class="col-xs-6 about-img"><img src="{{asset('images/questions-mark.png')}}"></div>
        <div class="col-xs-6 about-text">
          <h1 class="about-text-header">All questions get answered<br>
            <small>One-stop shop to answer your questions</small>
          </h1>
        </div>
      </div>
    </div>
  </div>
  <div class="section" id="section4">
    <div class="container">
      <div class="row">
        <div class="col-xs-6 about-img"><img src="{{asset('images/treasure.png')}}"/></div>
        <div class="col-xs-6 about-text">
          <h1 class="about-text-header wat-theme-gold">Earn We-Are-Trojans Point when you help other fellow trojans<br>
            <small class="wat-theme-white">By liking a thread, you can give another Trojans a WAT point, which can be exchanged for a cool swag from the bookstore</small>
          </h1>
        </div>
      </div>
    </div>
  </div>
  <div class="section" id="section5">
    <div class="container">
      <div class="row">
        <div class="col-xs-6 about-text">
          <h1 class="about-text-header wat-theme-black">News and Events send directly to you<br>
            <small class="wat-theme-black">Stay up-to-date on news and events happening around campus</small>
          </h1>
        </div>
        <div class="col-xs-6 about-img"><img src="{{asset('images/envelope.png')}}"/></div>
      </div>
    </div>
  </div>
  <div class="section" id="section6">
    <div class="footer" id="footer-login">
      Join Now
    </div>
    <div class="container" style="padding-top:100px;padding-bottom:100px;">
      <div class="row">
        <div class="col-xs-6 about-img"><img src="{{asset('images/numberone.png')}}"/></div>
        <div class="col-xs-6 about-text">
          <h1 class="about-text-header wat-theme-white">Striving for the number one spot<br>
            <small>Compete with your fellow Trojans by helping others so you can gain more WAT points and be the number one in the leaderboard</small>
          </h1>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
{{HTML::style('lib/fullPage/css/jquery.fullPage.css'); }}
{{HTML::style('css/bootstrap.min.css')}}
{{HTML::style('css/sessions/login.css');}}
{{HTML::script('js/jquery-2.1.3.min.js');}}
{{HTML::script('js/bootstrap.js')}}
{{HTML::script('lib/fullPage/js/jquery.fullPage.min.js');}}
{{HTML::script('js/sessions/login.js')}}
