
@extends('layouts.default')

@section('header')
{{ HTML::style('css/include.css'); }}
@stop

@section('js')
{{ HTML::script('//tinymce.cachefly.net/4.1/tinymce.min.js') }}
<script type="text/javascript">
tinymce.init({
    selector: "textarea",
    menubar:false,
    toolbar: "undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
});
</script>
@stop

@section('content')

    {{ Form::open(array('route' => 'thread.post.store')) }}
    <div class="container" style="padding-top:70px;">
    <div class="row panel" style="opacity:0.9;">
      <div class="form-group" style="height:700px;">
        <table style="margin-top:50px;margin-left:20px;">
          <tr>
            <td>{{ Form::label('threadtopic', 'Thread Topic:') }}</td>
            <td>&nbsp;&nbsp;</td>
            <td width="82%">{{ Form::label('threadcontent',$thread['topic']) }}</td>
            </tr>
        </table>
        {{Form::hidden('thread_id', $thread['id'], array('id'=>'thread_id'))}}
      <div style=" padding-left:120px;padding-right:120px;width:100%; margin-top:20px;">
    {{ Form::textarea('postcontent', '' ,array('class'=>'form-control','placeholder'=>'Enter content')) }}
     </div>
    <div style="margin-top:20px;padding-left:120px;">
      {{ Form::submit('Add Post', array('class' => 'btn btn-lg btn-primary loginButton')) }}
      </div>
    </div>
  {{ Form::close() }}
@stop
