@extends('layouts.default')

@section('header')
{{ HTML::style('css/include.css'); }}
{{ HTML::style('css/bootstrap-multiselect.css')}}
@stop

@section('js')
{{ HTML::script('//tinymce.cachefly.net/4.1/tinymce.min.js') }}
{{ HTML::script('js/bootstrap-multiselect.js')}}
{{ HTML::script('lib/placeholder/plugin.js')}}
<script type="text/javascript">
$(document).ready(function() {
  $('#category-selection').multiselect();
  tinymce.init({
    selector: "textarea",
    plugins : ["paste placeholder"],
    menubar:false,
    toolbar: false,
    statusbar:false,
    content_css : "{{asset('css/threads/wat_tinymce.css')}}",
    init_instance_callback:function(ed){
      $('#mceu_1').css('border-width', '0px');
    },
    valid_elements: "p,br,a[href|target=_blank],li,lo,blockquote",
    paste_auto_cleanup_on_paste:true
  });
});
</script>
@stop

@section ('content')
  {{ Form::open(array('route' => 'thread.store')) }}
  <div class="container" style="padding-top:70px;">
    <div class="row panel" style="opacity:0.9;">
      <div class="form-group" style="height:700px;">
        <table style="margin-top:50px;margin-left:20px;">
          <tr><td>&nbsp;</td><td>&nbsp;</td><td colspan="3">{{ $errors->first('topic','<span class=error style="color:red">*:message</span>') }}</td></tr>
          <tr>
            <td>{{ Form::label('topic', 'Thread Topic:') }}</td>
            <td>&nbsp;&nbsp;</td>
            <td width="82%">{{ Form::text('topic', '', ['class' => 'form-control', 'placeholder' => 'Enter thread topic']) }}</td>
          </tr>
        </table>

      <div style=" padding-left:120px;padding-right:120px;width:100%; margin-top:20px;">
        <div>{{ $errors->first('detail','<span class=error style="color:red">*:message</span>') }}</div>
        <div>{{ Form::textarea('detail', '' ,array('class'=>'form-control','placeholder'=>'Enter contents')) }}</div>
      </div>

      <div style="margin-top:20px;padding-left:120px;">
        <div>{{ $errors->first('category-selection','<span class=error style="color:red">*:message</span>') }}</div>
        <div>{{ Form::select('category-selection[]', $categories, null, array('id'=>'category-selection','class' => 'multiple','multiple' => 'true' )); }}</div>
      </div>

      <div style="margin-top:20px;padding-left:120px;">
        {{ Form::submit('Add Thread', array('class' => 'btn btn-lg btn-primary loginButton')) }}
      </div>
    </div>
  </div>
</div>
  {{ Form::close() }}

@stop
