@extends('layouts.default')


@section('header')
{{ HTML::style('css/include.css'); }}
{{ HTML::style('css/bootstrap-multiselect.css')}}
@stop

@section('js')
{{ HTML::script('//tinymce.cachefly.net/4.1/tinymce.min.js') }}
{{ HTML::script('js/bootstrap-multiselect.js')}}
<script type="text/javascript">
tinymce.init({
    selector: "textarea",
    menubar:false,
    toolbar: "undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
});
</script>
<script type="text/javascript">
$(document).ready(function() {
    $('#category-selection').multiselect();
});
</script>
@stop

@section ('content')

    {{ Form::open(array('method' => 'patch', 'route' => ['thread.update',$thread->id])) }}
    <div class="container" style="padding-top:70px;">
    <div class="row panel" style="opacity:0.9;">
      <div class="form-group" style="height:700px;">
        <table style="margin-top:50px;margin-left:20px;">
          <tr>
            <td>{{ Form::label('threadtopic', 'Thread Topic:') }}</td>
            <td>&nbsp;&nbsp;</td>
            <td width="82%">{{ Form::text('topic', $thread->topic, ['class' => 'form-control', 'placeholder' => 'Enter thread topic']) }}</td>
          </tr>
        </table>
      <div style=" padding-left:120px;padding-right:120px;width:100%; margin-top:20px;">
    {{ Form::textarea('detail',$thread->detail ,array('class'=>'form-control','placeholder'=>'Enter content')) }}
     </div>

    <div style="margin-top:20px;padding-left:120px;">
       {{ Form::select('category-selection[]', $categories, $select_categories, array('id'=>'category-selection','class' => 'multiple','multiple' => 'true' )); }}
    </div>

    <div style="margin-top:20px;padding-left:120px;">
      <table style="margin-top:50px;margin-left:20px;">
        <tr><td> {{ $errors->first('topic','<span class=error style="color:red">*:message</span>') }} </td></tr>
        <tr><td> {{ $errors->first('detail','<span class=error style="color:red">*:message</span>') }} </td></tr>
        <tr><td> {{ $errors->first('category-selection','<span class=error style="color:red">*:message</span>') }} </td></tr>
      </table>
    </div>

    <div style="margin-top:20px;padding-left:120px;">
      {{ Form::submit('Update Thread', array('class' => 'btn btn-lg btn-primary loginButton')) }}
      </div>
    </div>
  {{ Form::close() }}
@stop
