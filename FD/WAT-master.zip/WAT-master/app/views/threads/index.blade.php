@extends('layouts.default')

@section('header')
{{ HTML::style('css/forumpage.css'); }}
@stop

@section('js')
{{ HTML::script('js/threads/index.js') }}
{{ HTML::script('js/jquery.timeago.js') }}
<script type="text/javascript">
  jQuery(document).ready(function() {
    jQuery("time.timeago").timeago();
  });
</script>

<script type="text/javascript">
// this piece of code must be placed here not in the separate js files as they require php
  var like_thread_url = "{{route('like_thread')}}";
  var unlike_thread_url = "{{route('unlike_thread')}}";
  var dislike_thread_url = "{{route('dislike_thread')}}";
  var undislike_thread_url = "{{route('undislike_thread')}}";
</script>

<!--For category Bar -->
<script type="text/javascript">
/*this part is for category section that requires php*/
var updateCategories="{{{ asset('/updateCategories') }}}";
var threadCategories="{{{ asset('/threadCategories') }}}";
var home="{{asset('home')}}";
var categoryName="{{$categoryName}}";
var category =
{
  id: [],     //id of category that want to set.
  name: []  //id of category that want to reset.
};

$(document).ready(function(){
  @foreach($thread_categories as $category)
  category.id.push("{{{$category->id}}}");
  category.name.push("{{{$category->name}}}");
  @endforeach
  mycategories_initialize();
  set_selected_category();
});

</script>
@stop

@section ('content')
<div style="background-color:#F7F7F7;">
<div class="container" style="padding-top:70px;">
  <div class="row clearfix">
    <div class="col-sm-12 column">
      <div class="row clearfix">


        <!--Left of the page will have the category bar-->
      <div class="row row-offcanvas row-offcanvas-left">
        <!--Right of the page will have the Leaderboard-->
      <div class="row-offcanvas row-offcanvas-right">


      <!--Category Bar-->
               <div class="col-sm-2 sidebar-offcanvas" id="sidebarLeft" role="navigation" style="background-color:#F7F7F7;height:100%;">
                    <div class="col-md-12 column" id="mycategories"></div>
                  </div>
      <!--End of Category Bar-->

      <!--Main Content-->
              <div class="col-sm-7 column content" style="overflow:auto;margin-top:-20px;">
                <!--Render on Mobile: Make button visible on mobile view-->
                <p class="pull-left visible-xs" style="margin-top:20px;">
                  <button class="btn btn-primary btn-xs" style="margin-left:10px;" type="button" data-toggle="offcanvas"><i class="glyphicon glyphicon-chevron-left"><small>Category</small></i></button>
                </p>
                <p class="pull-right visible-xs" style="margin-top:20px;">
                  <button class="btn btn-primary btn-xs" style="margin-right:15px;" type="button" data-toggle="offcanvasright"><small>Leaderboard</small><i class="glyphicon glyphicon-chevron-right"></i></button>
                </p>
                <!--End of button visible information-->

                <!--Display the category selected by the user-->
                    <div style="padding-bottom:2px;">
                 <h3><center><span class="fa fa-star" style="margin-left:-5px;">&nbsp;&nbsp;{{$categoryName}}</span></center></h3>

                </div>
                <!--End of category display section-->

                            <!-- content starts here-->
                            @foreach ($threads as $thread)
                                  <div class="panel panel-primary">
                                      <div class="panel-body" >
                                          <strong>{{ HTML::linkAction('ThreadController@show',$thread->topic,array($thread->id),array('class'=>'text-custom1')) }}</strong>
                                          <br>
                                          <small class="text-muted"><a href="{{route('users.show',$thread->user_id)}}" style="text-decoration:none;color:black;"><img src="{{asset($thread->picture_url)}}" class="picstyle img-circle">&nbsp;<b>{{$thread->first_name}} {{$thread->last_name}}</b></a> • <time class="timeago" datetime="{{$thread->created_at}}"></time></small>
                                          <br>
                                          <div id="give_padding" class="col-sm-12">
                                            <div id="thread-comment-{{$thread->id}}">
                                              <div class="comment less" class="col-sm-12">
                                                @if(strlen(strip_tags($thread->detail))<Config::get('wat/forum.number_of_character_in_short_thread'))
                                                  {{substr(strip_tags($thread->detail), 0, Config::get('wat/forum.number_of_character_in_short_thread'))}}
                                                @else
                                                  {{substr(strip_tags($thread->detail), 0, Config::get('wat/forum.number_of_character_in_short_thread')).'...'}}
                                                  <span class="more_less_btn" onclick="thread.toggleMoreOrLess({{$thread->id}})" style="color:#990000"><b>[+more]</b></span>
                                                @endif
                                              </div>
                                              <div class="comment more">
                                                {{$thread->detail}}
                                                <span class="more_less_btn" onclick="thread.toggleMoreOrLess({{$thread->id}})" style="color:#990000"><b>[-less]</b></span>
                                              </div>
                                            </div>
                                          </div>
                                        <div class="pull-right">
                                          <small class="text-muted"><i class="fa fa-comments"></i>&nbsp;<a href="{{route('thread.show',$thread->id)}}" class="text-muted">Answers: {{Thread::countPost($thread->id)}}</a></small>
                                       </div>
                                        <div class="pull-left">
                                           <span id="thread-like-dislike-{{$thread->id}}">
                                           <small>
                                             <!--the user has already liked the thread-->
                                             @if($thread->relation_type == 1)
                                               <button class='like_button btn label label-custom-like fa fa-thumbs-up' onclick="thread.unlikeThread({{$thread->id}})">
                                                 <strong>
                                                   <span class="like-text"> Unlike </span>
                                                   <span class="number-of-like">{{$thread->like_amt}}</span>
                                                 </strong>
                                               </button>
                                               <button disabled class='dislike_button btn label label-custom-dislike fa fa-thumbs-down' onclick="thread.dislikeThread({{$thread->id}})">
                                                 <strong>
                                                   <span class="dislike-text"> Dislike </span>
                                                   <span class="number-of-dislike">{{$thread->dislike_amt}}</span>
                                                 </strong>
                                               </button>
                                             <!--the user has already disliked the thread-->
                                             @elseif($thread->relation_type == 2)
                                               <button disabled class='like_button btn label label-custom-like fa fa-thumbs-up' onclick="thread.likeThread({{$thread->id}})">
                                                 <strong>
                                                   <span class="like-text"> Like </span>
                                                   <span class="number-of-like">{{$thread->like_amt}}</span>
                                                 </strong>
                                               </button>
                                               <button class='dislike_button btn label label-custom-dislike fa fa-thumbs-down' onclick="thread.undislikeThread({{$thread->id}})">
                                                 <strong>
                                                   <span class="dislike-text"> Undislike </span>
                                                   <span class="number-of-dislike">{{$thread->dislike_amt}}</span>
                                                 </strong>
                                               </button>
                                             <!--the user is the owner the thread-->
                                             @elseif(Auth::user()->id == $thread->user_id)
                                               <button disabled class='like_button btn label label-custom-like fa fa-thumbs-up'>
                                                 <strong>
                                                   <span class="like-text"> Like </span>
                                                   <span class="number-of-like">{{$thread->like_amt}}</span>
                                                 </strong>
                                               </button>
                                               <button disabled class='dislike_button btn label label-custom-dislike fa fa-thumbs-down'>
                                                 <strong>
                                                   <span class="dislike-text"> Undislike </span>
                                                   <span class="number-of-dislike">{{$thread->dislike_amt}}</span>
                                                 </strong>
                                               </button>

                                             <!--Other cases, the user is free to like or dislike the thread-->
                                             @else
                                               <button class='like_button btn label label-custom-like fa fa-thumbs-up' onclick="thread.likeThread({{$thread->id}})">
                                                 <strong>
                                                   <span class="like-text"> Like </span>
                                                   <span class="number-of-like">{{$thread->like_amt}}</span>
                                                 </strong>
                                               </button>
                                               <button class='dislike_button btn label label-custom-dislike fa fa-thumbs-down' onclick="thread.dislikeThread({{$thread->id}})">
                                                 <strong>
                                                   <span class="dislike-text"> Dislike </span>
                                                   <span class="number-of-dislike">{{$thread->dislike_amt}}</span>
                                                 </strong>
                                               </button>
                                             @endif
                                           </small>
                                         </span>
                                       </div>
                                      <!--end of post content-->
                                      </div>
                                    </div>
                            @endforeach

                           {{$threads->links()}}
                </div>
                <!--End of Main Content-->





                <div class="col-sm-3 sidebar-offcanvas" id="sidebarRight" role="navigation" style="background-color:#F7F7F7;height:100%;">

                  <!--Display Login user information-->
                    <div class="col-md-12 column ">
                      <div class="text-muted" style="margin-bottom:2px;margin-top:10px;"><b>Your Rank: {{$loginUser->rank}}</b></div>

                    <a style="display:block;color:black;" href="{{route('users.show',$loginUser->id)}}">
                    <div class="fix_div_width">
                      <table class="for_hover">
                      <tr>
                      <td rowspan="2">
                      <p><a href="{{route('users.show',$loginUser->id)}}" class="pull-left"><img src="{{asset($loginUser->picture_url)}}" class="img-rounded custom-dimension2"></a></p>
                      </td>
                      <td>
                      <span><b>&nbsp;{{$loginUser->first_name}}&nbsp;{{$loginUser->last_name}}</b></span>
                      </td>
                      </tr>
                      <tr>
                        <td>
                          &nbsp;Semester Points: {{$loginUser->semester}}
                        </td>
                      </tr>
                      </table>
                      </div>
                    </a>
                  </div>
                  <!--End of Login user display-->
                  <div class="leader-board-content">
                  <!--Leaderboard Header-->
                      <div class="image_leaderboard"><img src="{{asset('/images/Leaderboard_images/Leader.png')}}" height="40" width="40" style= "opacity:0.8;"></div>
                      <div class="image_overlap_leaderboard"><strong>LEADERBOARD<i>&nbsp;Top#10</i></strong></div><br/>
                  <!--End of Header for Leaderboard-->

                  <!--Leaderboard content sorted based on decresing semester points-->
                      <?php $i = 1;?>
                      @foreach($users as $key=> $user)
                      @if($i==1)
                      <?php $max = "$user->semester";?>
                      @endif
                      <a style="display:block;color:black;text-decoration:none;" href="{{route('users.show',$user->id)}}">
                      <div class="fix_div_width">
                      @if($user->email == $loginUser->email)
                        <div style="padding-top:5px;"><span style="border-radius:5px;border: 3px solid #990000;padding: 2px;background-color:#990000;color:#FFCC00"><b>{{$loginUser->rank}}</b></span></div>
                      @else
                        <div style="padding-top:5px;"><b>{{$user->rank}}</b></div>
                      @endif
                        <div style="margin-left:20px;margin-top:-25px;"><img src="{{asset($user->picture_url)}}" class="img-rounded custom-dimension2"></div>
                        <div style="margin-top:-40px;margin-left:55px;><b>&nbsp;{{$user->first_name}}&nbsp;{{$user->last_name}}</b></div>

                        <div style="margin-top:-40px;margin-left:55px;"><b>&nbsp;{{$user->first_name}}&nbsp;{{$user->last_name}}</b></div>

                        <div style="margin-left:55px;">&nbsp;Semester Points: {{$user->semester}}</div><br/>
                        </div>
                      </a>
                      <div class="pull-left">
                      </div>
                      <?php $i++; ?>
                      @endforeach
                      <!--End of leaderboard content-->
                      </div>
                      </div>
                   </div>

        </div>
      </div>
    </div>
  </div>
</div>
</div>
@stop
