@extends('layouts.default')

@section('header')
{{ HTML::style('css/thread_view.css'); }}
{{ HTML::style('css/threads/show_thread_page.css'); }}
{{ HTML::style('css/threads/wat_tinymce.css'); }}
{{ HTML::style('css/bootstrap-multiselect.css')}}
@stop

@section('js')
{{ HTML::script('//tinymce.cachefly.net/4.1/tinymce.min.js') }}
{{ HTML::script('js/threads/index.js') }}
{{ HTML::script('js/posts/post_event_handler.js') }}
{{ HTML::script('js/jquery.timeago.js') }}
{{ HTML::script('js/bootstrap-multiselect_new.js')}}
{{ HTML::script('lib/placeholder/plugin.js')}}
<script type="text/javascript">
  jQuery(document).ready(function() {
    jQuery("time.timeago").timeago();
  });
</script>
<script type-"text/javascript">
$(document).ready(function() {
    $(".deleteform").click(function(event) {
        if(!confirm('Are you sure that you want to delete your thread/comment') )
            event.preventDefault();
    });
    $('#category-selection').multiselect();
    tinymce.init({
      selector: "textarea",
      plugins : ["paste placeholder"],
      menubar: false,
      toolbar: false,
      statusbar:false,
      placeholder:"test",
      resize:true,
      content_css : "{{asset('css/threads/wat_tinymce.css')}}",
      init_instance_callback:function(ed){
        $('#postcontent_ifr').css('height','50px');
      },
      valid_elements: "p,br,a[href|target=_blank],li,lo,blockquote,div[class],span[class]",
      paste_auto_cleanup_on_paste:true,
    });
    $('#add_comment_form').submit(function(){
      var btn = $('#add_comment_btn');
      btn.val("Sumitting...");
      btn.attr('disabled', true);
      return true;
    });
});
</script>
<script>
//this piece of code must be placed here not in the separate js files as they require php
//need to hide this somehow
  var like_thread_url = "{{route('like_thread')}}"
  , unlike_thread_url = "{{route('unlike_thread')}}"
  , dislike_thread_url = "{{route('dislike_thread')}}"
  , undislike_thread_url = "{{route('undislike_thread')}}"
  , like_post_url = "{{route('like_post')}}"
  , unlike_post_url = "{{route('unlike_post')}}"
  , dislike_post_url = "{{route('dislike_post')}}"
  , undislike_post_url = "{{route('undislike_post')}}"
  , report_thread_url = "{{route('report_thread')}}"
  , report_post_url = "{{route('report_post')}}"
  , token = "{{Session::token()}}"
  , update_post_url = decodeURIComponent("{{route('thread.post.update')}}")
  , update_thread_url = decodeURIComponent("{{route('thread.update')}}")
  , thread_categories = JSON.parse('{{$thread_categories}}')
  , home = decodeURIComponent("{{route('home')}}");
</script>
@stop

@section ('content')
<div class="container" style="padding-top:70px;">
	<div class="row clearfix outside">
		<div class="col-md-12 column" id="left">
			<div class="row clearfix">
				<div class="col-xs-2 col-sm-3 column mobile-invisible-view">
					<!--question topic-->
          <div class="category-section-bar">
            <!--back button-->
            <div style="padding-bottom:10px;margin-left:-10px;">
              <button type="button" class="btn add-color btn-sm btn-style" onclick="history.go(-1)">
              <span class="fa fa-arrow-circle-left"></span> Go Back
              </button>
            </div>
          <hr>
					<h6 class="text-muted">QUESTION CATEGORIES</h6>
					<hr>
					<ul id="category-class" class="list-unstyled">
						@foreach ($thread->categories as $category)
						<li id="catlist">
							{{link_to_route('home', $category->name, array($category->id), array('class' => 'CatButton'))}}
						</li>
						@endforeach
					</ul>
        </div>
				</div>
				<div class="col-xs-10 col-sm-9 column main-content" id="right">
					<div class="row clearfix">
						<div class="col-md-12 column">
                          <!--back button-->
            <div style="padding-bottom:25px;margin-left:-10px;" class="show-only-mobile">
              <button type="button" class="btn add-color btn-sm btn-style" onclick="history.go(-1)">
              <span class="fa fa-arrow-circle-left"></span> Go Back
              </button>
            </div>
							<div class="panel panel-primary">
                <div id="thread-anchor-{{$thread->id}}" class="anchor-offset"></div>
                <div id="thread-div-{{$thread->id}}" class="panel-body main-topic">
                  @if(Auth::user()->id == $thread->user_id)
                    <div class="delete-bar">
                      {{ Form::open(array('route' => array('thread.destroy', $thread->id), 'method' => 'delete','class'=>'deleteform')) }}
                      <button type="submit" class="btn label label-custom-delete"><span class="fa fa-times"></span></button>
                      {{ Form::close() }}
                    </div>
                  @endif
                  <span class="thread-topic"><strong class="topic-header">{{$thread->topic}}</strong></span>
                  <span class="thread-editor">
                    {{ Form::text('topic', '', ['class' => 'form-control', 'placeholder' => 'Thread Topic', 'id'=>'thread-topic-editor']) }}
                  </span>
                  <br>
                  <small class="text-muted">
                    <a href="{{route('users.show',$thread->user->id)}}" style="text-decoration:none;color:black;">
                      <img src="{{asset($thread->user->picture_url)}}" class="picstyle img-circle" alt="profile picture">&nbsp;
                      <b>
                        <span id="user-name-{{$thread->id}}">
                          {{$thread->user->first_name}} {{$thread->user->last_name}}
                        </span>
                      </b>
                    </a> • <time class="timeago" datetime="{{$thread->created_at}}"></time></small>
                  <br>
                  <div id="give_padding">
                    <div class="thread-detail">{{$thread->detail}}</div>
                    <div class ="thread-editor">
                      {{ Form::hidden('thread_id', $thread['id'], array('id'=>'thread_id'))}}
                      {{ Form::textarea('threadcontent', '' ,array('class'=>'textinputbox','placeholder'=>'Write a comment...', 'id'=>'threadcontent_editor-'.$thread->id)) }}
                      {{ Form::select('category-selection[]', $categories, '', array('id'=>'category-selection','class' => 'multiple','multiple' => 'true' )); }}
                    </div>
                  </div>
							   	<div class="pull-left">
                  <span id="thread-like-dislike-{{$thread->id}}">
                  <small>
                    <!--like and dislike button functionalities-->
                    @if(is_null($thread->relation_user))
                    <!--the user is the on who creates the thread-->
	                      @if(Auth::user()->id == $thread->user_id)
	                      <button disabled class='like_button btn label label-custom-like fa fa-thumbs-up '>
	                        <strong>
	                          <span class="like-text"> Like </span>
	                          <span class="number-of-like">{{$thread->like_amt}}</span>
	                        </strong>
	                      </button>
	                      <button disabled class='dislike_button btn label label-custom-dislike fa fa-thumbs-down '>
	                        <strong>
	                          <span class="dislike-text"> Dislike </span>
	                          <span class="number-of-dislike">{{$thread->dislike_amt}}</span>
	                        </strong>
	                      </button>
	                      <!--The thread is free to like or dislike-->
	                      @else
	                    	<button class='like_button btn label label-custom-like fa fa-thumbs-up ' onclick="thread.likeThread({{$thread->id}})">
	                        <strong>
	                          <span class="like-text"> Like </span>
	                          <span class="number-of-like">{{$thread->like_amt}}</span>
	                        </strong>
	                      </button>
	                      <button class='dislike_button btn label label-custom-dislike fa fa-thumbs-down ' onclick="thread.dislikeThread({{$thread->id}})">
	                        <strong>
	                          <span class="dislike-text"> Dislike </span>
	                          <span class="number-of-dislike">{{$thread->dislike_amt}}</span>
	                        </strong>
	                      </button>
	                      @endif
                    @else
                    	<!--the user has already liked the thread-->
	                    @if($thread->relation_user->relation_type == 1)
	                      <button class='like_button btn label label-custom-like fa fa-thumbs-up ' onclick="thread.unlikeThread({{$thread->id}})">
	                        <strong>
	                          <span class="like-text"> Unlike </span>
	                          <span class="number-of-like">{{$thread->like_amt}}</span>
	                        </strong>
	                      </button>
	                      <button disabled class='dislike_button btn label label-custom-dislike fa fa-thumbs-down ' onclick="thread.dislikeThread({{$thread->id}})">
	                        <strong>
	                          <span class="dislike-text"> Dislike </span>
	                          <span class="number-of-dislike">{{$thread->dislike_amt}}</span>
	                        </strong>
	                      </button>
                    <!--the user has already disliked the thread-->
                    	@elseif($thread->relation_user->relation_type == 2)
	                      <button disabled class='like_button btn label label-custom-like fa fa-thumbs-up ' onclick="thread.likeThread({{$thread->id}})">
	                        <strong>
	                          <span class="like-text"> Like </span>
	                          <span class="number-of-like">{{$thread->like_amt}}</span>
	                        </strong>
	                      </button>
	                      <button class='dislike_button btn label label-custom-dislike fa fa-thumbs-down ' onclick="thread.undislikeThread({{$thread->id}})">
	                        <strong>
	                          <span class="dislike-text"> Dislike </span>
	                          <span class="number-of-dislike">{{$thread->dislike_amt}}</span>
	                        </strong>
	                      </button>
                      <!--incase something goes wrong-->
                      	@else
	                        <button disabled class='like_button btn label label-custom-like fa fa-thumbs-up '>
	                        <strong>
	                          <span class="like-text"> Like </span>
	                          <span class="number-of-like">{{$thread->like_amt}}</span>
	                        </strong>
	                      </button>
	                      <button disabled class='dislike_button btn label label-custom-dislike fa fa-thumbs-down '>
	                        <strong>
	                          <span class="dislike-text"> Undislike </span>
	                          <span class="number-of-dislike">{{$thread->dislike_amt}}</span>
	                        </strong>
	                      </button>
                      @endif
                     @endif
                  </small>
                </span>
            	</div>
                <div class="pull-right">
                  @if(Auth::user()->id == $thread->user_id)
                    <!-- {{link_to_route('thread.edit', 'Edit', array($thread->id), array('class' => 'label label-edit fa fa-pencil'))}} -->
                    <span id="message-thread-{{$thread->id}}"></span>
                    <span id="editor-thread-{{$thread->id}}" class="label label-edit fa fa-pencil" onclick="thread.edit({{$thread->id}})">Edit</span>
                    <span id="save-thread-{{$thread->id}}" class="label label-edit fa fa-floppy-o" onclick="thread.save({{$thread->id}})" style="display:none;">Save</span>
                    <span id="cancel-thread-{{$thread->id}}" class="label label-edit fa fa-undo" onclick="thread.cancel({{$thread->id}})" style="display:none;">Cancel</span>
                  @endif
                  <span class="label label-edit fa fa-quote-left" onclick="thread.quote({{$thread->id}})">Quote</span>
                  @if(Auth::user()->id != $thread->user_id)
                  <span id="report-thread-{{$thread->id}}" class="label label-custom-report fa fa-ban" onclick="thread.report({{$thread->id}}, {{Auth::user()->id}})"> Report</span>
                  @endif
                </div>
              </div>
            </div>
            <div id="thread-error-{{$thread->id}}" class="success-message"  style="display: none;">
            </div>
            <hr>
            <span class="text-muted"><strong>{{count($thread->posts)}}&nbsp;Answers</strong></span>
            <hr>
					<!-- this part is for the thread's best answer: sorted by number likes. The function is in Thread.php-->
					@if(count($thread->most_liked) > 0)
            <div id="post-anchor-{{$thread->most_liked->id}}" class="anchor-offset"></div>
            <div id="post-div-{{$thread->most_liked->id}}" class="panel panel-warning">
              <div class="panel-body">
                <div class="image-left-bar">
                  <a href="{{route('users.show',$thread->most_liked->user_id)}}"><img src="{{asset($thread->most_liked->author_picture_url)}}" class="picstyle" alt="profile picture"></a>
                </div>
                @if(Auth::user()->id == $thread->most_liked->user_id)
                <div class="pull-right">
                  {{ Form::open(array('route' => array('thread.post.destroy', $thread->id,$thread->most_liked->id), 'method' => 'delete','class'=>'deleteform')) }}
                  <button type="submit" class="btn label label-custom-delete"><span class="fa fa-times"></span></button>
                  {{ Form::close() }}
                </div>
                @endif
                <div class="post-content">
                  <b>{{link_to_route('users.show', $thread->most_liked->author_firstname." ".$thread->most_liked->author_lastname, array($thread->most_liked->user_id), array('id'=>'user-name-'.$thread->most_liked->id, 'style'=>'color:black;'))}}</b>
                  <div class ="post-detail">{{$thread->most_liked->detail}}</div>
                  <div class ="post-editor">
                    {{ Form::hidden('thread_id', $thread['id'], array('id'=>'thread_id'))}}
                    {{ Form::hidden('post_id', $thread->most_liked->id, array('id'=>'post_id'))}}
                    {{ Form::textarea('postcontent', '' ,array('class'=>'textinputbox','placeholder'=>'Write a comment...', 'id'=>'postcontent_editor-'.$thread->most_liked->id)) }}
                  </div>
                  <br>
                  <div class="pull-left">
                  <span id="post-{{$thread->most_liked->id}}">
                    <small>
                      @if(is_null($thread->most_liked->relation_type))
                      <!--users cannot like their own post-->
                        @if(Auth::user()->id == $thread->most_liked->user_id)
  	                      <button disabled class='like_button btn label label-custom-like fa fa-thumbs-up '>
  	                        <strong>
  	                          <span class="like-text"> Like </span>
  	                          <span class="number-of-like">{{$thread->most_liked->like_amt}}</span>
  	                        </strong>
  	                      </button>
  	                      <button disabled class='dislike_button btn label label-custom-dislike fa fa-thumbs-down '>
  	                        <strong>
  	                          <span class="dislike-text"> Dislike </span>
  	                          <span class="number-of-dislike">{{$thread->most_liked->dislike_amt}}</span>
  	                        </strong>
  	                      </button>
  	                      <!--this post hasn't been liked or disliked by the user-->
                        @else
                          <button class='like_button btn label label-custom-like fa fa-thumbs-up ' onclick="post.likepost({{$thread->most_liked->id}})">
  	                        <strong>
  	                          <span class="like-text"> Like </span>
  	                          <span class="number-of-like">{{$thread->most_liked->like_amt}}</span>
  	                        </strong>
  	                      </button>
  	                      <button class='dislike_button btn label label-custom-dislike fa fa-thumbs-down ' onclick="post.dislikepost({{$thread->most_liked->id}})">
  	                        <strong>
  	                          <span class="dislike-text"> Dislike </span>
  	                          <span class="number-of-dislike">{{$thread->most_liked->dislike_amt}}</span>
  	                        </strong>
  	                      </button>
                        @endif
                      @else
                      <!--the user has already liked the post-->
  	                    @if($thread->most_liked->relation_type == 1)
  	                      <button class='like_button btn label label-custom-like fa fa-thumbs-up ' onclick="post.unlikepost({{$thread->most_liked->id}})">
  	                        <strong>
  	                          <span class="like-text"> Unlike </span>
  	                          <span class="number-of-like">{{$thread->most_liked->like_amt}}</span>
  	                        </strong>
  	                      </button>
  	                      <button disabled class='dislike_button btn label label-custom-dislike fa fa-thumbs-down ' onclick="post.dislikepost({{$thread->most_liked->id}})">
  	                        <strong>
  	                          <span class="dislike-text"> Dislike </span>
  	                          <span class="number-of-dislike">{{$thread->most_liked->dislike_amt}}</span>
  	                        </strong>
  	                      </button>
                      <!--the user has already disliked the post-->
                      	@elseif($thread->most_liked->relation_type == 2)
  	                      <button disabled class='like_button btn label label-custom-like fa fa-thumbs-up ' onclick="post.likepost({{$thread->most_liked->id}})">
  	                        <strong>
  	                          <span class="like-text"> Like </span>
  	                          <span class="number-of-like">{{$thread->most_liked->like_amt}}</span>
  	                        </strong>
  	                      </button>
  	                      <button class='dislike_button btn label label-custom-dislike fa fa-thumbs-down ' onclick="post.undislikepost({{$thread->most_liked->id}})">
  	                        <strong>
  	                          <span class="dislike-text"> Undislike </span>
  	                          <span class="number-of-dislike">{{$thread->most_liked->dislike_amt}}</span>
  	                        </strong>
  	                      </button>
                        <!--incase something goes wrong-->
                        	@else
  	                        <button disabled class='like_button btn label label-custom-like fa fa-thumbs-up '>
  	                        <strong>
  	                          <span class="like-text"> Like </span>
  	                          <span class="number-of-like">{{$thread->most_liked->like_amt}}</span>
  	                        </strong>
  	                      </button>
  	                      <button disabled class='dislike_button btn label label-custom-dislike fa fa-thumbs-down '>
  	                        <strong>
  	                          <span class="dislike-text"> Dislike </span>
  	                          <span class="number-of-dislike">{{$thread->most_liked->dislike_amt}}</span>
  	                        </strong>
  	                      </button>
                        @endif
                       @endif
                    </small>
                  </span>
				        </div>
                <div class="pull-right">
                  @if(Auth::user()->id == $thread->most_liked->user_id)
                    <span id="message-post-{{$thread->most_liked->id}}"></span>
                    <span id="editor-post-{{$thread->most_liked->id}}" class="label label-edit fa fa-pencil" onclick="post.edit({{$thread->most_liked->id}})">Edit</span>
                    <span id="save-post-{{$thread->most_liked->id}}" class="label label-edit fa fa-floppy-o" onclick="post.save({{$thread->most_liked->id}})" style="display:none;">Save</span>
                    <span id="cancel-post-{{$thread->most_liked->id}}" class="label label-edit fa fa-undo" onclick="post.cancel({{$thread->most_liked->id}})" style="display:none;">Cancel</span>
                  @endif
                  <span class="label label-edit fa fa-quote-left" onclick="post.quote({{$thread->most_liked->id}})">Quote</span>
                  <small class="text-muted"><i class="fa fa-calendar"></i> • <time class="timeago" datetime="{{$thread->most_liked->created_at}}"></time></small>
                    @if(Auth::user()->id != $thread->most_liked->user_id)
                    <span id="report-post-{{$thread->most_liked->id}}" class="label label-custom-report fa fa-ban" onclick="post.report({{$thread->most_liked->id}}, {{Auth::user()->id}})"> Report</span>
                    @endif
                  </div>
                </div>
              </div>
              </div>
            <div id="post-error-{{$thread->most_liked->id}}" class="success-message" style="display: none;">
              <p>&#10003;</p>
            </div>
					@endif
	<!-- 						@if(count($thread->posts)>1)
							@endif -->
							<!--normal post starts here-->
							<?php $i = 1;?>
							@if(count($thread->posts) > 0)
							@foreach ($thread->posts as $post)
							@if($post->id != $thread->most_liked->id)
              <div id="post-anchor-{{$post->id}}" class="anchor-offset"></div>
							<div id="post-div-{{$post->id}}" class="panel panel-default">
							    <div class="panel-body">
									<div class="image-left-bar">
							        	<a href="{{route('users.show',$post->user_id)}}"><img src="{{asset($post->author_picture_url)}}" class="picstyle"></a>
							    	</div>
							    	@if(Auth::user()->id == $post->user_id)
							    	<div class="pull-right">
							    		{{ Form::open(array('route' => array('thread.post.destroy', $thread->id,$post->id), 'method' => 'delete','class'=>'deleteform')) }}
                              				<button type="submit" class="btn label label-custom-delete"><span class="fa fa-times"></span></button>
                      					{{ Form::close() }}
							    	</div>
							    	@endif
							    	<div class="post-content">
							    		<b>{{link_to_route('users.show', $post->author_firstname." ".$post->author_lastname, array($post->user_id), array('id'=>'user-name-'.$post->id,'style' => 'color:black;'))}}</b>
							    		<div class ="post-detail">{{$post->detail}}</div>
                      <div class ="post-editor">
                        {{ Form::hidden('thread_id', $thread['id'], array('id'=>'thread_id'))}}
                        {{ Form::hidden('post_id', $post->id, array('id'=>'post_id'))}}
                        {{ Form::textarea('postcontent', '' ,array('class'=>'textinputbox','placeholder'=>'Write a comment...', 'id'=>'postcontent_editor-'.$post->id)) }}
                      </div>
							    	<br>
							   	<div class="pull-left">
                  <span id="post-{{$post->id}}">
                  <small>
                    @if(is_null($post->relation_type))
                    	<!--users cannot like their own post-->
	                      @if(Auth::user()->id == $post->user_id)
	                      <button disabled class='like_button btn label label-custom-like fa fa-thumbs-up '>
	                        <strong>
	                          <span class="like-text"> Like </span>
	                          <span class="number-of-like">{{$post->like_amt}}</span>
	                        </strong>
	                      </button>
	                      <button disabled class='dislike_button btn label label-custom-dislike fa fa-thumbs-down '>
	                        <strong>
	                          <span class="dislike-text"> Dislike </span>
	                          <span class="number-of-dislike">{{$post->dislike_amt}}</span>
	                        </strong>
	                      </button>
	                      <!--this post hasn't been liked or disliked by the user-->
	                      @else
	                    	<button class='like_button btn label label-custom-like fa fa-thumbs-up ' onclick="post.likepost({{$post->id}})">
	                        <strong>
	                          <span class="like-text"> Like </span>
	                          <span class="number-of-like">{{$post->like_amt}}</span>
	                        </strong>
	                      </button>
	                      <button class='dislike_button btn label label-custom-dislike fa fa-thumbs-down ' onclick="post.dislikepost({{$post->id}})">
	                        <strong>
	                          <span class="dislike-text"> Dislike </span>
	                          <span class="number-of-dislike">{{$post->dislike_amt}}</span>
	                        </strong>
	                      </button>
	                      @endif
                    @else
                    <!--the user has already liked the post-->
	                    @if($post->relation_type == 1)
	                      <button class='like_button btn label label-custom-like fa fa-thumbs-up ' onclick="post.unlikepost({{$post->id}})">
	                        <strong>
	                          <span class="like-text"> Unlike </span>
	                          <span class="number-of-like">{{$post->like_amt}}</span>
	                        </strong>
	                      </button>
	                      <button disabled class='dislike_button btn label label-custom-dislike fa fa-thumbs-down ' onclick="post.dislikepost({{$post->id}})">
	                        <strong>
	                          <span class="dislike-text"> Dislike </span>
	                          <span class="number-of-dislike">{{$post->dislike_amt}}</span>
	                        </strong>
	                      </button>
                    <!--the user has already disliked the post-->
                    	@elseif($post->relation_type == 2)
	                      <button disabled class='like_button btn label label-custom-like fa fa-thumbs-up ' onclick="post.likepost({{$post->id}})">
	                        <strong>
	                          <span class="like-text"> Like </span>
	                          <span class="number-of-like">{{$post->like_amt}}</span>
	                        </strong>
	                      </button>
	                      <button class='dislike_button btn label label-custom-dislike fa fa-thumbs-down ' onclick="post.undislikepost({{$post->id}})">
	                        <strong>
	                          <span class="dislike-text"> Undislike </span>
	                          <span class="number-of-dislike">{{$post->dislike_amt}}</span>
	                        </strong>
	                      </button>
                      <!--incase something goes wrong-->
                      	@else
	                        <button disabled class='like_button btn label label-custom-like fa fa-thumbs-up '>
	                        <strong>
	                          <span class="like-text"> Like </span>
	                          <span class="number-of-like">{{$post->like_amt}}</span>
	                        </strong>
	                      </button>
	                      <button disabled class='dislike_button btn label label-custom-dislike fa fa-thumbs-down '>
	                        <strong>
	                          <span class="dislike-text"> Dislike </span>
	                          <span class="number-of-dislike">{{$post->dislike_amt}}</span>
	                        </strong>
	                      </button>
                      @endif
                     @endif
                  </small>
                </span>
					</div><!--end div pull-left-->
							    <div class="pull-right">
                    @if(Auth::user()->id == $post->user_id)
                      <span id="message-post-{{$post->id}}"></span>
                      <span id="editor-post-{{$post->id}}" class="label label-edit fa fa-pencil" onclick="post.edit({{$post->id}})">Edit</span>
                      <span id="save-post-{{$post->id}}" class="label label-edit fa fa-floppy-o" onclick="post.save({{$post->id}})" style="display:none;">Save</span>
                      <span id="cancel-post-{{$post->id}}" class="label label-edit fa fa-undo" onclick="post.cancel({{$post->id}})" style="display:none;">Cancel</span>
                    @endif
                    <span class="label label-edit fa fa-quote-left" onclick="post.quote({{$post->id}})">Quote</span>
							    	<small class="text-muted"><i class="fa fa-calendar"></i> • <time class="timeago" datetime="{{$post->created_at}}"></time></small>
							    	  @if(Auth::user()->id != $post->user_id)
                      <span id="report-post-{{$post->id}}" class="label label-custom-report fa fa-ban" onclick="post.report({{$post->id}}, {{Auth::user()->id}})"> Report</span>
							    	 @endif
							    </div>
							    	</div>
								</div>
							</div>
              <div id="post-error-{{$post->id}}" class="success-message" style="display: none;">
              </div>
							<!-- <hr> -->
							@endif
							<?php $i++; ?>
  							@endforeach
  							@endif
             </div>
          </div>
          <div>
            <!-- <button class="btn btn-primary" id="addpostbutton"><i class="glyphicon glyphicon-plus"></i>Add a comment</button> -->
            <div class="addreply-area">
              <div class="image-left-bar">
                <img src="{{asset(Auth::user()->picture_url)}}" style="height:30px;width:30px;"/>
              </div>
              <div class="post-input-content">
                {{ Form::open(array('route'=> array('thread.post.store',$thread['id']), 'id'=>'add_comment_form')) }}
                {{ Form::hidden('thread_id', $thread['id'], array('id'=>'thread_id'))}}
                <div id="create_comment_box">
                  {{ $errors->first('postcontent','<span class=error style="color:red">*:message</span>') }}
                  {{ Form::textarea('postcontent', '' ,array('class'=>'textinputbox','placeholder'=>'Write a comment...', 'id'=>'postcontent')) }}
                </div>
                <div class="pull-right">
                  {{ Form::submit('Add a comment', array('class' => 'addreply', 'id'=>'add_comment_btn')) }}
                </div>
                {{ Form::close() }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@stop
