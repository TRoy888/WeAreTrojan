
@extends('layouts.default')

@section('header')
{{ HTML::style('css/include.css'); }}
@stop

@section('js')
@stop

@section ('content')
<div style="padding-top:70px;padding-left:70px;padding-right:70px;">
   {{ Form::open(array('route' => 'notify.store')) }}
   {{ Form::label('topic', 'Try Sending something to other user') }}
   {{ Form::textarea('message', '' ,array('class'=>'form-control','placeholder'=>'Enter content')) }}
   {{ Form::select('receiver', $list_users)}}
      {{ Form::submit('Send', array('class' => 'btn btn-lg btn-primary loginButton')) }}
  {{ Form::close() }}
</div>
@stop
