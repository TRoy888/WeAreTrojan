@extends('layouts.default')

@section('header')

{{ HTML::style('css/notification/notificationpage.css'); }}


@stop

@section('js')



@stop
@section('content')

<div class="container" style="padding-top:60px">
  <div class="row">


    <div class="col-sm-12">
      <div  style="background-color: #f5f5f5" class="panel panel-default">
        <div class="panel-heading"style="">
          <strong class="panel-title" style="padding-top:7px;padding-left:0px;">Notifications</strong>
        </div>



        <div class="panel-body" style="opacity:1.0">
          @foreach ($notifications as $notification)
          @if (!$notification->is_read)
            <div class="notifsunread" >
                <img src='{{$notification->picture_url}}' style='height:55px;width:55px;float:left;margin-right: 10px;'/>
                {{ Form::open(array('route' => array('notification.destroy', $notification->id), 'method' => 'delete', 'class'=>'deleteform')) }}
                <div class="pull-right">
                    <button type="submit" class="btn label label-custom-delete"><span class="fa fa-times"></span></button>
                </div>
                {{ Form::close() }}
                <div class="message" style="padding-top:5px">
                    <div class="text-custom1" style='color:black'>{{$notification->sender_string.' '.$notification->message}}</div>
                </div>
                  <div class="text-muted">
                    <h6>{{ $notification->timestamp }}.</h6>
                  </div>
            </div>
          @else
          <div class="notifsread" ><a href='{{URL::to("notifications/redirect?id=".$notification->object_id."&type=".$notification->object_type);}}'>
                <img src='{{$notification->picture_url}}' style='height:55px;width:55px;float:left;margin-right: 10px;'></img>
                {{ Form::open(array('route' => array('notification.destroy', 'obj_id' => $notification->object_id, 'obj_type' => $notification->object_type, 'notif_type' => $notification->notification_type), 'method' => 'delete', 'class'=>'deleteform')) }}
                <div class="pull-right">
                    <button type="submit" class="btn label label-custom-delete"><span class="fa fa-times"></span></button>
                </div>
                {{ Form::close() }}
                <div class="message" style="padding-top:5px">
                    <div class="text-custom1" style='color:black'>{{$notification->sender_string.' '.$notification->message}}</div>
                </div>
                  <div class="text-muted">
                    <h6>{{ $notification->timestamp }}.</h6>
                  </div>
                </a>
            </div>
          @endif
          <hr style="margin:10px"/>
          @endforeach

<!--          <div class="notifsunread" >
                <div class="message" style="padding-top:5px"><img src="{{asset('images/profilePictures/title.jpg')}}" style="height:20px;width:20px;">
                  <span class="text-muted"><b>Punyawee Pakdiying</b></span><br>
                  Posted a comment on your 'Should I drop out of medical school (4th year student) and focus on technology' thread
                </div>
                <div class="messageinfo">
                  <h6>2 hours ago</h6>
                </div>
              <div>
                <h6 class="text-muted status">Status: Unread
                <button type="button" class="btn btn-default btn-xs">Mark as Read</button>
                <button type="button" class="btn btn-danger btn-xs">Delete</button></h6>
              </div>
          </div>
          <hr style="margin:10px"/>
          <div class="notifsunread" >
            <div class="message" style="padding-top:5px"><img src="{{asset('images/profilePictures/title.jpg')}}" style="height:20px;width:20px;">
              <span class="text-muted"><b>Pete Nawara</b></span><br>
              Wants to drink with you
            </div>
            <div class="messageinfo">
              <h6>3 hours ago</h6>
            </div>
            <div>
              <h6 class="text-muted status">Status: Unread
                <button type="button" class="btn btn-default btn-xs">Mark as Read</button>
                <button type="button" class="btn btn-danger btn-xs">Delete</button></h6>
              </div>
          </div>
          <hr style="margin:10px"/>
          <div class="notifsread" >
            <div class="message" style="padding-top:5px"><img src="{{asset('images/profilePictures/title.jpg')}}" style="height:20px;width:20px;">
              <span class="text-muted"><b>Gary LaPlante</b></span><br>
              Talked about some trash
            </div>
            <div class="messageinfo">
              <h6>4 hours ago</h6>
            </div>
            <div>
              <h6 class="text-muted status">Status: Read

                <button type="button" class="btn btn-danger btn-xs">Delete</button></h6>
              </div>
          </div>
          <hr style="margin:10px"/>
          <div class="notifsread" >
            <div class="message" style="padding-top:5px"><img src="{{asset('images/profilePictures/title.jpg')}}" style="height:20px;width:20px;">
              <span class="text-muted"><b>Jason Nawara</b></span><br>
              I playing a game
            </div>
            <div class="messageinfo">
              <h6>Yesterday</h6>
            </div>
            <div>
              <h6 class="text-muted status">Status: Read

                <button type="button" class="btn btn-danger btn-xs">Delete</button></h6>
              </div>
            </div>-->
        </div>
      </div>
    </div>



  </div>
</div>
@stop
