@extends('layouts.default')

@section('header')

    {{ HTML::style('css/profile/profile_page.css'); }}
    {{ HTML::style('css/profile/main.css'); }}
    {{ HTML::style('css/profile/jquery.Jcrop.min.css'); }}

@stop

@section('js')
    {{ HTML::script('//code.jquery.com/jquery-migrate-1.2.1.js') }}
    {{ HTML::script('js/profile/profilepage_script.js') }}
    {{ HTML::script('js/profile/profilepage.js') }}
    {{ HTML::script('js/profile/profilepage_circle-progress.js') }}
    {{ HTML::script('js/profile/profilepage_jquery.Jcrop.min.js') }}
    {{ HTML::script('js/jquery.timeago.js') }}



<script type="text/javascript">
    jQuery(document).ready(function() {
        jQuery("time.timeago").timeago();
    });

    var width=0;

    var jfirstname="{{{$first_name}}}";
    var jlastname="{{{$last_name}}}";
    var jemail="{{{$email}}}";
    var thread_area_name=jfirstname+" doesn't";
    var thread_number="{{{$threadnumber}}}";

    @if($class)
      var enterclass=jclas;
    @else
      var d = new Date();
      var enterclass = d.getFullYear();
    @endif

    @if($editable)
      @if($class)
        var jclas="{{{ $class }}}";
      @else
        var jclas="(Enter Your Class)";
      @endif

      @if($degree)
        var jdegree="{{{$degree}}}";
      @else
        var jdegree="(Enter Your Degree)";
      @endif

      @if($summary_profile)
        var jsummary_profile="{{{$summary_profile}}}";
      @else
        var jsummary_profile="(Enter About You)";
      @endif

      @if($hobbies)
        var jhobbies="{{{$hobbies}}}";
      @else
        var jhobbies="(Enter Your Hobbies)";
      @endif

      @if($other)
        var jother="{{{$other}}}";
      @else
        var jother="(Enter Other Information)";
      @endif

      @if($school == "undefined" || $school == "")
        var school="(Enter School Information)";
      @else
        var school="{{{$school}}}";
      @endif

      @else
        var jsummary_profile="{{{$summary_profile}}}";
        var jhobbies="{{{$hobbies}}}";
        var jother="{{{$other}}}";
        var jdegree="{{{$degree}}}";
        var school="{{{$school}}}";

        @if($class)
          var jclas="{{{ $class }}}";
        @else
          var jclas="";
        @endif
    @endif


    var mycategoriesarea="";
    var updatecategoriesarea="";

    @if($editable)
      mycategoriesarea="<div id=\"show_categories\" ></div>";
      updatecategoriesarea="<div id=\"mycategories\" ></div>";
      thread_area_name="You don't"
    @endif



    var like_thread_url = "{{asset('like_thread')}}";
    var unlike_thread_url = "{{asset('unlike_thread')}}";
    var dislike_thread_url = "{{asset('dislike_thread')}}";
    var undislike_thread_url = "{{asset('undislike_thread')}}";

    var jroute="{{route('users.show',Auth::user()->id)}}";
    var updateCategories="{{{ asset('/updateCategories') }}}";
    var threadCategories="{{{ asset('/threadCategories') }}}";
    var schoolGroup="{{{ asset('/schoolGroup') }}}";

    var lpoint={{{$lpoint}}};
    var spoint={{{$spoint}}};
    var ppoint={{{$ppoint}}};
    var user_id="{{{asset("/users/".$id)}}}";
    var updatepassword="{{{asset("/updatepassword")}}}";
    var updatepic="{{{asset("/updatepic")}}}";
    var pictureurl="{{{asset($picture_url)}}}";
    var coverurl="{{{asset($cover_url)}}}";

    var category =
    {
      id: [], 		//id of category that want to set.
      name: [] 	//id of category that want to reset.
    };
    var imagesize = {{{$imagesize}}}; //in bytes

    $(document).ready(function(){
        @foreach($thread_categories as $category)
            category.id.push("{{{$category->id}}}");
            category.name.push("{{{$category->name}}}");
        @endforeach
        mycategories_initialize();
    });

</script>

@stop

@section('content')
<div id="general_outline" class="pageheight general_padding">
        <div id="photo-upload-area" style="opacity:0.8;display:none;z-index:100;position:fixed;background-color:black;"></div>
        <div class="container" style="background-color:white;padding:0px">
            @if($editable)
              <!--Picture Upload Section-->
              <div style ="margin-left:5%;display:none;z-index:100;position:absolute;margin-top:40px" id="upload-wrapper_main" >
                <div class="bbody">
                  <form id="upload_form" enctype="multipart/form-data" method="post" >
                    <!-- hidden crop params -->
                    <input type="hidden" id="x1" name="x1" />
                    <input type="hidden" id="y1" name="y1" />
                    <input type="hidden" id="x2" name="x2" />
                    <input type="hidden" id="y2" name="y2" />
                    <input type="hidden" id="inputtype" name="inputtype"/>
                    <button onclick="profile_info_update();clearcropic();reset_value();" class="btn-sm profile_button">Back</button><br><br>
                    <strong style="color:white;">Step1: Please select image file</strong>
                    <div><input type="file" accept="image/*"  name="image_file" id="image_file" onchange="fileSelectHandler()" style="margin-top:20px;color:white;width:500px"  /></div>
                    <div class="error" id="photo_error"></div>
                    <div class="step2">
                      <br><strong style="color:white;">Step2: Please select a crop region</strong>
                      <div >
                        <img id="preview"/>
                      </div>
                      <div class="info">
                        <label style="color:white;">File size</label> <input type="text" id="filesize" name="filesize" />
                        <label style="color:white;">Type</label> <input type="text" id="filetype" name="filetype" />
                        <label id="w"></label>
                      </div>
                      <button type="submit" value="Upload" class="btn-sm profile_button">Upload</button>
                    </div>
                  </form>
                </div>
              </div>
              <!--Picture Upload Section-->

              <!-- password update section-->
              <div  id="update_password" style="margin-left:25%;display:none;z-index:100;position:absolute;margin-top:150px" >
                <h4  style="color:white">Update Password</h4>
                <form name="form1" id='update_password_form' method="none"  >
                  <table >
                    <tr >
                      <td>
                        <label style="color:white" >Old Password</label>
                      </td>
                      <td>
                        <input type="password" name='oldpassword' id="oldpassword" size="40" required="required" autocomplete="off" name="password1">
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label style="color:white" >New Password</label>
                      </td>
                      <td style="padding-top:2px;">
                        <input type="password" name='newpassword' id="newpassword" size="40" required="required" autocomplete="off" name="password">
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label style="color:white" >New Password(Again)</label>
                      </td>
                      <td style="padding-top:2px;">
                        <input type="password"  autocomplete="off" size="40" id="txtConfirmPassword" required="required"  name="password2">
                      </td>
                    </tr>
                  </table>
                  <p class="registrationFormAlert" style="color:#F00; font-size:16px; margin:3px;" id="divCheckPasswordMatch"></p>
                  <button type="submit" class="btn profile_button" value="Sign up"  name="go">Save</button>
                  <a onclick="change_cover_out();reset_value();" class="btn profile_button">Back</a>
                </form>
              </div>
              <!-- password update section-->
            @endif

            <div><img src={{{asset($picture_url)}}} id="profile_pic"  class="img-thumbnail picture picturemd" style="background-color:black;"/></div>

            @if($editable)
              <div class="editbuttonarea" id="edit_button_area" style="z-index:10;margin-top:10px;"></div>
            @endif

            <h2 id="name_area" class="name_area namemd" style="overflow:hidden;max-height:35px;text-shadow:2px 2px 2px #000000;color:white;position:absolute;z-index:20;">{{{$first_name}}} {{{$last_name}}}</h2>
            <h5 class="aboutmesection name_area rightside aboutmd" id="summary_profile_textarea"></h5>

            <div class="picture picturemd" style="text-align:center;color:white;" id="profile_pic_change"></div>

            <div id="cover_pic" class="CoverImage FlexEmbed FlexEmbed--3by1" style="background-image:url({{{asset($cover_url)}}});"></div>

            <div class="row" style="margin-bottom:50px; margin-top:-200px;margin-right:0px; margin-lef:0px">
              <div class="col-xs-1" style="color:transparent"><br><br><br><br><br><br><br></div>
              <div class="col-xs-10" style="text-align:center;color:black;" id="cover_pic_change"></div>
            </div>

            <div class="row point_info" style="padding-right:0px;margin-right:0px;">
                <div class="col-xs-6 col-sm-3 col-md-1 border_bottoms">
                    <span><b>Level</b></span>
                </div>

                <div class="col-xs-6 col-sm-1 col-md-1 border_bottoms">
                    <span align="left" style="color:#990000;"><span id="user_level"></span></span>
                      <script>
                        var x = {{{$lpoint}}};
                        var level=0;
                        while (x>999)
                          {x=x-1000;level=level+1;}
                          document.getElementById("user_level").innerHTML ="<b>"+level+"</b>";
                      </script>
                    </div>

               <div class="col-xs-6 col-sm-3 col-md-2 border_bottoms">
                      <span><b>Life&nbsp;Time&nbsp;Point</b></span>
                    </div>

               <div class="col-xs-6 col-sm-1 col-md-1 border_bottoms">
                      <span align="left" style="color:#990000;"><b>{{{$lpoint}}}</b></span>
                    </div>

               <div class="col-xs-6 col-sm-3 col-md-1 border_bottoms" style="min-width:110px;">
                      <span ><b>Semester&nbsp;Point</b></span>
                    </div>

                <div class="col-xs-6 col-sm-1 col-md-1 border_bottoms">
                      <span align="left" style="color:#990000;"><b>{{{$spoint}}}</b></span>
                </div>


                        @if($editable)
                        <div class="col-xs-6 col-sm-3 col-md-1 border_bottoms" style="min-width:100px;">
                          <span><b>Usable&nbsp;Point</b></span>
                          </div>
                        <div class="col-xs-6 col-sm-1 col-md-1 border_bottoms">
                          <span align="left" style="color:#990000;"><b>{{{$upoint}}}</b></span>
                        </div>

                        @endif
                  <div class="col-xs-6 col-sm-3 col-md-1 border_bottoms">
                        <span><b>Threads</b></span>
                      </div>

                  <div class="col-xs-6 col-sm-1 col-md-1 border_bottoms">
                        <span align="left" id="question_number" style="color:#990000;"></span>
                      </div>

            </div>

            <hr class="hideout" style="margin-bottom: 0px; margin-top: 0px;"/>

            <div class="row" style="margin-top:40px;margin-right:0px;" id="reference_row">

              <div class="col-xs-1 col-md-1" style="max-width:70px;"></div>

              <div class="col-xs-11 col-md-2" id="profile_info" style="min-width:300px;"></div>

              <div class="col-xs-1 col-md-1" style="max-width:1px;"></div>

              <div class="col-xs-11 col-md-7" style="margin-right:auto;" >

                  <div class="row">
                    <div id="messages"></div>

                    @foreach ($threads as $thread)
                      <div class="panel panel-primary" style="overflow:hidden;padding-right:0px;">
                        <div class="panel-body">
                          <strong>{{ HTML::linkAction('ThreadController@show',$thread->topic,array($thread->id),array('class'=>'text-custom1')) }}</strong>
                          <br>
                          <small class="text-muted"><time class="timeago" datetime="{{$thread->created_at}}"></time></small>
                          <br>
                          <div id="give_padding" class="col-sm-12">
                            <div id="thread-comment-{{$thread->id}}">
                              <div class="comment less" class="col-sm-12">
                                @if(strlen(strip_tags($thread->detail))<Config::get('wat/forum.number_of_character_in_short_thread'))
                                {{substr(strip_tags($thread->detail), 0, Config::get('wat/forum.number_of_character_in_short_thread'))}}
                                @else
                                {{substr(strip_tags($thread->detail), 0, Config::get('wat/forum.number_of_character_in_short_thread')).'...'}}
                                <span class="more_less_btn" onclick="thread.toggleMoreOrLess({{$thread->id}})"><b style="color:#990000">[+more]</b></span>
                                @endif
                              </div>
                              <div class="comment more">
                                {{$thread->detail}}
                                <span class="more_less_btn" onclick="thread.toggleMoreOrLess({{$thread->id}})"><b style="color:#990000">[-less]</b></span>
                              </div>
                            </div>
                          </div>
                          <div class="pull-left">
                            <small class="text-muted"><i class="fa fa-comments"></i>&nbsp;<a href="{{route('thread.show',$thread->id)}}" class="text-muted">Answers: {{Thread::countPost($thread->id)}}</a></small>
                          </div>
                          <div class="pull-left">
                            <span class="text-muted">
                              <small>
                                <span>

                                    <span class="like-text">&nbsp;&nbsp;&nbsp;&nbsp;Like:</span>
                                    <span class="number-of-like"> {{$thread->like_amt}}</span>

                                </span>
                                <span>
                                    <span class="dislike-text">&nbsp;&nbsp;&nbsp;&nbsp;Dislike:</span>
                                    <span class="number-of-dislike"> {{$thread->dislike_amt}}</span>

                                </span>
                              </small>
                            </span>
                          </div>
                        </div>
                      </div>
                      @endforeach
                      {{$threads->links()}}
                  </div>

              </div>

        </div>
      </div>
</div>

@stop
