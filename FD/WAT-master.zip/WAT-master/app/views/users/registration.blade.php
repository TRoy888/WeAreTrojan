<!DOCTYPE html>
<html lang="en">
<head>
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
{{ HTML::style('css/include.css'); }}
{{ HTML::style('css/animate.css'); }}
<script type="text/javascript">
var call_view = function(name)
  {
      window.location = name;
  }
</script>
</head>
<body>
  <div class="align"><h1 class="textchange">We Are Trojans Network</h1></p></div>
  <div class="container">
    <div class="content" id="div1">
      <div class="row vertical-offset-100">
        <div class="col-md-4 col-md-offset-4">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3 class="panel-title" style="color:#610B21;">Registration</h3>
            </div>
            <div class="panel-body">

              @if($errors->any())
                <!-- <div class="alert alert-danger" role="alert">
                  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                  <span class="sr-only"></span>Error:<br>
                    @foreach ($errors->all() as $key=> $error)
                        {{ $key.$error }}<br>
                    @endforeach
                </div> -->
              @endif
              <!--Route changed from session.store to users.store (Eirik)-->
              {{ Form::open(array('route' => 'users.store')) }}
              <fieldset>
                <!-- Don't know why had problem using cellspacing and cellpadding..-->
                <div class="form-group">
                  <table>
                    <tr>
                      <td colspan="2" style="padding-left:20px;width:100%;">{{$errors->first('firstname','<span class=error style="color:red">*:message</span>')}}</td>
                    </tr>
                    <tr>
                      <td style="padding-bottom:10px;padding-left:20px;width:100%;">{{ Form::text('firstname', '', ['class' => 'form-control', 'placeholder' => 'First Name']) }}</td>
                    </tr>
                    <tr>
                      <td colspan="2" style="padding-left:20px;width:100%;">{{$errors->first('lastname','<span class=error style="color:red">*:message</span>')}}</td>
                    </tr>
                    <tr>
                      <td style="padding-bottom:10px;width:100%;padding-left:20px;">{{ Form::text('lastname', '', ['class' => 'form-control', 'placeholder' => 'Last Name']) }}</td>
                    </tr>
                    <tr>
                      <td colspan="2" style="padding-left:20px;width:100%;">{{$errors->first('email','<span class=error style="color:red">*:message</span>')}}</td>
                    </tr>
                    <tr>
                      <td style="width:100%;padding-left:20px;padding-bottom:10px;" style="margin-left:30px;">{{ Form::text('email', '', ['class' => 'form-control', 'placeholder' => 'E-mail']) }}</td><td><strong>@usc.edu</strong></td>
                    </tr>
                    @if($errors->get('password'))
                      @foreach($errors->get('password') as $error)
                      <tr>
                        <td colspan="2" style="padding-left:20px;width:100%;"><span class=error style="color:red">{{$error}}</span></td>
                      </tr>
                      @endforeach
                    @endif
                    <tr>
                      <td style="width:100%;padding-left:20px;padding-bottom:10px;" style="margin-left:30px;">{{ Form::password('password', ['class' => 'form-control', 'placeholder' => 'Password']) }}</td>
                    </tr>
                    <tr>
                        <!--CAUTION: password_confirmation MUST be named so in order for validation in users.store to work! -Eirik -->
                      <td style="width:100%;padding-left:20px;padding-bottom:10px;" style="margin-left:30px;">{{ Form::password('password_confirmation', ['class' => 'form-control', 'placeholder' => 'Re-type Password']) }}</td>
                    </tr>
                  </table>
                </div>
                <div align="center">
                  {{ Form::submit('Sign Up', array('class' => 'btn btn-lg btn-success loginButton')) }}
                </div>
              <div >
                <table align="left" style="margin-top: 20px;">
                  <tr><td style="font-size:14px;">Already a member? {{ HTML::linkAction('SessionController@create','Click here') }}</td></tr>
                </table>
              </div>
            </fieldset>
            </div>
              {{ Form::close() }}
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
