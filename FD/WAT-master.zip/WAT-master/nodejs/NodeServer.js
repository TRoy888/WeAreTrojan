var express =   require('express'),
    http =      require('http'),
    server =    http.createServer(app);
    crypto =    require('crypto');
 //TODO: 
 //1). make it more secure by hashing and using crypto module.
 //2). comment out the console after everything is done.

var app = express();
 
server.listen(3000, 'localhost');

const redis =   require('redis');
const io =      require('socket.io').listen(server);
const redisClient = redis.createClient();
//redis client is listening to any activity from laravel that sends into 'notification' channel
redisClient.subscribe('notification');
 
 //object users stores message and some form of user identify
var users = {};

//If there is any message pushed into redis, node will pick it up here
redisClient.on("message", function(channel, data) {
        //data parse contains message and userID of the receiver
        var $notification = JSON.parse(data);
        //check whether the receiver is online or not.
        if($notification.receiver in users){
            var arrayLength = users[$notification.receiver].length;
            for (var i = 0; i < arrayLength; i++) {
                var socketid = users[$notification.receiver][i];
                //console.log("Sending notification to users with socket: "+socketid+" who is currently online");
                io.sockets.to(socketid).emit(channel,$notification.message);
            }
        }
        //else{
            //debug
           // console.log("Not sending: this user is not online");
        //}
});

io.sockets.on('connection', function(socket) {
    //method of getting connected user's info, so that we can send a specific info for that particular user.
    socket.emit('handshake');
    socket.on("check in",function(incoming){
        socket.user_id = incoming.userId;
        //users already registered:
        if(incoming.userId in users){
            users[incoming.userId].push(socket.id);
            //console.log('user: '+incoming.userId+' is registering in another socket id: '+socket.id+' . He opens '+users[incoming.userId].length+' tabs');
        }
        //if the users not yet registered: creating new array for that user object and save the socketid in it.
        else{
            users[incoming.userId] = [];
            users[incoming.userId].push(socket.id);
            //console.log('user: '+incoming.userId+' is registering in socket id: '+socket.id);
        }
        //debug
    });
    
    //remove object client.user_id from users object
    socket.on('disconnect', function() {
        //debug
            //console.log("user: "+socket.user_id+" disconnects from socket: "+socket.id);
        var index = users[socket.user_id].indexOf(socket.id);
        //remove that socket id from the array
        users[socket.user_id].splice(index,1);
        //check if array still has other elements, if not delete the object
            //console.log("user: "+socket.user_id+" has "+users[socket.user_id].length+" tabs left");
        if(users[socket.user_id].length == 0){   
            //console.log("deleting this user object-- this user is currently offline")
            delete users[socket.user_id];
        }
    });
});