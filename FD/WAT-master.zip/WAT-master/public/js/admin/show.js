function library(module) {
  $(function() {
    if (module.init) {
      module.init();
    }
  });
  return module;
}
/*
var timeFormat = library(function() {
  var $time = $('.timeformat')

  return :
  init: function() {

  }
}());*/

// -- page --
var page = library(function() {
  var $body = $("html, body");

  return {
    scrollTop: function (px) {
      $body.animate({ scrollTop: px });
    }
  }
}());

var Tab = function($tab, paginate, url) {
    this.$tab = $tab;
    this.paginate = paginate;
    this.url = url;
}
Tab.prototype = function() {
  function getPaginationSelectedPage(url) {
    var chunks = url.split('?');
    var baseUrl = chunks[0];
    var queryStr = chunks[1].split('&');
    var pg = 1;
    for (i in queryStr) {
      var qs = queryStr[i].split('=');
      if (qs[0] == 'page') {
        pg = qs[1];
        break;
      }
    }
    return pg;
  };
  function bindUI(obj) {
    obj.$tab.on('click', '.pagination a', function(e) {
      e.preventDefault();
      var pg = getPaginationSelectedPage($(this).attr('href'));
      obj.refresh(pg);
    });
  };

  return {
    init: function(callback) {
      this.$tab.load(this.url+'?page='+this.paginate, function() {
        if (callback !== undefined)
          callback();
      });
      bindUI(this);
    },
    refresh: function(pg, callback) {
      Obj = this;
      if (pg == undefined)
        pg = Obj.paginate;

      $.ajax({
        url: Obj.url,
        data: {page:pg},
        success: function(data) {
          Obj.$tab.html(data);
          Obj.paginate = pg;
          if (callback !== undefined)
            callback();
        }
      });
    }
  }
}();

var ThreadTab = function($tab, paginate, url) {
  Tab.call(this, $tab, paginate, url);
};
ThreadTab.prototype = Object.create(Tab.prototype);
ThreadTab.prototype.constructor = ThreadTab;

var PostTab = function($tab, paginate, url) {
  Tab.call(this, $tab, paginate, url);
}
PostTab.prototype = Object.create(Tab.prototype);
PostTab.prototype.constructor = PostTab;

var EventTab = function($tab, paginate, url) {
  Tab.call(this, $tab, paginate, url);
};
EventTab.prototype = Object.create(Tab.prototype);
EventTab.prototype = {
  constructor: EventTab,
  setTimeformat: function (obj) {
    obj.$tab.find('.timeformat').each(function(idx) {
      var d = new Date($(this).attr('datetime'));
      $(this).text(d.toLocaleString());
      delete d;
    });
  },
  init: function () {
    obj = this;
    function initCallback() {
      EventTab.prototype.setTimeformat.call(this, obj);
    };
    Tab.prototype.init.call(this, initCallback);
  },
  refresh: function (pg) {
    obj = this;
    function initCallback() {
      EventTab.prototype.setTimeformat.call(this, obj);
    };
    Tab.prototype.refresh.call(this, pg, initCallback);
  }
}



// -- tab --
var tabContent = library(function() {
  var eventTab = new EventTab($('#event-tab-content'), 1, events_url)
    , threadTab = new ThreadTab($('#thread-tab-content'), 1, reported_threads_url)
    , postTab = new PostTab($('#post-tab-content'), 1, reported_posts_url)
    , $adminTabbar = $('#admin-tab-bar');

  function bindUI() {
    $adminTabbar.find('a').click(function (e) {
      e.preventDefault();
      $(this).tab('show');
    });
  }

  return {
    init: function() {
      bindUI();
      threadTab.init();
      postTab.init();
      eventTab.init();
    },
    threadTab:threadTab,
    postTab:postTab,
    eventTab:eventTab
  }
}());

// event picture modal
var eventPictureModal = function() {
  var $modal, $image, canvasData, cropBoxData, preview
      , $inputX, $inputY, $inputWidth, $inputHeight;

  function initVariable() {
    $modal = $('#event-cropper-modal');
    $image = $('#event-cropper > img');
    $inputX = $('#form-input-image-x');
    $inputY = $('#form-input-image-y');
    $inputWidth = $('#form-input-image-width');
    $inputHeight = $('#form-input-image-hight');
    pic_preview = '#event-picture-preview';
  }

  function modalShow() {
    $image.cropper({
      aspectRatio:450/350,
      autoCropArea:0.5,
      strict:false,
      preview:pic_preview,
      built: function() {
        $image.cropper('setCanvasData', canvasData);
        $image.cropper('setCropBoxData', cropBoxData);
      },
      crop: function(data) {
        $inputX.val(Math.round(data.x));
        $inputY.val(Math.round(data.y));
        $inputWidth.val(Math.round(data.width));
        $inputHeight.val(Math.round(data.height));
      }
    });
  }

  function modalHidden() {
    canvasData = $image.cropper('getCanvasData');
    cropBoxData = $image.cropper('getCropBoxData');
  }

  return {
    setImage: function(src) {
      $image.attr('src', src);
    },
    show: function() {
      $modal.modal('show');
    },
    destroy: function() {
      $image.cropper('destroy');
    },
    init: function() {
      initVariable();
      $modal.on('shown.bs.modal', modalShow).on('hidden.bs.modal', modalHidden);
    }
  }
}();

// top message widget
var topMessage = library (function () {
  var $message = $('#message-div'),
      $info = $([
        "<div class='alert alert-info' role='alert'>",
        " <span class='sr-only'>:Info</span>",
        "</div>"
      ].join('\n')),
      $danger = $([
        "<div class='alert alert-danger' role='alert'>",
        " <span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>",
        " <span class='sr-only'>:Danger</span>",
        "</div>"
      ].join('\n')),
      $success = $([
        "<div class='alert alert-success' role='alert'>",
        " <span class='glyphicon glyphicon-ok-circle' aria-hidden='true'></span>",
        " <span class='sr-only'>:Success</span>",
        "</div>"
      ].join('\n')),
      $warning = $([
        "<div class='alert alert-warning' role='alert'>",
        " <span class='sr-only'>:Warning</span>",
        "</div>"
      ].join('\n'));

  function setMessage(type, msg) {
    $message.empty();
    type.empty();
    type.text(msg);
    $message.append(type);
  }

  function infoMessage(msg) {
    setMessage($info, msg);
  }

  function dangerMessage(msg) {
    setMessage($danger, msg);
  }

  function successMessage(msg) {
    setMessage($success, msg);
  }

  function warningMessage(msg) {
    setMessage($warning, msg);
  }

  function showMessage() {
    $message.slideDown();
  }

  function hideMessage() {
    $message.slideUp();
  }

  return {
    danger: dangerMessage,
    success: successMessage,
    warning: warningMessage,
    info: infoMessage,
    show: showMessage,
    hide: hideMessage
  }
}());

// create event widget
var createEvent = library (function () {
  var $divCreateEvent = $('#create-event-div')
      , $btnCreate = $('#create-event-btn')
      , urlCreateEvent = './event/create'
      , $btnCancel
      , $formCreateEvent
      , $inputStartDate
      , $inputEndDate
      , $inputPicture
      , $divImgPreview;

  function clearErrorMarkup() {
    $formCreateEvent.find('.form-group').removeClass('has-error');
    $formCreateEvent.find('.form-group .col-sm-9 .control-label').remove();
  }

  function resetForm() {
    $formCreateEvent.trigger("reset");
    clearErrorMarkup();
    eventPictureModal.destroy();
  }

  function sendAjax(form) {
    function sendSuccess(resp) {
      resetForm();
      hideContent();
      page.scrollTop('0px');
      topMessage.success("Create event success!");
      topMessage.show();
      setTimeout (function () {
        topMessage.hide();
      }, 2000);
    }

    function failBadRequest(errors) {
      clearErrorMarkup();

      $.each(errors, function (field, message) {
        $formInput = $('#form-'+field);
        $formInput.addClass('has-error');
        if ($formInput.find('.col-sm-9 .control-label').length == 0)
        {
          $formInput.find('.col-sm-9').prepend('<label class="control-label" for="inputError1"></label>');
        }
        $label = $formInput.find('.col-sm-9 .control-label');
        $label.text(message);
      });
    }

    function sendFail(xhr, ajaxOptions, thrownError) {
      if (xhr.status == 400)
      {
        failBadRequest(xhr.responseJSON.errors);
      }
      else
      {
        clearErrorMarkup();
        page.scrollTop('0px');
        topMessage.danger("Error " + xhr.status + ":" + xhr.statusText);
        topMessage.show();
        setTimeout (function () {
          topMessage.hide();
        }, 2000);
      }
    }

    $.ajax ({
      url: event_store_url,
      type: "POST",
      data: new FormData(form),
      contentType:false,
      cache:false,
      processData:false,
      success: sendSuccess,
      error: sendFail
    });
  }

  function showContent() {
    $divCreateEvent.show('slow');
    $btnCreate.hide();
  }

  function hideContent() {
    page.scrollTop('0px');
    $divCreateEvent.slideUp(400, 'swing', function () {
      resetForm();
      $divImgPreview.hide();
    });
    $btnCreate.show();
  }

  function showPreviewImage(e) {
    var $input = $(this);
    var ifiles = this.files;

    eventPictureModal.destroy();
    if (ifiles == undefined || ifiles.length == 0)
    {
      $divImgPreview.hide();
      return;
    }

    var ifile = ifiles[0];
    var reader = new FileReader();
    reader.onload = function(ev) {
      $input.find('img').attr('src', ev.target.result);
      //$('#event-cropper > img').attr('src', ev.target.result);
      eventPictureModal.setImage(ev.target.result);
      eventPictureModal.show();
      $divImgPreview.show();
    };
    reader.onerror = function(ev) {
      alert('file reader error: ' + ev.target.error.code);
    };
    reader.readAsDataURL(ifile)
  }

  function bindUI() {
    $btnCancel.click(hideContent);
    $btnCreate.click(showContent);
    $inputStartDate.datetimepicker();
    $inputEndDate.datetimepicker();
    $inputPicture.change(showPreviewImage);
    $formCreateEvent.submit(function (e) //this is for updating DB with new pasword
    {
      e.preventDefault();
      sendAjax(this);
    });
  }

  function initVariable() {
    $btnCancel = $('#cancel-create-event-btn');
    $formCreateEvent = $('#event-create-form');
    $inputEndDate = $('#end-date-input');
    $inputStartDate = $('#start-date-input');
    $inputPicture = $('#event-picture-file');
    $divImgPreview = $('#event-picture-preview');
  }

  return {
    show: showContent,
    hide: hideContent,
    init: function() {
      $divCreateEvent.load(urlCreateEvent, function () {
        initVariable();
        eventPictureModal.init();
        bindUI();
      });
    }
  };
}());

//----- POST -----
var post = {};
post.verify = function (pid, uid) {
  var post_data = {
    'post':''+pid,
    'user':''+uid
  };
  $.ajax({
    type:"POST",
    url:verify_post_url,
    data: post_data
  })
  .done (function(msg) {
    tabContent.postTab.refresh();
    //refreshPostTab(getPaginationCurrentPage($('#post-tab-content')));
    topMessage.success("Verify post success!");
    topMessage.show();
    setTimeout (function () {
      topMessage.hide();
    }, 2000);
    //alert('success');
  })
  .fail(function (xhr, textStatus) {
    var response = jQuery.parseJSON (xhr.responseText);
    topMessage.danger("Verify post fail!" + response.errors);
    topMessage.show();
    setTimeout (function () {
      topMessage.hide();
    }, 2000);
    //alert('failed with errors:'+response.errors);
  });
};

post.delete = function(pid, uid) {
  var post_data = {
    'post':''+pid,
    'user':''+uid
  };
  $.ajax({
    type:"POST",
    url:delete_post_url,
    data: post_data
  })
  .done (function(msg) {
    tabContent.postTab.refresh();
    //refreshPostTab(getPaginationCurrentPage($('#post-tab-content')));
    topMessage.success("Delete post success!");
    topMessage.show();
    setTimeout (function () {
      topMessage.hide();
    }, 2000);
    //alert('success');
  })
  .fail (function(xhr, textStstau) {
    var response = jQuery.parseJSON(xhr.errors);
    topMessage.danger("Delete post failed! "+response.errors);
    topMessage.show();
    setTimeout (function () {
      topMessage.hide();
    }, 2000);
    //alert('failed with errors:' + response.errors);
  });
}

//------ THREAD -------
var thread ={};
thread.verify = function(tid, uid)  {
  var post_data = {
    'thread':''+tid,
    'user':''+uid
  };
  $.ajax({
    type:"POST",
    url:verify_thread_url,
    data: post_data
  })
  .done (function(msg) {
    tabContent.threadTab.refresh();
    //refreshThreadTab(getPaginationCurrentPage($('#thread-tab-content')));
    topMessage.success("Verify thread success!");
    topMessage.show();
    setTimeout (function () {
      topMessage.hide();
    }, 2000);
    //alert('success');
  })
  .fail(function(xhr, textStatus) {
    var response = jQuery.parseJSON(xhr.responseText);
    topMessage.danger("Verify thread fail! "+response.errors);
    topMessage.show();
    setTimeout (function () {
      topMessage.hide();
    }, 2000);
    //alert('faile with errors:' + response.errors);
  });
};
thread.delete = function(tid, uid) {
  var post_data = {
    'thread':''+tid,
    'user':''+uid
  };
  $.ajax({
    type:"POST",
    url:delete_thread_url,
    data: post_data
  })
  .done (function(msg) {
    tabContent.threadTab.refresh();
    //refreshThreadTab(getPaginationCurrentPage($('#thread-tab-content')));
    topMessage.success("Delete thread success!");
    topMessage.show();
    setTimeout (function () {
      topMessage.hide();
    }, 2000);
    //alert('success');
  })
  .fail (function(xhr, textStstau) {
    var response = jQuery.parseJSON(xhr.errors);
    topMessage.danger("Delete thread fail! "+response.errors);
    topMessage.show();
    setTimeout (function () {
      topMessage.hide();
    }, 2000);
    //alert('failed with errors:' + response.errors);
  });
};
