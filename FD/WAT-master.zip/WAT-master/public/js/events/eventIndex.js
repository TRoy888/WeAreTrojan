var eventSource = <?php echo $eventData;?>;
$(document).ready(function() {

    // page is now ready, initialize the calendar...


    var eventArray = [];
    for( var topic in eventSource){
      if (eventSource.hasOwnProperty(topic)) {
            eventArray[topic] ={
              title: eventSource[topic]['topic'],
              description: eventSource[topic]['detail'],
              location: eventSource[topic]['location'],
              point: eventSource[topic]['point_for_joining'],
              imageUrl: eventSource[topic]['picture'],
              description: eventSource[topic]['detail'],
              start: eventSource[topic]['start_time'],
              end: eventSource[topic]['end_time'],
              allDay : false,
              color: '#990000',     // an option!
              textColor: '#FFCC00' // an option!
            };
      }
    }

    $('#calendar').fullCalendar({
        // put your options and callbacks here
        header: {
  				left: 'prev,next today',
  				center: 'title',
          right: 'month,basicWeek,basicDay'
  			},
        eventLimit: true,
        allDayDefault: false,
        color  : 'red',
        textColor: 'yellow',
        events: eventArray,

        eventClick:  function(event, jsEvent, view) {
            $('#modalTitle').html(event.title).append("&nbsp;&nbsp;&nbsp;<small>Points:"+event.point+"</small>");
            $('#eventPoint').html(event.point);
            console.log(event);
            var eventStart = moment(event.start).format("hh:mm A");
            var eventEnd = moment(event.end).format("hh:mm A");

            $('#eventLocation').html("Location: "+event.location);
            $('#eventTime').html("Time:&nbsp;"+eventStart+"&nbsp; - &nbsp;"+eventEnd);
            //$('#modalBody').html(event.description);
            $('#eventImage').attr('src',event.imageUrl);
            $('#eventUrl').attr('href',event.url);
            $('#eventDescription').html(event.description);
            $('#fullCalModal').modal();
        }
    });

});
