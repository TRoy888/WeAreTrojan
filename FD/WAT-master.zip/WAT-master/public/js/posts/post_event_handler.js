var post = {};
post.likepost = function(id){
  $("#post-"+id).find("button.like_button").prop("disabled",true);
  $("#post-"+id).find("button.dislike_button").prop("disabled",true);
  $.post(like_post_url, {'post':id}, function(resultString){
    console.log(resultString);
    var result = jQuery.parseJSON(resultString);
    if(!result.error){
      $("#post-"+result.id).find("span.number-of-like").first().text(result.like_amt);
      $("#post-"+result.id).find("span.number-of-dislike").first().text(result.dislike_amt);

      $("#post-"+result.id).find("button.like_button").first().attr('onclick', 'post.unlikepost('+result.id+")");
      $("#post-"+result.id).find("span.like-text").first().text("Unlike");
      $("#post-"+result.id).find("button.like_button").prop("disabled",false);
    }
    else{
      window.location.reload();
    }
  });
}
post.unlikepost = function(id){
  $("#post-"+id).find("button.like_button").prop("disabled",true);
  $.post(unlike_post_url, {'post':id}, function(resultString){
    console.log(resultString);
    var result = jQuery.parseJSON(resultString);
    if(!result.error){
      $("#post-"+result.id).find("span.number-of-like").first().text(result.like_amt);
      $("#post-"+result.id).find("span.number-of-dislike").first().text(result.dislike_amt);

      $("#post-"+result.id).find("button.like_button").first().attr('onclick', 'post.likepost('+result.id+")");
      $("#post-"+result.id).find("span.like-text").first().text("Like");
      $("#post-"+result.id).find("button.like_button").prop("disabled",false);
      $("#post-"+result.id).find("button.dislike_button").prop("disabled",false);
    }
    else{
      window.location.reload();
    }
  });
}
post.dislikepost = function(id){
  $("#post-"+id).find("button.like_button").prop("disabled",true);
  $("#post-"+id).find("button.dislike_button").prop("disabled",true);
  $.post(dislike_post_url, {'post':id}, function(resultString){
    console.log(resultString);
    var result = jQuery.parseJSON(resultString);
    if(!result.error){
      $("#post-"+result.id).find("span.number-of-like").first().text(result.like_amt);
      $("#post-"+result.id).find("span.number-of-dislike").first().text(result.dislike_amt);

      $("#post-"+result.id).find("button.dislike_button").first().attr('onclick', 'post.undislikepost('+result.id+")");
      $("#post-"+result.id).find("span.dislike-text").first().text("Undislike");
      $("#post-"+result.id).find("button.dislike_button").prop("disabled", false);
    }
    else{
      window.location.reload();
    }
  });
}
post.undislikepost = function(id){
  $("#post-"+id).find("button.dislike_button").prop("disabled",true);
  $.post(undislike_post_url, {'post':id}, function(resultString){
    console.log(resultString);
    var result = jQuery.parseJSON(resultString);
    if(!result.error){
      $("#post-"+result.id).find("span.number-of-like").first().text(result.like_amt);
      $("#post-"+result.id).find("span.number-of-dislike").first().text(result.dislike_amt);

      $("#post-"+result.id).find("button.dislike_button").first().attr('onclick', 'post.dislikepost('+result.id+")");
      $("#post-"+result.id).find("span.dislike-text").first().text("Dislike");
      $("#post-"+result.id).find("button.like_button").prop("disabled",false);
      $("#post-"+result.id).find("button.dislike_button").prop("disabled",false);
    }
    else{
      window.location.reload();
    }
  });
}
post.report = function(pid, uid) {
  //send ajax report only 1?
  var post_data = {
    'posts':''+pid,
    'user':''+uid
  };
  $.ajax({
    type:"POST",
    url:report_post_url,
    data: post_data
  })
  .done (function(msg) {
    $("#post-error-"+pid).text(" Report success !");
    $("#post-error-"+pid).show();
    setTimeout (function () {
      $("#post-error-"+pid).slideUp()
    }, 3000);
    //alert('the post id:'+pid+' is reported');
  })
  .fail(function(xhr, textStatus) {
    var response = jQuery.parseJSON(xhr.responseText);
    alert('faile with errors:' + response.errors);
  });
};

post.buttonViewEditToggle = function(id){
  $("#post-div-"+id).find('div.post-detail').toggle();
  $("#post-div-"+id).find('div.post-editor').toggle();
  $("#editor-post-"+id).toggle();
  $("#save-post-"+id).toggle();
  $("#cancel-post-"+id).toggle();
};

post.edit = function(id){
  post.buttonViewEditToggle(id);
  tinymce.get("postcontent_editor-"+id).setContent($('#post-div-'+id).find("div.post-detail").html());
};

post.save = function(id){
  // tinymce.get("postcontent_editor-"+id).setContent($('#post-div-'+id).find("div.post-detail").html());
  var thread_id = $("#post-div-"+id).find('div.post-editor').find('input#thread_id').val(),
  url = update_post_url.replace('{thread}', thread_id).replace('{post}', id)
  , content = tinymce.get("postcontent_editor-"+id).getContent();
  var param = {
    'url': url
    , 'method': 'PATCH'
    , 'data' : {
      'thread_id':thread_id
      , 'post_id':id
      , 'postcontent':content
      , '_token':token
    }
    , 'error':function(jqXHR, status, error){
      // console.log("jq:"+jqXHR);
      // console.log("status:"+status);
      // console.log("error:"+error);
      var message = "Fail!!!";
      //handle error here
      $('#message-post-'+id).addClass("post-fail-message").html(message).fadeIn(function(){
        $(this).fadeOut(5000, function(){
          $('#message-post-'+id).removeClass("post-fail-message").html("");
        });
      });
    }
  };
  $.ajax(param).done(function( data, textStatus, jqXHR) {
    var post_result = JSON.parse(data);
    $('#post-div-'+id).find("div.post-detail").html('');
    $('#post-div-'+id).find("div.post-detail").html(post_result.detail);
    post.buttonViewEditToggle(id);
    $('#message-post-'+id).addClass("post-successful-message").html("Saved Successfully").fadeIn(function(){
      $(this).fadeOut(5000, function(){
        $('#message-post-'+id).removeClass("post-successful-message").html("");
      });
    });
  });
};

post.cancel = function(id){
  post.buttonViewEditToggle(id);
  tinymce.get("postcontent_editor-"+id).setContent("");
};

post.quote = function(id){
  var quote_text = $('#post-div-'+id).find("div.post-detail");
  var user_name = $('#post-div-'+id).find("#user-name-"+id);
  tinymce.get("postcontent").setContent("<blockquote><div class='quoting'>Originally Posted by: <span class='author'>"+user_name.html()+"</span></div>"+quote_text.html()+"</blockquote><p></p>");
  tinymce.get('postcontent').focus(false);
  tinymce.get("postcontent").selection.select(tinyMCE.activeEditor.getBody(), true);
  tinymce.get("postcontent").selection.collapse(false);
  $("body").animate({
    scrollTop: $('#create_comment_box').offset().top - $("body").offset().top + $("body").scrollTop()
  });
  $('#postcontent_ifr').css('height', $('#post-div-'+id).find("div.post-content").height()+60+"px");
}
