/***   THREAD SECTION   ****/

var thread = {};

thread.toggleMoreOrLess = function(id){
  $("#thread-comment-"+id).find(".comment").toggle();
};
$(document).ready(function() {
  $('[data-toggle=offcanvas]').click(function() {
    $('.row-offcanvas-left').toggleClass('active');
  });

  $('[data-toggle=offcanvasright]').click(function() {
    $('.row-offcanvas-right').toggleClass('active');
  });
});

/*** END OF  THREAD SECTION   ****/

function password_change(){
  document.getElementById("photo-upload-area").style.display = "block";
  document.getElementById("update_password").style.display = "block";

}

function change_cover_picture(){

  document.getElementById("photo-upload-area").style.display = "block";
  document.getElementById("upload-wrapper_main").style.display = "block";
  document.getElementById("inputtype").value = "cover";
  $("#cover_pic_change").html("");
  $("#profile_pic_change").html("");
  upload_area_init();
}

function change_profile_picture(){

  document.getElementById("photo-upload-area").style.display = "block";
  document.getElementById("upload-wrapper_main").style.display = "block";
  document.getElementById("inputtype").value = "profile";
  upload_area_init();
  $("#cover_pic_change").html("");
  $("#profile_pic_change").html("");
}

$(window).resize(function (){
  upload_area_init();
});

function upload_area_init(){
  var w = $( document ).width();
  $( "#photo-upload-area" ).css( "width", w );
  var h = $( document ).height();
  //width=w;
  $( "#photo-upload-area" ).css( "height", h+110 );
  //$( "#general_outline" ).css( "height", h+110);
}

function change_cover_over(){
  str="<a style=\"cursor:pointer;\" onclick=\"change_cover_picture()\"><span style=\"font-size:65px\"class=\"glyphicon glyphicon-camera\"></span><br>Update Your Cover Picture</a>";
  $("#cover_pic_change").html(str);
  str="<br><br><a style=\"cursor:pointer;\" onclick=\"change_profile_picture()\"><span class=\"glyphicon glyphicon-camera profile_Cam\"></span><br>Update Your Profile Picture</a>";
  $("#profile_pic_change").html(str);
  document.getElementById("cover_pic").style.opacity = "0.5";
  document.getElementById("profile_pic_change").style.opacity = "0.9";
  document.getElementById("profile_pic_change").style.backgroundColor = "black";
  click_edit_button();
}
function reset_value(){
  document.getElementById("oldpassword").value = "";
  document.getElementById("newpassword").value = "";
  document.getElementById("txtConfirmPassword").value = "";
  document.getElementById("upload-wrapper_main").style.display = "none";
  document.getElementById("update_password").style.display = "none";
  $( "#divCheckPasswordMatch" ).html( "");
}

function change_cover_out(){

  $("#cover_pic_change").html("");
  $("#profile_pic_change").html("");
  document.getElementById("cover_pic").style.opacity = "1.0";
  document.getElementById("profile_pic_change").style.opacity = "1.0";
  document.getElementById("profile_pic_change").style.backgroundColor = "";
  document.getElementById("photo-upload-area").style.display = "none";

  show_categories();
  fillthreadarea();
}



$(document).ready(function(){  //this is for creating resizable function for text area for about me, hobbies and other
  profile_info_initialize();
  upload_area_init();
});

function fillthreadarea(){
  $("#question_number").html("<b>"+thread_number+"<b/>");

  if(thread_number==0)
    {
      $("#messages").html(thread_area_name+" have any thread");
    }
  else
    {
      $("#messages").html("Threads:");
    }
}


//profile info  initilaize
function profile_info_initialize(){
  document.getElementById("summary_profile_textarea").value =jsummary_profile;
  var str=""+
  "<table class=\"profile_info_section\" style=\"border-width: 5px;font-size:14px;font-family: Helvetica;width:100%;\">"+
  "<tr><td style=\"padding-top:5px;max-width: 180px;overflow:hidden; \">"+jdegree+"</td></tr>"+
  "<tr><td style=\"padding-top:5px;\" id=\"user_school_name_long\"></td></tr>";

  if(jclas=="(Enter Your Class)"){
    str=str+"<tr><td style=\"padding-top:5px;\">"+jclas+"</td></tr>";
  }

  else if(jclas==""){
    str=str+"<tr><td style=\"padding-top:5px;\">"+jclas+"</td></tr>";
  }

  else{
    str=str+"<tr><td style=\"padding-top:5px;\">Class of "+jclas+"</td></tr>";
  }


  str=str+"<tr><td style=\"padding-top:5px;\">"+jemail+"</td></tr></table>"+mycategoriesarea+"<hr>";


  $("#profile_info").html(str);
  $("#edit_button_area").html("<button style=\"width: 55px;margin-left:2px;margin-top:2px;font-size:12px;\"class=\"btn-xs profile_button\" onclick=\"password_change();\" title=\"Change Password\"><span class=\"glyphicon glyphicon-lock\"></span></button>"+
                              "<button style=\"width: 55px;margin-left:2px;margin-top:2px;font-size:12px;\"class=\"btn-xs profile_button\" onclick=\"profile_info_update();\" title=\"Edit Profile\">Edit</button>");
  $("#summary_profile_textarea").html(""+jsummary_profile);
  if(school=="(Enter School Information)"){
    $("#user_school_name_long").html("(Enter School Information)");
  }
  else{

  $("#user_school_name_long").ready(function(){ //this creates user school information in long verison on profile page

    $.ajax({
      url: schoolGroup,
      type: "GET",
      success: function(result)
      {
        $("#user_school_name_long").html(result[school]);
      }
    });//end of ajax
  });//end of user_school_name_long
  }
  change_cover_out();
  document.getElementById("name_area").style.opacity = "1.0";
  document.getElementById("summary_profile_textarea").style.opacity = "1.0";
}


//profile information update section
function profile_info_update(){

  document.getElementById("name_area").style.opacity = "0.1";
  document.getElementById("summary_profile_textarea").style.opacity = "0.1";
  var str=""+
  "<div id=\"error_message\" class=\"alert alert-danger\" style=\"display:none;\" role=\"alert\">"+
  "<span class=\"glyphicon glyphicon-exclamation-sign\" aria-hidden=\"true\"></span>"+
  "<span class=\"sr-only\">Error:</span>"+
  "</div>"+
  "<form id=\"edit_profile_form\" >"+
  "<table style=\"font-size:14px;font-family: Helvetica;\">"+
  "<tr><td><input class=\"form-control\" name=\"firstname\" id=\"firstname\" value =\""+jfirstname+"\" maxlength=\"255\" title=\"Enter Name\" placeholder =\"(First Name)\"/></td><td id=\"f_er\" class=\"eror\"></td></tr>"+
  "<tr><td style=\"padding-top:5px;\"><input  class=\"form-control\" name=\"lastname\" id=\"lastname\" value =\""+jlastname+"\" maxlength=\"255\" placeholder =\"(Last Name)\" title=\"Enter Lastname\"/></td><td id=\"l_er\" class=\"eror\"></td></tr>";
  if(jsummary_profile=="(Enter About You)"){
    str=str+"<tr><td style=\"padding-top:5px;\"><input  class=\"form-control\" name=\"description\" id=\"description\" placeholder =\"(About You)\" maxlength=\"255\" title=\"Enter About You\"/></td><td id=\"s_er\" class=\"eror\"></td></tr>";
  }
  else{
    str=str+"<tr><td style=\"padding-top:5px;\"><input  class=\"form-control\" name=\"description\" id=\"description\" placeholder =\"(About You)\" value =\""+jsummary_profile+"\" maxlength=\"255\" title=\"Enter About You\"/></td><td id=\"s_er\" class=\"eror\"></td></tr>";
  }
  if(jdegree=="(Enter Your Degree)"){
    str=str+"<tr><td style=\"padding-top:5px;\"><input  class=\"form-control\" name=\"degree\" id=\"degree\" placeholder =\"(Degree)\" maxlength=\"50\" title=\"Enter Degree Information\"/></td><td id=\"d_er\" class=\"eror\"></td></tr>";
  }
  else{
    str=str+"<tr><td style=\"padding-top:5px;\"><input  class=\"form-control\" name=\"degree\" id=\"degree\" value =\""+jdegree+"\" maxlength=\"50\" title=\"Enter Degree Information\" placeholder =\"(Degree)\"/></td><td id=\"d_er\" class=\"eror\"></td></tr>";
  }

  str=str+"<tr><td style=\"padding-top:5px;\"><select class=\"form-control\" name=\"school\" id=\"school\" style=\"padding-left: 6px;\" placeholder =\"(School)\"title=\"Enter School Information\"></select</td><td id=\"sc_er\" class=\"eror\"></td></tr>";



  if(jclas=="(Enter Your Class)"){
    str=str+"<tr><td style=\"padding-top:5px;\"><input class=\"form-control\" name=\"class\" id=\"class\" value ="+enterclass+" type=\"number\" placeholder =\"(Year of Class)\" title=\"Enter Class Information\"/></td><td id=\"c_er\" class=\"eror\"></td></tr>";
  }
  else{
    str=str+"<tr><td style=\"padding-top:5px;\"><input  class=\"form-control\" name=\"class\" id=\"class\" value ="+jclas+" type=\"number\" placeholder =\"(Year of Class)\" title=\"Enter Class Information\"/></td><td id=\"c_er\" class=\"eror\"></td></tr>";
  }




  str=str+"</table><div  style=\"float:right;padding-top:10px;\">"+
  "<button type=\"submit\" class=\"btn-sm profile_button\">Save</button>"+
  "</div></form>"+updatecategoriesarea+"<hr>";//href=\""+jroute+"\"
  $("#profile_info").html(str);

  $("#edit_button_area").html("<button class=\"btn-sm profile_button\" onclick=\"profile_info_initialize();\" style=\"margin-top:2px;margin-left:59px;width: 55px;font-size:12px;text-align:center;\">Back</button>");
  change_cover_over();
  school_function();
  upload_area_init();
  document.getElementById("photo-upload-area").style.display = "none";
  document.getElementById("upload-wrapper_main").style.display = "none";
  document.getElementById("update_password").style.display = "none";

  $("#edit_profile_form").submit(function(event)//function edit_profile()// //this is for updating DB with user information
  {
    var sum=0;
    var str="";
    event.preventDefault();


    if ($('#firstname').val())
    {
      $('#f_er').html("");
        sum++;
    }
    else
    {
        $('#f_er').html("<span class=\"glyphicon glyphicon-arrow-left\"></span>");
        str=str+"<span class=\"eror\"><span class=\"glyphicon glyphicon-remove-sign eror\"></span>  Firstname is mandatory</span><br class=\"errmsg\">";
    }

    if ($('#lastname').val())
      {
        $('#l_er').html("");
        sum++;
      }
      else
        {
          $('#l_er').html("<span class=\"glyphicon glyphicon-arrow-left\"></span>");
          str=str+"<span class=\"eror\"><span class=\"glyphicon glyphicon-remove-sign eror\"></span>  Lastname is mandatory</span><br class=\"errmsg\">";
        }

    if (checkYear())
      {
        $('#c_er').html("");
        sum++;
      }
      else
        {
          $('#c_er').html("<span class=\"glyphicon glyphicon-arrow-left\"></span>");
          str=str+"<span class=\"eror\"><span class=\"glyphicon glyphicon-remove-sign eror\"></span>  Please enter a number for Class between 1950 and 2050</span>";
        }
    if(sum>2)
    {
        $('#error_message').hide();
        $.ajax
        ({
          url: user_id,
          type: "PUT",
          data: $(this).serialize(),

          success: function(resp)
          {
            $('#error_message').html("<span style=\"color:green;\"class=\"glyphicon glyphicon-ok-sign\"></span><span style=\"color:green;\">  Successfully Saved</span>");
            $('#error_message').show();
            window.location.reload();
          },
          error: function (xhr, ajaxOptions, thrownError)
          {
            $('.errmsg').remove();
            var resp = jQuery.parseJSON(xhr.responseText);
            var errmsg='';
            $.each(resp.errors, function (k, v){
              $('#error_message').html('<span class=\"eror\"><span class=\"glyphicon glyphicon-remove-sign eror\"></span>  '+k+':  '+v+'</span><br class="errmsg">');
              //errmsg = errmsg + k + ":" + v +" /\r\n/  ";
            });
            //$('#error_message').text(errmsg);
            $('#error_message').show();
            //alert(resp.errors.firstname);
          }
        });
     }
     else
    {
      $('#error_message').html(str);
      $('#error_message').show();
    }
  }); //end 0f edit_profile_form
}


function checkYear() //this function checks year information during input of school year information
{
  var a=0;
  a=Number($("#class").val());
  if((a<1950)|| (a>2050)){
    document.getElementById("class").value='';
    return false;
  }
  else
    return true;
}//end of check year

//THIS IS GENERAL JAVASCRIPTS FOR PROFILE PAGE
/* CATEGORY SECTION */
var postData =
{
  set: [], 		//id of category that want to set.
  reset: [] 	//id of category that want to reset.
};

var categoryname =
{
  set: [], 		//name of category that want to set.
  reset: [] 	//name of category that want to reset.
};


function mycategories_initialize()  //THIS IS FOR INITIALIZING MY CATEGORY SECTION
{

  $.ajax({
    url: threadCategories,
    type: "GET",

    success: function(result){

      var includedInFavorite=false;

      for(var key in result)
      {
        for(index=0;index<category.id.length;index++)   //this loop sets postData.set with current category preference
        {
          if(result[key].id==category.id[index])
          {
            includedInFavorite=true;
            postData.set.push(category.id[index]);
            categoryname.set.push(category.name[index]);
          }
        }
        if (includedInFavorite!=true)                    //this if sets postData.reset according to current category preference
        {
          postData.reset.push(result[key].id);
          categoryname.reset.push(result[key].name);
        }
        includedInFavorite=false;
      }
      show_categories(); //update show categories area according to set and reset values
    }
  });
} //end of mycategories_initialize


function click_edit_button()//THIS FUNCTION CREATES CLICK EDIT BUTTON ACTION AND CHANGES MYTHREAD AREA INTO EDITABLE VERSION
{
  var str="<div class=\"row\" style=\"margin-top:0px\"></div>"+

          "<p style=\"font-size:14px\" class=\"text-muted\">Add Topic:</p>"+
          "<div class=\"dropdown\">"+
          "<button class=\"btn btn-default dropdown-toggle\" type=\"button\" id=\"menu1\" data-toggle=\"dropdown\">Select Your Category"+
          "<span class=\"caret\"></span></button>"+
          "<ul style=\"max-height:100px;overflow:auto;cursor:pointer;\" id=\"category_add_section\" class=\"dropdown-menu\" role=\"menu\" aria-labelledby=\"menu1\"></ul></div>"+
          "<p style=\"font-size:14px\" class=\"text-muted\">Your Topic Feeds:</p>"+
          "<div><ul id=\"category_update_section\"style=\"list-style-type:fa fa-dot-circle-o;padding-left: inherit;font-size:17px\"></div>";
  $("#mycategories").html(str);
  category_update_section();  //create update section for delete
  category_add_section();     //create update section for add
} //end of click_edit_button

function category_update_section() //this function creates delete area for category update
{
  var str='';
  for	(index = 0; index < postData.set.length; index++) //this loops creates minus in front of categories, user can delete by clicking the minus
  {
    str=str+'<p style="font-size:14px;"><a onclick=\"remove_category('+postData.set[index]+
            ');\"><span style=\"cursor:pointer;\" class=\"glyphicon glyphicon-minus\"></span></a>&nbsp;&nbsp'+categoryname.set[index]+'</p>';
  }
  str=str+"</li>"
  $("#category_update_section").html(str);
} //end of category_update_section

function category_add_section() //this function creates add area for category update
{
  var str='';
  for	(index = 0; index < postData.reset.length; index++)   //this loop creates dropdown menu with categories that are not included into user's preferences
  {
    str = str+'<li role=\"presentation\"><a onclick=\"add_category('+postData.reset[index]+
              ');\"><span class=\"glyphicon glyphicon-plus\">  '+categoryname.reset[index]+'</span></a></li>';
  }
  $("#category_add_section").html(str);
} //end of category_add_section


function remove_category($id)
{
  var intermediate_post= //this is for intermediate variable for new category preference of user
  {
    set: [],
    reset: [],
    setname:[],
    resetname:[]
  };

  var removed_category=  //this keeps removed category
  {
    set: [],
    name: []
  };

  for(index=0;index<postData.set.length;index++)//This loop finds removed category in postData.set
  {
    if(postData.set[index]==$id)
    {
      removed_category.set.push(postData.set[index]);
      removed_category.name.push(categoryname.set[index]);
    }
    else
    {
      intermediate_post.set.push(postData.set[index]);
      intermediate_post.setname.push(categoryname.set[index]);
    }
  }

  postData.set=[];
  categoryname.set=[]
  for(index=0;index<intermediate_post.set.length;index++)//This loop updates postData.set variable and categoryname.set varible according to removal
  {
    postData.set.push(intermediate_post.set[index]);
    categoryname.set.push(intermediate_post.setname[index]);
  }

  postData.reset[postData.reset.length]=removed_category.set[0]; //removed category added into postData.reset
  categoryname.reset[categoryname.reset.length]=removed_category.name[0];

  $.ajax //update DB
  ({
    url:updateCategories,
    type: "POST",
    data: JSON.stringify(postData),
    error: function (xhr, textStatus, errorThrown)
    {
      var resp = jQuery.parseJSON(xhr.responseText);
    }
  });
  category_update_section(); //update category update section
  category_add_section();    //update category add section
  show_categories();         //update category show section in profile page
} //end of remove_category

function add_category($id)
{
  var intermediate_post=             //this is for intermediate variable for new category preference of user
  {
    set: [],
    reset: [],
    setname:[],
    resetname:[]
  };

  var added_category=           //this keeps added category
  {
    set: [],
    name: []
  };

  for(index=0;index<postData.reset.length;index++)        //This loop finds added category in postData.reset
  {
    if(postData.reset[index]==$id)
    {
      added_category.set.push(postData.reset[index]);
      added_category.name.push(categoryname.reset[index]);
    }
    else
    {
      intermediate_post.reset.push(postData.reset[index]);
      intermediate_post.resetname.push(categoryname.reset[index]);
    }
  }

  postData.reset=[];
  categoryname.reset=[]
  for(index=0;index<intermediate_post.reset.length;index++) //This loop updates postData.reset variable and categoryname.reset varible according to removal
  {
    postData.reset.push(intermediate_post.reset[index]);
    categoryname.reset.push(intermediate_post.resetname[index]);
  }
  postData.set[postData.set.length]=added_category.set[0];
  categoryname.set[categoryname.set.length]=added_category.name[0];

  $.ajax //update DB
  ({
    url:updateCategories,
    type: "POST",
    data: JSON.stringify(postData),
    error: function (xhr, textStatus, errorThrown)
    {
      var resp = jQuery.parseJSON(xhr.responseText);
    }
  });
  category_update_section(); //update category delete section
  category_add_section();    //update category add section
  show_categories();         //update category show section in profile page
}//end of add_category




function show_categories() //This function is for showing current category preference in Profile page
{                          //Note that other users cant see this, look at profile.blade.php-> show_categories division
  var str="<hr style=\"margin:10px\"><p class=\"text-muted\" style=\"font-size:14px\">Which topics do you want to know about?:</p>";
  if(postData.set.length>0)
  {
    for	(index = 0; index < postData.set.length; index++)
    {
      str=str+'<p style=\"font-size:14px\">'+ categoryname.set[index]+'</p>';
    }

  }
  else
  {
    str=str+'<h5>\"You haven\'t select any category!\"</h5>';
  }
  $("#show_categories").html(str);
}//end of show_categories

/*End of category section*/

function school_function(){  //THIS FUNCTION IS for creation of dropdown menu for school information

  $.ajax   //this ajax returns all predefined school information from config/school.php
  ({
    url: schoolGroup,
    type: "GET",
      success: function(result)
      {
        var str='';
        if (school == "(Enter School Information)")
        {
          str=str+'<option placeholder="Eneter" value='+result[school]+'>(Enter School Information)</option>';
        }
        else
        {
          str=str+'<option value='+result[school]+'>'+result[school]+'</option>';
        }

        for (var key in result)  //this is for removal of current school from dropdown
        {
          if(key !=school)
          {
            str = str+'<option value='+result[key]+'>'+result[key]+'</option>';
          }
        }
        $("#school").html(str);
      }
  }); //END OF AJAX
} //END OF edit_profile_form function








function checkPasswordMatch() // this is for comparing the new passord with second input
{

  var password = $("#newpassword").val();
  var confirmPassword = $("#txtConfirmPassword").val();
  if (password == confirmPassword)
  {
    if(password.length>7)
      {
        return 2;
      }
    else
      {
        return 1;
      }
  }
  else
  {
    return 0;
  }
}//end of checkPasswordMatch

$('#update_password_form').submit(function (event) //this is for updating DB with new pasword
{
  event.preventDefault();
  var a=checkPasswordMatch();
  if(a==2)
  {
    $.ajax
    ({
      url: updatepassword,
      type: "POST",
      data: $(this).serialize(),
      success: function(resp)
      {
        $("#divCheckPasswordMatch").html("<span style=\"color:green;\"class=\"glyphicon glyphicon-ok-sign\"></span><span style=\"color:green;\">  Successfully Saved</span>");
        window.location.reload();
      },
      error: function (xhr, ajaxOptions, thrownError)
      {
        var resp = jQuery.parseJSON(xhr.responseText);
        $("#divCheckPasswordMatch").html(resp.errors);
      }
    });
  }
  else if (a==1)
  {
    $("#divCheckPasswordMatch").html("Error: The password must be at least 8 characters.");
  }
  else{
    $("#divCheckPasswordMatch").html("Error: The password confirmation does not match.");
  }
});//end of update_password_form

// check for selected crop region for picture upload
$('#upload_form').submit(function (event) //this updates database with new photo
{
  //$('.error').html('OUTSİDE Upload').show();
  event.preventDefault();
  if (!parseInt($('#w').val()))
  {
    $('.error').html('<span class=\"glyphicon glyphicon-remove-sign eror\"></span>  Please select a crop region and then press Upload').show();

  }
  else
  {
    //$('.error').html('İNSİDE').show();
    $.ajax
    ({
      url: updatepic,
      type: "POST",
      data: new FormData(this),
      contentType: false,
      cache: false,
      processData: false,
      success: function(resp)
      {
        //$('.error').html('SUCCESS').show();
        window.location.reload();
      },
      error: function (xhr, ajaxOptions, thrownError)
      {
        var resp = jQuery.parseJSON(xhr.responseText);
        $('.error').html('<span class=\"glyphicon glyphicon-remove-sign eror\"></span>  '+resp.errors).show();
      }
    });
    //$('.error').html('AFTER').show();
  }
});
