var thread = {};
thread.likeThread = function(id){
  $("#thread-like-dislike-"+id).find("button.like_button").prop("disabled",true);
  $("#thread-like-dislike-"+id).find("button.dislike_button").prop("disabled",true);
  $.post(like_thread_url, {'thread':id}, function(resultString){
    console.log(resultString);
    var result = jQuery.parseJSON(resultString);
    if(!result.error){
      $("#thread-like-dislike-"+result.id).find("span.number-of-like").first().text(result.like_amt);
      $("#thread-like-dislike-"+result.id).find("span.number-of-dislike").first().text(result.dislike_amt);

      $("#thread-like-dislike-"+result.id).find("button.like_button").first().attr('onclick', 'thread.unlikeThread('+result.id+")");
      $("#thread-like-dislike-"+result.id).find("span.like-text").first().text("Unlike");
      $("#thread-like-dislike-"+result.id).find("button.like_button").prop("disabled",false);
    }
    else{
      window.location.reload();
    }
  });
};
thread.unlikeThread = function(id){
  $("#thread-like-dislike-"+id).find("button.like_button").prop("disabled",true);
  $.post(unlike_thread_url, {'thread':id}, function(resultString){
    console.log(resultString);
    var result = jQuery.parseJSON(resultString);
    if(!result.error){
      $("#thread-like-dislike-"+result.id).find("span.number-of-like").first().text(result.like_amt);
      $("#thread-like-dislike-"+result.id).find("span.number-of-dislike").first().text(result.dislike_amt);

      $("#thread-like-dislike-"+result.id).find("button.like_button").first().attr('onclick', 'thread.likeThread('+result.id+")");
      $("#thread-like-dislike-"+result.id).find("span.like-text").first().text("Like");
      $("#thread-like-dislike-"+result.id).find("button.like_button").prop("disabled",false);
      $("#thread-like-dislike-"+result.id).find("button.dislike_button").prop("disabled",false);
    }
    else{
      window.location.reload();
    }
  });
};
thread.dislikeThread = function(id){
  $("#thread-like-dislike-"+id).find("button.like_button").prop("disabled",true);
  $("#thread-like-dislike-"+id).find("button.dislike_button").prop("disabled",true);
  $.post(dislike_thread_url, {'thread':id}, function(resultString){
    console.log(resultString);
    var result = jQuery.parseJSON(resultString);
    if(!result.error){
      $("#thread-like-dislike-"+result.id).find("span.number-of-like").first().text(result.like_amt);
      $("#thread-like-dislike-"+result.id).find("span.number-of-dislike").first().text(result.dislike_amt);

      $("#thread-like-dislike-"+result.id).find("button.dislike_button").first().attr('onclick', 'thread.undislikeThread('+result.id+")");
      $("#thread-like-dislike-"+result.id).find("span.dislike-text").first().text("Undislike");
      $("#thread-like-dislike-"+result.id).find("button.dislike_button").prop("disabled", false);
    }
    else{
      window.location.reload();
    }
  });
};
thread.undislikeThread = function(id){
  $("#thread-like-dislike-"+id).find("button.dislike_button").prop("disabled",true);
  $.post(undislike_thread_url, {'thread':id}, function(resultString){
    console.log(resultString);
    var result = jQuery.parseJSON(resultString);
    if(!result.error){
      $("#thread-like-dislike-"+result.id).find("span.number-of-like").first().text(result.like_amt);
      $("#thread-like-dislike-"+result.id).find("span.number-of-dislike").first().text(result.dislike_amt);

      $("#thread-like-dislike-"+result.id).find("button.dislike_button").first().attr('onclick', 'thread.dislikeThread('+result.id+")");
      $("#thread-like-dislike-"+result.id).find("span.dislike-text").first().text("Dislike");
      $("#thread-like-dislike-"+result.id).find("button.like_button").prop("disabled",false);
      $("#thread-like-dislike-"+result.id).find("button.dislike_button").prop("disabled",false);
    }
    else{
      window.location.reload();
    }
  });
};
thread.report = function(tid, uid) {
  //send ajax report only 1?
  var post_data = {
    'thread':''+tid,
    'user':''+uid
  }
  $.ajax({
    type:"POST",
    url:report_thread_url,
    data: post_data
  })
  .done (function(msg) {
    $("#thread-error-"+tid).text(" Report success !");
    $("#thread-error-"+tid).show();
    setTimeout (function () {
      $("#thread-error-"+tid).slideUp()
    }, 3000);
  })
  .fail(function(xhr, textStatus) {
    var response = jQuery.parseJSON(xhr.responseText);
    alert('faile with errors:' + response.errors);
  });
  // will we make it unable to click
};
thread.buttonViewEditToggle = function(id){
  $("#thread-div-"+id).find('div.thread-detail').toggle();
  $("#thread-div-"+id).find('span.thread-topic').toggle();
  $("#thread-div-"+id).find('.thread-editor').toggle();
  $("#editor-thread-"+id).toggle();
  $("#save-thread-"+id).toggle();
  $("#cancel-thread-"+id).toggle();
};
thread.edit = function(id){
  thread.buttonViewEditToggle(id);
  $('#category-selection').multiselect('select', thread_categories);
  tinymce.get("threadcontent_editor-"+id).setContent($('#thread-div-'+id).find("div.thread-detail").html());
  $("#thread-topic-editor").val($('#thread-div-'+id).find(".topic-header").html());
};
thread.save = function(id){
  var thread_id = $("#thread-div-"+id).find('.thread-editor').find('input#thread_id').val(),
  url = update_thread_url.replace('{thread}', thread_id)
  , content = tinymce.get("threadcontent_editor-"+id).getContent()
  , topic = $("#thread-topic-editor").val()
  , categories = $('#category-selection').val();
  var param = {
    'url': url
    , 'method': 'PATCH'
    , 'data' : {
      'thread_id':thread_id
      , 'topic':topic
      , 'detail':content
      , 'category-selection': categories
      , '_token':token
    }
    , 'error':function(jqXHR, status, error){
      // console.log("jq:"+jqXHR);
      // console.log("status:"+status);
      // console.log("error:"+error);
      var message = "Fail!!!";
      //handle error here
      $('#message-thread-'+id).addClass("thread-fail-message").html(message).fadeIn(function(){
        $(this).fadeOut(5000, function(){
          $('#message-thread-'+id).removeClass("thread-fail-message").html("");
        });
      });
    }
  };
  $.ajax(param).done(function( data, textStatus, jqXHR) {
    var thread_result = JSON.parse(data);
    $('#thread-div-'+id).find("div.thread-detail").html('');
    $('#thread-div-'+id).find(".topic-header").html('');
    $('#thread-div-'+id).find("div.thread-detail").html(thread_result.detail);
    $('#thread-div-'+id).find(".topic-header").html(thread_result.topic);
    $("#category-class").html('');
    // console.log(thread_result);
    thread_categories = [];
    for(var i=0;i<thread_result.categories.length;i++){
      thread_categories.push(thread_result.categories[i].id);
      var category = $('<li></li>').prop('id','catlist')
      , hyperLink = $('<a></a>').prop('class','CatButton').prop('href',home.replace('{category_id}',thread_result.categories[i].id));
      hyperLink.html(thread_result.categories[i].name);
      category.append(hyperLink);
      $("#category-class").append(category);
    }
    thread.buttonViewEditToggle(id);
    thread.clearFields(id);
    $('#message-thread-'+id).addClass("thread-successful-message").html("Saved Successfully").fadeIn(function(){
      $(this).fadeOut(5000, function(){
        $('#message-thread-'+id).removeClass("thread-successful-message").html("");
      });
    });
  });
};
thread.clearFields = function(id){
  tinymce.get("threadcontent_editor-"+id).setContent("");
  $("#thread-topic-editor").val("");
  $('#category-selection').multiselect('deselectAll', false);
  $('#category-selection').multiselect('updateButtonText');
};
thread.cancel = function(id){
  thread.buttonViewEditToggle(id);
  thread.clearFields(id);
};
thread.quote = function(id){
  var quote_text = $('#thread-div-'+id).find("div.thread-detail");
  var user_name = $('#thread-div-'+id).find("#user-name-"+id);
  tinymce.get("postcontent").setContent("<blockquote><div class='quoting'>Originally Posted by: <span class='author'>"+user_name.html()+"</span></div>"+quote_text.html()+"</blockquote><p></p>");
  tinymce.get('postcontent').focus(false);
  tinymce.get("postcontent").selection.select(tinyMCE.activeEditor.getBody(), true);
  tinymce.get("postcontent").selection.collapse(false);
  $("body").animate({
    scrollTop: $('#create_comment_box').offset().top - $("body").offset().top + $("body").scrollTop()
  });
  $('#postcontent_ifr').css('height', quote_text.height()+150+"px");
};
thread.toggleMoreOrLess = function(id){
  $("#thread-comment-"+id).find(".comment").toggle();
};
$(document).ready(function() {
  $('[data-toggle=offcanvas]').click(function() {
    $('.row-offcanvas-left').toggleClass('active');
  });

  $('[data-toggle=offcanvasright]').click(function() {
    $('.row-offcanvas-right').toggleClass('active');
  });
});

/* *********CATEGORY UPDATE SECTION ********************/
var postData =
{
  set: [], 		//id of category that want to set.
  reset: [] 	//id of category that want to reset.
};

var categoryname =
{
  set: [], 		//name of category that want to set.
  reset: [] 	//name of category that want to reset.
};

/*This function will set the showing category in the category list (left side meny) to have red shadow behind it*/
function set_selected_category()
{
  $("#mycategories button").each(function () {
    if ($(this).text() == categoryName){
      $(this).addClass("CatButton-selected");
    }
  });
}

function mycategories_initialize()  //THIS IS FOR INITIALIZING MY CATEGORY SECTION
{
  
  $.ajax
  ({
    url: threadCategories,
    type: "GET",

    success: function(result) //document.getElementById('profile_info').style.display='none';
    {
      var str="<div class=\"row\"><h6 class=\"text-muted\">TOPIC FEEDS<a id=\"edit\"href=\"#\" style=\"float:right;\" onclick=\"click_edit_button();\"><b>EDIT</b></a></h6></div>"+"<hr style=\"margin:5px\"><ul class=\"list-unstyled\">";
      var includedInFavorite=false;
      str=str+'<li id=\"catlist\"><a href=\"'+home+'/allthread\">'+'<button style=\"color:black;\"class=\"CatButton\">All Threads</button></a></li>';
      str=str+'<li id=\"catlist\"><a href=\"'+home+'/hotthread\">'+'<button style=\"color:black;\"class=\"CatButton\">Hot Threads</button></a></li>';
      for(var key in result)
      {
        for(index=0;index<category.id.length;index++)   //this loop sets postData.set with current category preference
        {
          if(result[key].id==category.id[index])
          {
            includedInFavorite=true;
            postData.set.push(category.id[index]);
            categoryname.set.push(category.name[index]);
            str=str+'<li id=\"catlist\"><a href=\"'+home+'/'+category.id[index]+'\">'+'<button style=\"color:black;\"class=\"CatButton\">'+category.name[index]+'</button></a></li>';
          }
        }
        if (includedInFavorite!=true)                    //this if sets postData.reset according to current category preference
        {
          postData.reset.push(result[key].id);
          categoryname.reset.push(result[key].name);
        }
        includedInFavorite=false;
      }
      str=str+'</ul>';
      $("#mycategories").html(str);   //fill in te mycategories area with str variable
      set_selected_category();        //To set the selected category to have shadow behind it
    }
  });
  //find the categoryName is equal to
} //end of mycategories_initialize


function click_edit_button()//THIS FUNCTION CREATES CLICK EDIT BUTTON ACTION AND CHANGES MYTHREAD AREA INTO EDITABLE VERSION
{
  showEdit=false;
  var str="<div class=\"row\"><h6 class=\"text-muted\">YOUR CATEGORY:<a id=\"edit\"href=\"#\" style=\"float:right;\" onclick=\"click_done_button();\"><b>DONE</b></a></h6></div>"+
  "<div><ul id=\"category_update_section\"style=\"list-style-type:fa fa-dot-circle-o;padding-left: inherit;\"></div>"+
  "<div class=\"row\"><h6 class=\"text-muted\">ADD CATEGORY:</h6></div>"+
  "<div class=\"dropdown\">"+
  "<button class=\"btn btn-default dropdown-toggle\" type=\"button\" id=\"menu1\" data-toggle=\"dropdown\">Select Your Category"+
  "<span class=\"caret\"></span></button>"+
  "<ul id=\"category_add_section\" class=\"dropdown-menu\" role=\"menu\" aria-labelledby=\"menu1\"></ul></div>";
  $("#mycategories").html(str);
  category_update_section();  //create update section for delete
  category_add_section();     //create update section for add
} //end of click_edit_button

function category_update_section() //this function creates delete area for category update
{
  var str='';
  str=str+'<p class=\"category_list\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;All Threads</p>';
  str=str+'<p class=\"category_list\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hot Threads</p>';
  for	(index = 0; index < postData.set.length; index++) //this loops creates minus in front of categories, user can delete by clicking the minus
  {
    str=str+'<p class=\"category_list\"><a href=\"#\"onclick=\"remove_category('+postData.set[index]+
    ');\"><span class=\"glyphicon glyphicon-minus\"></span></a>&nbsp;&nbsp'+categoryname.set[index]+'</p>';
  }
  str=str+"</li>"
  $("#category_update_section").html(str);
} //end of category_update_section

function category_add_section() //this function creates add area for category update
{
  var str='';
  for	(index = 0; index < postData.reset.length; index++)   //this loop creates dropdown menu with categories that are not included into user's preferences
  {
    str = str+'<li role=\"presentation\"><a href=\"#\"onclick=\"add_category('+postData.reset[index]+
    ');\"><span class=\"glyphicon glyphicon-plus\">'+categoryname.reset[index]+'</span></a></li>';
  }
  $("#category_add_section").html(str);
} //end of category_add_section

function remove_category($id)
{
  var intermediate_post= //this is for intermediate variable for new category preference of user
  {
    set: [],
    reset: [],
    setname:[],
    resetname:[]
  };

  var removed_category=  //this keeps removed category
  {
    set: [],
    name: []
  };

  for(index=0;index<postData.set.length;index++)//This loop finds removed category in postData.set
  {
    if(postData.set[index]==$id)
    {
      removed_category.set.push(postData.set[index]);
      removed_category.name.push(categoryname.set[index]);
    }
    else
      {
      intermediate_post.set.push(postData.set[index]);
      intermediate_post.setname.push(categoryname.set[index]);
    }
  }

  postData.set=[];
  categoryname.set=[]
  for(index=0;index<intermediate_post.set.length;index++)//This loop updates postData.set variable and categoryname.set varible according to removal
  {
    postData.set.push(intermediate_post.set[index]);
    categoryname.set.push(intermediate_post.setname[index]);
  }

  postData.reset[postData.reset.length]=removed_category.set[0]; //removed category added into postData.reset
  categoryname.reset[categoryname.reset.length]=removed_category.name[0];

  $.ajax //update DB
  ({
    url:updateCategories,
    type: "POST",
    data: JSON.stringify(postData),
    error: function (xhr, textStatus, errorThrown)
    {
      var resp = jQuery.parseJSON(xhr.responseText);
    }
  });
  category_update_section(); //update category update section
  category_add_section();    //update category add section
} //end of remove_category

function add_category($id)
{
  var intermediate_post=             //this is for intermediate variable for new category preference of user
  {
    set: [],
    reset: [],
    setname:[],
    resetname:[]
  };

  var added_category=           //this keeps added category
  {
    set: [],
    name: []
  };

  for(index=0;index<postData.reset.length;index++)        //This loop finds added category in postData.reset
  {
    if(postData.reset[index]==$id)
    {
      added_category.set.push(postData.reset[index]);
      added_category.name.push(categoryname.reset[index]);
    }
    else
    {
      intermediate_post.reset.push(postData.reset[index]);
      intermediate_post.resetname.push(categoryname.reset[index]);
    }
  }

  postData.reset=[];
  categoryname.reset=[]
  for(index=0;index<intermediate_post.reset.length;index++) //This loop updates postData.reset variable and categoryname.reset varible according to removal
  {
    postData.reset.push(intermediate_post.reset[index]);
    categoryname.reset.push(intermediate_post.resetname[index]);
  }
  postData.set[postData.set.length]=added_category.set[0];
  categoryname.set[categoryname.set.length]=added_category.name[0];

  $.ajax //update DB
  ({
    url:updateCategories,
    type: "POST",
    data: JSON.stringify(postData),
    error: function (xhr, textStatus, errorThrown)
    {
      var resp = jQuery.parseJSON(xhr.responseText);
    }
  });
  category_update_section(); //update category delete section
  category_add_section();    //update category add section
}//end of add_category

function click_done_button()  //THIS IS FOR DONE BUTTON ACTION FOR CATEGRY UPDATE SECTION , removes done button, dropdown menu and minuses, creates edit button again
{
  showEdit=true;
  var str="<div class=\"row\"><h6 class=\"text-muted\">TOPIC FEEDS<a id=\"edit\"href=\"#\" style=\"float:right;\" onclick=\"click_edit_button();\"><b>EDIT</b></a></h6></div>"+"<hr style=\"margin:5px\"><ul class=\"list-unstyled\">";
  str=str+'<li id=\"catlist\"><a href=\"'+home+'/allthread\">'+'<button style=\"color:black;\"class=\"CatButton\">All Threads</button></a></li>';
  str=str+'<li id=\"catlist\"><a href=\"'+home+'/hotthread\">'+'<button style=\"color:black;\"class=\"CatButton\">Hot Threads</button></a></li>';
  for	(index = 0; index < postData.set.length; index++)
  {
    str=str+'<li id=\"catlist\"><a href=\"'+home+'/'+postData.set[index]+'\">'+'<button style=\"color:black;\"class=\"CatButton\">'+categoryname.set[index]+'</button></a></li>';
  }
  str=str+'</ul>';
  $("#mycategories").html(str);
  set_selected_category();//To set the selected category to have shadow behind it
}//end of click_button_done
