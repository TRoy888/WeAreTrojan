## WAT We Are Trojan

We Are Trojan is a network that brings Trojans together and acknowledge those who define the meaning of being a Trojan.

## Prerequisites 
1. composer https://getcomposer.org/
2. PHP 5.4+

## Steps to install
1). clone WAT from the git repository
```
git clone https://github.com/TRoy888/WAT <destination_directory>
```

2). go under the root directory of the project

3). run composer to install the project's dependencies
```
composer install
```
4). We use php gd module to handle image so make sure that php have this module
*to install php gd on amazon ec2 run
```
sudo yum install php55-gd
```
   then restart the webserver by 
``` 
/etc/init.d/httpd restart
```
## Steps to install the real-time notification system
0). Sync the latest version

1). Run composer update

2). Download, install, and run Redis
```
http://redis.io/download
```
3). Install node.js
```
https://nodejs.org/download/
```
4). Once node is installed and you have the latest version of the project, go to 'nodejs' folder in the root directory and run this command. This will install all required modules.
```
npm install socket.io express redis
```
5). Run Node.js file in that directory.
```
node NodeServer.js
```
You should be able to see log in the console when a user is accessing the webpage.

6). (optional) You can run this command for monitoring purpose.
```
./redis-cli monitor
```
##Steps to setup Elasticsearch in WAT (Development).
1). Download and decompress elasticsearch files.
```
https://www.elastic.co/
```
2). Modify configurations such as ports, cluster.name of the elasticsearch instance in the following file(Optional)
```
<decompressed directory>/config/elasticsearch.yml
```
3). Go into [decompressed directory]/bin and run to start Elasticsearch.
```
./elasticsearch
```
4). Configure the "elasticsearch_hosts" variable inside app/config/wat/search.php to identify the elasticsearch server's IP address and port.
5). Run the following command to initialize and setup indices for the elasticsearch. (This will enable the search to be able to match the same words in different forms such as jump, jumped, and jumping)
```
php artisan wat:search --setup
```
6). Run the following command to get test data into the elasticsearch server (Optional)
```
php artisan db:seed
```

## Deployment Notes
1. Set up the database connection at app/config/database.php.
2. Change timezone in app/config/app.php if needed this will effect all time used in Laravel.
3. Set log setup in app/start/global.php
4. In order to create table structure, run "php artisan migrate" at the root folder of the project.

WAT is developed based on PHP Laravel framework
## Laravel PHP Framework
[![Build Status](https://travis-ci.org/laravel/framework.svg)](https://travis-ci.org/laravel/framework)
[![Total Downloads](https://poser.pugx.org/laravel/framework/downloads.svg)](https://packagist.org/packages/laravel/framework)
[![Latest Stable Version](https://poser.pugx.org/laravel/framework/v/stable.svg)](https://packagist.org/packages/laravel/framework)
[![Latest Unstable Version](https://poser.pugx.org/laravel/framework/v/unstable.svg)](https://packagist.org/packages/laravel/framework)
[![License](https://poser.pugx.org/laravel/framework/license.svg)](https://packagist.org/packages/laravel/framework)

Laravel is a web application framework with expressive, elegant syntax. We believe development must be an enjoyable, creative experience to be truly fulfilling. Laravel attempts to take the pain out of development by easing common tasks used in the majority of web projects, such as authentication, routing, sessions, and caching.

Laravel aims to make the development process a pleasing one for the developer without sacrificing application functionality. Happy developers make the best code. To this end, we've attempted to combine the very best of what we have seen in other web frameworks, including frameworks implemented in other languages, such as Ruby on Rails, ASP.NET MVC, and Sinatra.

Laravel is accessible, yet powerful, providing powerful tools needed for large, robust applications. A superb inversion of control container, expressive migration system, and tightly integrated unit testing support give you the tools you need to build any application with which you are tasked.

## Official Documentation

Documentation for the entire framework can be found on the [Laravel website](http://laravel.com/docs).

### Contributing To Laravel

**All issues and pull requests should be filed on the [laravel/framework](http://github.com/laravel/framework) repository.**

### License

The Laravel framework is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT)
